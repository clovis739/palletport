import { AUTHORS, BLOG_CATEGORIES, POSTS } from "@/content/blog";
import type { Article } from "@/content/types";

export const slugifyText = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

export const categorySlug = (c: string) => slugifyText(c);
export const categoryFromSlug = (slug: string) => BLOG_CATEGORIES.find((c) => categorySlug(c) === slug);

export function allPosts(): Article[] {
  return [...POSTS].sort((a, b) => (b.date ?? "").localeCompare(a.date ?? ""));
}

export function getPost(slug: string) {
  return POSTS.find((p) => p.slug === slug);
}

export function authorOf(p: Article) {
  return AUTHORS[p.author ?? "team"] ?? AUTHORS.team;
}

export function allTags() {
  const count = new Map<string, number>();
  for (const p of POSTS) for (const t of p.tags ?? []) count.set(t, (count.get(t) ?? 0) + 1);
  return [...count.entries()].sort((a, b) => b[1] - a[1]);
}

/** Posts sharing a category or tag, most overlap first. */
export function relatedPosts(post: Article, n = 3) {
  return allPosts()
    .filter((p) => p.slug !== post.slug)
    .map((p) => ({ p, score: (p.category === post.category ? 2 : 0) + (p.tags ?? []).filter((t) => post.tags?.includes(t)).length }))
    .sort((a, b) => b.score - a.score)
    .slice(0, n)
    .map((x) => x.p);
}

export function neighbours(slug: string) {
  const list = allPosts();
  const i = list.findIndex((p) => p.slug === slug);
  return { newer: i > 0 ? list[i - 1] : undefined, older: i >= 0 && i < list.length - 1 ? list[i + 1] : undefined };
}

export function formatDate(d?: string, style: "medium" | "long" = "medium") {
  return d ? new Date(`${d}T12:00:00`).toLocaleDateString("en-US", { dateStyle: style }) : "";
}
