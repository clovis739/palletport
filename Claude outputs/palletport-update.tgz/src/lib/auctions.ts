import "server-only";
import { db } from "./db";
import { bidIncrement, minNextBid } from "./format";
import { estimateShipments, freightTotal } from "./shipping";

const SOFT_CLOSE_MS = 2 * 60 * 1000; // bids in the last 2 minutes extend the auction
const PAY_WINDOW_MS = 3 * 86400000; // winners have 3 days to pay

export type BidResult =
  | { ok: true; leading: boolean; priceCents: number; message: string }
  | { ok: false; error: string };

/**
 * Proxy bidding: each bidder enters a maximum. The visible price rises only as far as
 * needed to beat the runner-up by one increment.
 */
export async function placeBid(lotId: string, userId: string, maxCents: number): Promise<BidResult> {
  return db.$transaction(async (tx) => {
    const lot = await tx.lot.findUnique({ where: { id: lotId }, include: { seller: { select: { userId: true } } } });
    if (!lot || lot.saleType !== "AUCTION") return { ok: false, error: "This lot isn't an auction" };
    if (lot.status !== "ACTIVE" || !lot.endsAt || lot.endsAt <= new Date()) return { ok: false, error: "This auction has ended" };
    if (lot.seller.userId === userId) return { ok: false, error: "You can't bid on your own lot" };

    const now = new Date();
    const extend = lot.endsAt.getTime() - now.getTime() < SOFT_CLOSE_MS ? new Date(now.getTime() + SOFT_CLOSE_MS) : lot.endsAt;

    // Current leader raising their own maximum.
    if (lot.leaderId === userId) {
      if (maxCents <= (lot.leaderMaxCents ?? 0)) return { ok: false, error: "Your new maximum must be higher than your current one" };
      await tx.lot.update({ where: { id: lot.id }, data: { leaderMaxCents: maxCents } });
      return { ok: true, leading: true, priceCents: lot.priceCents, message: "Maximum bid raised — you're still the high bidder" };
    }

    const minBid = minNextBid(lot);
    if (maxCents < minBid) return { ok: false, error: `Bid at least $${(minBid / 100).toLocaleString()}` };

    // First bid.
    if (!lot.leaderId) {
      const price = lot.startPriceCents ?? lot.priceCents;
      await tx.bid.create({ data: { lotId: lot.id, userId, amountCents: price, maxCents } });
      await tx.lot.update({
        where: { id: lot.id },
        data: { leaderId: userId, leaderMaxCents: maxCents, priceCents: price, bidCount: { increment: 1 }, endsAt: extend },
      });
      return { ok: true, leading: true, priceCents: price, message: "You're the high bidder" };
    }

    const leaderMax = lot.leaderMaxCents ?? lot.priceCents;
    if (maxCents > leaderMax) {
      // New leader. Price becomes one increment over the old leader's max, capped at the new max.
      const price = Math.min(maxCents, leaderMax + bidIncrement(leaderMax));
      await tx.bid.create({ data: { lotId: lot.id, userId: lot.leaderId, amountCents: leaderMax, auto: true, createdAt: new Date(now.getTime() - 1) } });
      await tx.bid.create({ data: { lotId: lot.id, userId, amountCents: price, maxCents } });
      await tx.lot.update({
        where: { id: lot.id },
        data: { leaderId: userId, leaderMaxCents: maxCents, priceCents: price, bidCount: { increment: 2 }, endsAt: extend },
      });
      return { ok: true, leading: true, priceCents: price, message: "You're the high bidder" };
    }

    // Existing leader's proxy outbids the newcomer.
    const price = Math.min(leaderMax, maxCents + bidIncrement(maxCents));
    await tx.bid.create({ data: { lotId: lot.id, userId, amountCents: maxCents, maxCents, createdAt: new Date(now.getTime() - 1) } });
    await tx.bid.create({ data: { lotId: lot.id, userId: lot.leaderId, amountCents: price, auto: true } });
    await tx.lot.update({ where: { id: lot.id }, data: { priceCents: price, bidCount: { increment: 2 }, endsAt: extend } });
    return { ok: true, leading: false, priceCents: price, message: "You've been outbid by another bidder's maximum. Try a higher bid." };
  });
}

/**
 * Closes auctions whose end time has passed. Winners get an order awaiting payment.
 * Runs lazily from pages that show auctions; in production also run it from a cron job.
 */
export async function settleAuctions() {
  const ended = await db.lot.findMany({
    where: { saleType: "AUCTION", status: "ACTIVE", endsAt: { lte: new Date() } },
    select: { id: true },
    take: 50,
  });
  for (const { id } of ended) {
    await db.$transaction(async (tx) => {
      const lot = await tx.lot.findUnique({ where: { id } });
      if (!lot || lot.status !== "ACTIVE") return; // settled concurrently
      if (!lot.leaderId) {
        await tx.lot.update({ where: { id }, data: { status: "ENDED" } });
        return;
      }
      const winner = await tx.user.findUnique({ where: { id: lot.leaderId } });
      if (!winner) {
        await tx.lot.update({ where: { id }, data: { status: "ENDED" } });
        return;
      }
      const shippingCents = freightTotal(
        estimateShipments(
          [{ sellerId: lot.sellerId, sellerName: "", shipsFrom: lot.shipsFrom, lotSize: lot.lotSize, palletCount: lot.palletCount, weightLbs: lot.weightLbs, quantity: 1, priceCents: lot.priceCents }],
          { toZip: winner.shipPostal, method: "FREIGHT", liftgate: true, residential: false },
          lot.priceCents,
        ),
      );
      await tx.order.create({
        data: {
          number: `PP-A${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 36).toString(36).toUpperCase()}`,
          userId: winner.id,
          status: "AWAITING_PAYMENT",
          paymentMethod: "UNPAID",
          fromAuction: true,
          payBy: new Date(Date.now() + PAY_WINDOW_MS),
          subtotalCents: lot.priceCents,
          shippingCents,
          totalCents: lot.priceCents + shippingCents,
          shipName: winner.businessName ?? winner.name,
          shipAddress: winner.shipAddress ?? "",
          shipCity: winner.shipCity ?? "",
          shipRegion: winner.shipRegion ?? "",
          shipPostal: winner.shipPostal ?? "",
          shipCountry: winner.shipCountry ?? "United States",
          items: { create: [{ lotId: lot.id, sellerId: lot.sellerId, title: lot.title, priceCents: lot.priceCents, quantity: 1 }] },
        },
      });
      await tx.lot.update({ where: { id }, data: { status: "SOLD_OUT", available: 0 } });
      await tx.cartItem.deleteMany({ where: { lotId: id } });
    });
  }
}
