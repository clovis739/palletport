import "server-only";
import { db } from "./db";

/** Conversations visible to a user: as buyer, and (if they own a store) as seller. */
export async function getInbox(userId: string) {
  const seller = await db.seller.findUnique({ where: { userId } });
  const convos = await db.conversation.findMany({
    where: { OR: [{ buyerId: userId }, ...(seller ? [{ sellerId: seller.id }] : [])] },
    include: {
      buyer: { select: { name: true, businessName: true, certStatus: true } },
      seller: { select: { name: true, slug: true, userId: true } },
      messages: { orderBy: { createdAt: "desc" }, take: 1 },
    },
    orderBy: { updatedAt: "desc" },
  });
  const unread = await db.message.count({
    where: { readAt: null, senderId: { not: userId }, conversation: { OR: [{ buyerId: userId }, ...(seller ? [{ sellerId: seller.id }] : [])] } },
  });
  return { convos, unread, seller };
}
