import { InquiryForm } from "./InquiryForm";

type Topic = "PRO" | "VOLUME" | "AFFILIATE" | "EVENTS" | "INTEGRATIONS";

export function ProgramPage({
  eyebrow,
  title,
  lead,
  hue,
  benefits,
  steps,
  faqs,
  topic,
  formTitle,
  formCta,
  bodyLabel,
  extra,
}: {
  eyebrow: string;
  title: string;
  lead: string;
  hue: number;
  benefits: [string, string][];
  steps?: string[];
  faqs?: [string, string][];
  topic: Topic;
  formTitle: string;
  formCta: string;
  bodyLabel?: string;
  extra?: React.ReactNode;
}) {
  return (
    <>
      <section className="text-white" style={{ background: `linear-gradient(135deg, hsl(${hue} 50% 18%), hsl(${hue} 45% 32%))` }}>
        <div className="container-pp grid gap-10 py-16 md:grid-cols-[1.2fr_1fr]">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-signal">{eyebrow}</p>
            <h1 className="mt-2 font-display text-4xl font-bold leading-tight sm:text-5xl">{title}</h1>
            <p className="mt-4 max-w-xl text-white/75">{lead}</p>
          </div>
          <div className="rounded-2xl bg-white/5 p-6 ring-1 ring-white/15">
            <p className="mb-4 font-display text-lg font-bold">{formTitle}</p>
            <InquiryForm topic={topic} dark submitLabel={formCta} bodyLabel={bodyLabel ?? "Tell us about your business"} />
          </div>
        </div>
      </section>
      <section className="container-pp py-14">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {benefits.map(([t, d]) => (
            <div key={t} className="card p-5">
              <p className="font-display text-lg font-bold">{t}</p>
              <p className="mt-1 text-sm text-muted">{d}</p>
            </div>
          ))}
        </div>
        {extra}
        {steps && (
          <div className="mt-14">
            <h2 className="mb-5 font-display text-2xl font-bold">How it works</h2>
            <ol className="grid gap-4 md:grid-cols-3">
              {steps.map((s, i) => (
                <li key={s} className="flex gap-3 rounded-2xl bg-sand/70 p-5">
                  <span className="font-display text-2xl font-bold text-signal">{i + 1}</span>
                  <span className="text-sm">{s}</span>
                </li>
              ))}
            </ol>
          </div>
        )}
        {faqs && (
          <div className="mt-14 max-w-3xl">
            <h2 className="mb-4 font-display text-2xl font-bold">Questions</h2>
            <div className="divide-y divide-line rounded-2xl border border-line bg-white">
              {faqs.map(([q, a]) => (
                <details key={q} className="group p-5">
                  <summary className="flex cursor-pointer list-none items-center justify-between font-semibold">
                    {q}<span className="text-signal transition group-open:rotate-45">+</span>
                  </summary>
                  <p className="mt-2 text-sm text-muted">{a}</p>
                </details>
              ))}
            </div>
          </div>
        )}
      </section>
    </>
  );
}
