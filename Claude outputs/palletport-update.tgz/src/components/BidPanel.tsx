"use client";

import { useActionState, useState } from "react";
import { bidAction } from "@/app/actions/bids";
import { SubmitButton } from "./SubmitButton";
import { Countdown } from "./Countdown";

function usd(c: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(c / 100);
}

export function BidPanel({
  lotId,
  priceCents,
  minBidCents,
  incrementCents,
  bidCount,
  endsAt,
  status,
  signedIn,
}: {
  lotId: string;
  priceCents: number;
  minBidCents: number;
  incrementCents: number;
  bidCount: number;
  endsAt: string;
  status: "leading" | "outbid" | "none" | "own";
  signedIn: boolean;
}) {
  const [state, action] = useActionState(bidAction, undefined);
  const [value, setValue] = useState(String(minBidCents / 100));
  const quick = [minBidCents, minBidCents + incrementCents * 2, minBidCents + incrementCents * 5];

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-muted">{bidCount ? "Current bid" : "Starting bid"}</p>
          <p className="font-display text-4xl font-bold">{usd(priceCents)}</p>
          <p className="text-sm text-muted">{bidCount} bid{bidCount === 1 ? "" : "s"}</p>
        </div>
        <div className="text-right">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted">Time left</p>
          <Countdown endsAt={endsAt} compact className="font-display text-xl font-bold" />
          <p className="text-xs text-muted">{new Date(endsAt).toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}</p>
        </div>
      </div>

      {status === "leading" && <p className="rounded-lg bg-moss/10 p-3 text-sm font-semibold text-moss">You're the high bidder. We'll bid for you up to your maximum.</p>}
      {status === "outbid" && <p className="rounded-lg bg-rust/10 p-3 text-sm font-semibold text-rust">You've been outbid. Place a higher maximum to get back in.</p>}

      {status === "own" ? (
        <p className="rounded-lg bg-sand p-3 text-sm">This is your listing. Watch bids from the Seller hub.</p>
      ) : (
        <form action={action} className="space-y-3">
          <input type="hidden" name="lotId" value={lotId} />
          <div className="flex gap-2">
            {quick.map((q) => (
              <button key={q} type="button" onClick={() => setValue(String(q / 100))} className="flex-1 rounded-lg border border-line bg-white py-2 text-sm font-semibold hover:border-ink">
                {usd(q)}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted">$</span>
              <input
                name="max"
                inputMode="numeric"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                className="input pl-7 text-lg font-semibold"
                aria-label="Your maximum bid in dollars"
              />
            </div>
            <SubmitButton className="btn-primary px-6" pendingText="Bidding…">{signedIn ? "Place bid" : "Sign in to bid"}</SubmitButton>
          </div>
          <p className="text-xs text-muted">
            Enter {usd(minBidCents)} or more. Enter the most you'd pay — we'll bid for you in {usd(incrementCents)} steps, only as high as needed. Bids in the final 2 minutes extend the auction.
          </p>
          {state?.error && <p className="rounded-lg bg-rust/10 p-3 text-sm font-medium text-rust">{state.error}</p>}
          {state?.ok && <p className="rounded-lg bg-moss/10 p-3 text-sm font-medium text-moss">{state.ok}</p>}
        </form>
      )}
    </div>
  );
}
