"use client";

import { useState } from "react";

export function ShareBar({ title }: { title: string }) {
  const [copied, setCopied] = useState(false);
  const share = (base: string) => {
    const url = encodeURIComponent(window.location.href);
    const t = encodeURIComponent(title);
    window.open(base.replace("{url}", url).replace("{title}", t), "_blank", "noopener,noreferrer,width=600,height=500");
  };
  return (
    <div>
      <p className="label">Share this article</p>
      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={() => share("https://www.linkedin.com/sharing/share-offsite/?url={url}")} className="btn-ghost px-3 py-2 text-xs">LinkedIn</button>
        <button type="button" onClick={() => share("https://www.facebook.com/sharer/sharer.php?u={url}")} className="btn-ghost px-3 py-2 text-xs">Facebook</button>
        <button type="button" onClick={() => share("https://x.com/intent/post?url={url}&text={title}")} className="btn-ghost px-3 py-2 text-xs">X</button>
        <button type="button" onClick={() => share("mailto:?subject={title}&body={url}")} className="btn-ghost px-3 py-2 text-xs">Email</button>
        <button
          type="button"
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(window.location.href);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            } catch {
              /* blocked */
            }
          }}
          className="btn-ghost px-3 py-2 text-xs"
        >
          {copied ? "Copied!" : "Copy link"}
        </button>
      </div>
    </div>
  );
}
