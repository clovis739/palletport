import { toggleFavorite } from "@/app/actions/social";

export function FavoriteButton({ lotId, saved, back }: { lotId: string; saved: boolean; back: string }) {
  return (
    <form action={toggleFavorite}>
      <input type="hidden" name="lotId" value={lotId} />
      <input type="hidden" name="back" value={back} />
      <button className={saved ? "btn-primary" : "btn-ghost"} aria-pressed={saved}>
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill={saved ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2">
          <path d="M12 21s-7.5-4.6-9.3-9.2C1.5 8.6 3.6 5 7.1 5c2 0 3.4 1.1 4.9 2.8C13.5 6.1 14.9 5 16.9 5c3.5 0 5.6 3.6 4.4 6.8C19.5 16.4 12 21 12 21z" />
        </svg>
        {saved ? "Watching" : "Watch"}
      </button>
    </form>
  );
}
