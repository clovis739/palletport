import Link from "next/link";
import { Logo } from "./Logo";
import { getCurrentUser } from "@/lib/auth";
import { getCartCount } from "@/lib/cart";
import { db } from "@/lib/db";
import { logout } from "@/app/actions/auth";
import { initials } from "@/lib/format";

export async function Header() {
  const [user, categories] = await Promise.all([
    getCurrentUser(),
    db.category.findMany({ orderBy: { name: "asc" }, select: { name: true, slug: true } }),
  ]);
  const [cartCount, unread] = user
    ? await Promise.all([
        getCartCount(user.id),
        db.message.count({
          where: {
            readAt: null,
            senderId: { not: user.id },
            conversation: { OR: [{ buyerId: user.id }, ...(user.seller ? [{ sellerId: user.seller.id }] : [])] },
          },
        }),
      ])
    : [0, 0];

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/95 backdrop-blur">
      <div className="bg-ink text-center text-xs text-white/85">
        <div className="container-pp flex items-center justify-center gap-4 py-2">
          <span>New auctions daily · Free freight on orders over $7,500 · Net 30 for verified resellers</span>
          <Link href="/how-to-buy" className="hidden font-semibold text-signal sm:inline">How bidding works →</Link>
        </div>
      </div>
      <div className="container-pp flex items-center gap-4 py-3">
        <Link href="/" className="shrink-0 text-ink"><Logo /></Link>
        <form action="/search" className="hidden flex-1 md:block">
          <input name="q" placeholder="Search auctions, products, sellers…" className="input rounded-full bg-white" />
        </form>
        <nav className="ml-auto flex items-center gap-1 text-sm font-medium sm:gap-2">
          {user?.role === "ADMIN" && <Link href="/admin" className="hidden rounded-full px-3 py-2 hover:bg-sand lg:block">Admin</Link>}
          {user?.seller ? (
            <Link href="/dashboard" className="hidden rounded-full px-3 py-2 hover:bg-sand sm:block">Seller hub</Link>
          ) : (
            <Link href="/sell" className="hidden rounded-full px-3 py-2 hover:bg-sand sm:block">Sell</Link>
          )}
          {user ? (
            <>
              <Link href="/messages" className="relative rounded-full p-2 hover:bg-sand" aria-label="Messages">
                <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M4 5h16v11H8l-4 4V5z" /></svg>
                {unread > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-signal px-1 text-[11px] font-bold text-white">{unread}</span>}
              </Link>
              <Link href="/bids" className="hidden rounded-full px-3 py-2 hover:bg-sand md:block">My bids</Link>
              <Link href="/account/favorites" className="rounded-full p-2 hover:bg-sand" aria-label="Watchlist">
                <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 21s-7.5-4.6-9.3-9.2C1.5 8.6 3.6 5 7.1 5c2 0 3.4 1.1 4.9 2.8C13.5 6.1 14.9 5 16.9 5c3.5 0 5.6 3.6 4.4 6.8C19.5 16.4 12 21 12 21z" /></svg>
              </Link>
              <details className="relative">
                <summary className="grid h-9 w-9 cursor-pointer list-none place-items-center rounded-full bg-ink font-display text-xs font-bold text-white">{initials(user.name)}</summary>
                <div className="absolute right-0 mt-2 w-56 rounded-xl border border-line bg-white p-2 text-sm shadow-lg">
                  <p className="truncate px-3 py-2 text-xs text-muted">{user.businessName ?? user.email}</p>
                  {[["/account", "Account"], ["/bids", "My bids"], ["/orders", "Orders"], ["/messages", "Messages"], ["/account/favorites", "Watchlist"], ["/account/referrals", "Refer a business"], ...(user.seller ? [["/dashboard", "Seller hub"]] : [])].map(([href, label]) => (
                    <Link key={href} href={href} className="block rounded-lg px-3 py-2 hover:bg-sand">{label}</Link>
                  ))}
                  <form action={logout}><button className="w-full rounded-lg px-3 py-2 text-left text-muted hover:bg-sand">Sign out</button></form>
                </div>
              </details>
            </>
          ) : (
            <>
              <Link href="/login" className="rounded-full px-3 py-2 hover:bg-sand">Sign in</Link>
              <Link href="/register" className="btn-dark hidden sm:inline-flex">Register to bid</Link>
            </>
          )}
          <Link href="/cart" className="relative rounded-full p-2 hover:bg-sand" aria-label="Cart">
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M3 4h2l2.4 11.2a1 1 0 0 0 1 .8h9.2a1 1 0 0 0 1-.8L20 8H6.2" />
              <circle cx="9" cy="20" r="1.3" /><circle cx="17" cy="20" r="1.3" />
            </svg>
            {cartCount > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-signal px-1 text-[11px] font-bold text-white">{cartCount}</span>}
          </Link>
        </nav>
      </div>
      <div className="container-pp -mt-1 flex gap-1 overflow-x-auto pb-2 text-sm [scrollbar-width:none]">
        <Link href="/auctions" className="shrink-0 rounded-full bg-ink px-3 py-1.5 font-semibold text-white hover:bg-ink-2">Auctions</Link>
        <Link href="/auctions?ending=today" className="shrink-0 rounded-full px-3 py-1.5 font-semibold text-rust hover:bg-sand">Ending today</Link>
        <Link href="/buy-now" className="shrink-0 rounded-full px-3 py-1.5 font-semibold hover:bg-sand">Buy Now</Link>
        <Link href="/truckloads" className="shrink-0 rounded-full px-3 py-1.5 font-semibold hover:bg-sand">Truckloads</Link>
        <Link href="/pallets" className="shrink-0 rounded-full px-3 py-1.5 font-semibold hover:bg-sand">Pallets</Link>
        <Link href="/case-packs" className="shrink-0 rounded-full px-3 py-1.5 font-semibold hover:bg-sand">Case packs</Link>
        <span className="mx-1 w-px shrink-0 bg-line" />
        {categories.map((c) => (
          <Link key={c.slug} href={`/c/${c.slug}`} className="shrink-0 rounded-full px-3 py-1.5 text-ink/75 hover:bg-sand hover:text-ink">{c.name}</Link>
        ))}
        <Link href="/sellers" className="shrink-0 rounded-full px-3 py-1.5 text-ink/75 hover:bg-sand hover:text-ink">Sellers</Link>
      </div>
    </header>
  );
}
