import Link from "next/link";
import { db } from "@/lib/db";
import { money } from "@/lib/format";
import { GUIDES } from "@/content/guides";
import { PalletArt } from "@/components/PalletArt";

export const metadata = {
  title: "About us",
  description: "PalletPort is the B2B marketplace for manifested liquidation lots — returns, shelf pulls and overstock by the case, pallet or truckload.",
};
export const dynamic = "force-dynamic";

function Arrow() {
  return <span aria-hidden className="inline-block transition group-hover:translate-x-1">→</span>;
}

export default async function About() {
  const [sellers, buyers, lotsListed, soldLots, retail, units, reviews, avgRating] = await Promise.all([
    db.seller.count(),
    db.user.count({ where: { role: "BUYER" } }),
    db.lot.count(),
    db.lot.count({ where: { status: "SOLD_OUT" } }),
    db.lot.aggregate({ _sum: { msrpCents: true } }),
    db.lot.aggregate({ _sum: { units: true } }),
    db.review.count(),
    db.review.aggregate({ _avg: { rating: true } }),
  ]);

  const stats: { n: string; label: string; href: string }[] = [
    { n: lotsListed.toLocaleString(), label: "lots listed", href: "/search" },
    { n: money(retail._sum.msrpCents ?? 0), label: "retail value listed", href: "/lots?sort=retail" },
    { n: (units._sum.units ?? 0).toLocaleString(), label: "units on manifests", href: "/lots?sort=units" },
    { n: soldLots.toLocaleString(), label: "lots sold", href: "/lots?sold=1" },
    { n: sellers.toLocaleString(), label: "verified liquidators & sellers", href: "/sellers" },
    { n: reviews ? `${(avgRating._avg.rating ?? 0).toFixed(1)} ★` : `${buyers.toLocaleString()}`, label: reviews ? `average from ${reviews} buyer reviews` : "registered buyers", href: "/sellers" },
  ];

  const audiences = GUIDES.map((g) => ({ href: `/guides/${g.slug}`, title: g.title, text: g.excerpt, hue: g.hue ?? 24, slug: g.slug }));

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-ink text-white">
        <div className="container-pp grid items-center gap-10 py-16 md:grid-cols-[1.3fr_1fr] md:py-20">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-signal">About PalletPort</p>
            <h1 className="mt-3 font-display text-4xl font-bold leading-[1.05] sm:text-5xl">The marketplace that keeps good goods moving.</h1>
            <p className="mt-5 max-w-xl text-lg text-white/70">
              We connect retailers, distributors and returns processors with the independent businesses that give their surplus a second life — by the case, the pallet or the truckload.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/register" className="btn-primary px-6 py-3">Get started</Link>
              <Link href="/how-it-works" className="rounded-full border border-white/25 px-6 py-3 text-sm font-semibold hover:bg-white/10">How it works</Link>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {["about-a", "about-b", "about-c", "about-d"].map((s, i) => (
              <div key={s} className={`overflow-hidden rounded-2xl ${i % 2 ? "translate-y-6" : ""}`}>
                <PalletArt seed={s} hue={[24, 215, 150, 330][i]} className="w-full" />
              </div>
            ))}
          </div>
        </div>
        <div className="stripe h-2" />
      </section>

      {/* Numbers — every card links to the matching listing */}
      <section className="container-pp py-14">
        <h2 className="mb-6 font-display text-2xl font-bold sm:text-3xl">PalletPort by the numbers</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {stats.map((s) => (
            <Link key={s.label} href={s.href} className="group card flex items-end justify-between p-6 transition hover:-translate-y-0.5 hover:border-ink">
              <div>
                <p className="font-display text-4xl font-bold">{s.n}</p>
                <p className="mt-1 text-sm text-muted">{s.label}</p>
              </div>
              <span className="text-signal-dark"><Arrow /></span>
            </Link>
          ))}
        </div>
      </section>

      {/* Mission */}
      <section className="border-y border-line bg-sand/50">
        <div className="container-pp grid gap-10 py-16 md:grid-cols-2">
          <div>
            <p className="label">Our mission</p>
            <h2 className="font-display text-3xl font-bold leading-tight">Make buying surplus inventory as clear as buying anything else online.</h2>
          </div>
          <div className="space-y-4 text-ink/80">
            <p>Liquidation used to mean phone calls, blind pallets and guesswork. We think resellers deserve better: a full manifest on every lot, honest condition grades, real freight quotes and sellers who have been checked before they list.</p>
            <p>For sellers, we offer a faster route to cash than holding stock in a warehouse — with auctions, fixed-price sales and buyers across the country ready to bid.</p>
            <Link href="/how-it-works" className="group inline-flex items-center gap-1 font-semibold text-signal-dark">See how the marketplace works <Arrow /></Link>
          </div>
        </div>
      </section>

      {/* Sustainability */}
      <section className="container-pp grid items-center gap-10 py-16 md:grid-cols-[1fr_1.2fr]">
        <PalletArt seed="about-green" hue={150} className="w-full rounded-2xl" />
        <div>
          <p className="label">Sustainability</p>
          <h2 className="font-display text-3xl font-bold leading-tight">Every resold pallet is one less load for landfill.</h2>
          <p className="mt-4 text-ink/80">Returned and overstocked goods are often destroyed simply because processing them is inconvenient. By making resale easy, we help keep usable products in circulation and support the local shops, market vendors and repairers who give them a second life.</p>
          <Link href="/blog/liquidation-and-sustainability" className="group mt-5 inline-flex items-center gap-1 font-semibold text-signal-dark">Why reselling returns is good for the planet <Arrow /></Link>
        </div>
      </section>

      {/* Transparent buying */}
      <section className="bg-ink text-white">
        <div className="container-pp py-16">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-signal">A transparent buying experience</p>
          <h2 className="mt-2 max-w-2xl font-display text-3xl font-bold">No mystery boxes. No surprises at checkout.</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-4">
            {[
              { href: "/blog/how-to-read-a-manifest", t: "Full manifests", d: "Every lot lists SKUs, quantities and retail values — search, sort or download them." },
              { href: "/how-it-works#conditions", t: "Clear condition grades", d: "New, shelf pull, customer return, mixed or salvage — labelled on every lot." },
              { href: "/blog/ltl-freight-101", t: "Freight up front", d: "Estimate shipping by ZIP on the lot page before you bid, with pickup where offered." },
              { href: "/legal/returns-and-disputes", t: "Buyer protection", d: "If a lot arrives materially below its manifest, you're covered." },
            ].map((c) => (
              <Link key={c.t} href={c.href} className="group rounded-2xl border border-white/10 bg-white/5 p-5 transition hover:border-white/30 hover:bg-white/10">
                <p className="font-display text-lg font-semibold">{c.t}</p>
                <p className="mt-1 text-sm text-white/65">{c.d}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-signal">Learn more <Arrow /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Who buys */}
      <section className="container-pp py-16">
        <p className="label">Who buys from us</p>
        <h2 className="mb-8 font-display text-3xl font-bold">Built for every kind of reseller</h2>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {audiences.map((a) => (
            <Link key={a.slug} href={a.href} className="group card overflow-hidden transition hover:-translate-y-0.5 hover:border-ink">
              <PalletArt seed={a.slug} hue={a.hue} className="aspect-[16/8] w-full" />
              <div className="p-5">
                <p className="font-display text-lg font-bold group-hover:text-signal-dark">{a.title}</p>
                <p className="mt-1 text-sm text-muted">{a.text}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-signal-dark">Read the guide <Arrow /></span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Advantages */}
      <section className="border-t border-line bg-sand/50">
        <div className="container-pp py-16">
          <p className="label">Our advantages</p>
          <h2 className="mb-8 font-display text-3xl font-bold">Why resellers choose PalletPort</h2>
          <div className="grid gap-5 md:grid-cols-3">
            {[
              { href: "/sellers", t: "Buy with confidence", d: "Sellers are reviewed before they list, rated by buyers, and marked verified once we've confirmed their business.", cta: "Meet our sellers" },
              { href: "/how-to-buy", t: "No hidden fees", d: "You see the bid increments, freight estimate and payment terms before you commit. What you win is what you pay.", cta: "How buying works" },
              { href: "/truckloads", t: "Scale with ease", d: "Start with a single case pack and grow to weekly truckloads — plus Net 30 terms once your business is verified.", cta: "Shop truckloads" },
            ].map((c) => (
              <Link key={c.t} href={c.href} className="group card flex flex-col p-6 transition hover:-translate-y-0.5 hover:border-ink">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-signal font-display font-bold text-white">✓</span>
                <p className="mt-4 font-display text-xl font-bold">{c.t}</p>
                <p className="mt-2 flex-1 text-sm text-ink/75">{c.d}</p>
                <span className="mt-4 inline-flex items-center gap-1 font-semibold text-signal-dark">{c.cta} <Arrow /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Thank you */}
      <section className="container-pp py-16 text-center">
        <h2 className="font-display text-3xl font-bold">Thank you</h2>
        <p className="mx-auto mt-3 max-w-2xl text-ink/75">
          To the resellers who trust us with their sourcing and the sellers who trust us with their inventory — thank you. We're just getting started, and we'd love to hear what you'd like us to build next.
        </p>
        <div className="mx-auto mt-10 grid max-w-4xl gap-4 sm:grid-cols-3">
          {[
            { href: "/register", t: "Start buying", d: "Create a free business account" },
            { href: "/sell", t: "Start selling", d: "Open a seller store" },
            { href: "/contact", t: "Talk to us", d: "Questions, feedback or partnerships" },
          ].map((c) => (
            <Link key={c.t} href={c.href} className="group card p-5 text-left transition hover:-translate-y-0.5 hover:border-ink">
              <p className="font-display text-lg font-bold group-hover:text-signal-dark">{c.t} <Arrow /></p>
              <p className="text-sm text-muted">{c.d}</p>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
