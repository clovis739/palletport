import Link from "next/link";
import { headers } from "next/headers";
import { getCurrentUser } from "@/lib/auth";

export const metadata = { title: "Invite your buyers" };

export default async function SellerRefer() {
  const user = await getCurrentUser();
  const h = await headers();
  const origin = `${h.get("x-forwarded-proto") ?? "http"}://${h.get("host") ?? "localhost:3000"}`;
  const link = user?.seller ? `${origin}/register?ref=${user.referralCode}&next=/sellers/${user.seller.slug}` : null;
  return (
    <div className="container-pp grid gap-10 py-14 md:grid-cols-2">
      <div className="space-y-4">
        <p className="label">For sellers</p>
        <h1 className="font-display text-4xl font-bold leading-tight">Bring your existing buyers — keep more of every sale.</h1>
        <p className="text-ink/75">Already have customers who buy from you by phone or email? Invite them to order through PalletPort. Orders from buyers you bring pay a reduced 3% commission for their first year, and they land on your storefront, not someone else's.</p>
        <ul className="list-disc space-y-1.5 pl-5 text-sm marker:text-signal">
          <li>Buyers get online ordering, Net 30 (when verified) and freight tracking.</li>
          <li>You get one place for orders, invoices and payouts.</li>
          <li>Invited buyers see your storefront first when they sign up.</li>
        </ul>
      </div>
      <div className="card p-6">
        {link ? (
          <>
            <p className="font-display text-lg font-bold">Your invite link</p>
            <input readOnly value={link} className="input mt-3 font-mono text-xs" aria-label="Invite link" />
            <p className="mt-2 text-xs text-muted">Share it in your emails, invoices and texts to buyers.</p>
            <Link href="/dashboard/customers" className="btn-ghost mt-5">See your customers</Link>
          </>
        ) : (
          <>
            <p className="font-display text-lg font-bold">Open a store to get your invite link</p>
            <p className="mt-1 text-sm text-muted">It takes about two minutes.</p>
            <Link href="/sell" className="btn-primary mt-5">Open a seller store</Link>
          </>
        )}
      </div>
    </div>
  );
}
