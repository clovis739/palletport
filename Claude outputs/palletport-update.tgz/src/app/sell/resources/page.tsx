import Link from "next/link";
import { POSTS } from "@/content/blog";
import { HELP } from "@/content/help";

export const metadata = { title: "Seller resources" };

export default function SellerResources() {
  const tips = POSTS.filter((p) => p.category === "Seller tips");
  const help = HELP.filter((h) => h.category === "Selling");
  return (
    <div className="container-pp py-12">
      <h1 className="font-display text-4xl font-bold">Seller resources</h1>
      <p className="mb-10 text-muted">Everything you need to list well, ship smoothly and get paid.</p>
      <div className="grid gap-8 lg:grid-cols-3">
        <section className="lg:col-span-2">
          <h2 className="mb-4 font-display text-xl font-bold">Playbooks</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            {tips.map((p) => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="card p-5 hover:border-ink">
                <p className="font-display text-lg font-bold">{p.title}</p>
                <p className="mt-1 text-sm text-muted">{p.excerpt}</p>
              </Link>
            ))}
          </div>
          <h2 className="mb-4 mt-10 font-display text-xl font-bold">Checklist for a great first listing</h2>
          <ol className="card list-decimal space-y-2 p-6 pl-10 text-sm">
            <li>Write a clear title: category, condition and pallet count.</li>
            <li>Paste an accurate manifest with realistic retail values.</li>
            <li>Price against comparable live lots (check percent of retail).</li>
            <li>Describe testing, packaging and pickup options.</li>
            <li>Add a first-order promo to attract new buyers.</li>
            <li>Reply to buyer messages within one business day.</li>
          </ol>
        </section>
        <aside className="space-y-4">
          <div className="card p-5">
            <p className="label">Help articles</p>
            <ul className="space-y-2 text-sm">{help.map((h) => <li key={h.slug}><Link href={`/help/${h.slug}`} className="hover:underline">{h.title}</Link></li>)}</ul>
          </div>
          <div className="rounded-2xl bg-ink p-5 text-white">
            <p className="font-display text-lg font-bold">Ready to list?</p>
            <Link href="/dashboard/new" className="btn-primary mt-3">List a pallet</Link>
          </div>
          <Link href="/sell/refer" className="card block p-5 hover:border-ink">
            <p className="font-display font-bold">Invite your buyers →</p>
            <p className="text-sm text-muted">Reduced commission on buyers you bring.</p>
          </Link>
        </aside>
      </div>
    </div>
  );
}
