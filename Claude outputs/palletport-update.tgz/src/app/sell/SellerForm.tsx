"use client";

import { useActionState } from "react";
import { becomeSeller } from "@/app/actions/seller";
import { SubmitButton } from "@/components/SubmitButton";

export function SellerForm() {
  const [state, action] = useActionState(becomeSeller, undefined);
  return (
    <form action={action} className="space-y-4 p-6">
      <h2 className="font-display text-xl font-bold">Open your seller store</h2>
      <div><label className="label" htmlFor="name">Store name</label><input id="name" name="name" className="input" required /></div>
      <div><label className="label" htmlFor="location">Warehouse location</label><input id="location" name="location" placeholder="City, State" className="input" required /></div>
      <div><label className="label" htmlFor="bio">About your inventory</label><textarea id="bio" name="bio" rows={4} className="input" placeholder="Where your stock comes from, how you grade it, pickup and freight options…" required /></div>
      {state?.error && <p className="rounded-lg bg-rust/10 p-3 text-sm font-medium text-rust">{state.error}</p>}
      <SubmitButton className="btn-primary w-full py-3">Open store</SubmitButton>
    </form>
  );
}
