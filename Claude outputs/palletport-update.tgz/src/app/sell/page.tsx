import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { SellerForm } from "./SellerForm";

export const metadata = { title: "Sell on PalletPort" };

export default async function SellPage() {
  const user = await getCurrentUser();
  if (user?.seller) redirect("/dashboard");

  return (
    <>
      <section className="bg-ink text-white">
        <div className="container-pp grid gap-10 py-16 md:grid-cols-2">
          <div className="space-y-5">
            <h1 className="font-display text-4xl font-bold leading-tight sm:text-5xl">Turn returns and overstock into <span className="text-signal">cash flow.</span></h1>
            <p className="text-white/70">List manifested pallets and truckloads, set your price, and ship to resellers nationwide. You keep control of every lot.</p>
            <div className="grid grid-cols-3 gap-4 pt-2">
              {[["0", "listing fees"], ["48 hrs", "avg. time to sell"], ["2 days", "payout after delivery"]].map(([n, l]) => (
                <div key={l}><p className="font-display text-2xl font-bold text-signal">{n}</p><p className="text-xs text-white/60">{l}</p></div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl bg-white p-1 text-ink">
            {user ? (
              <SellerForm />
            ) : (
              <div className="space-y-4 p-6">
                <h2 className="font-display text-xl font-bold">Start with an account</h2>
                <p className="text-sm text-muted">Create an account or sign in, then open your seller store in one step.</p>
                <div className="flex gap-3">
                  <Link href="/register?next=/sell" className="btn-primary">Create account</Link>
                  <Link href="/login?next=/sell" className="btn-ghost">Sign in</Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
      <section className="container-pp grid gap-6 py-14 md:grid-cols-3">
        {[
          ["Upload a manifest", "Paste line items or CSV rows. We total units and retail value for you."],
          ["Get matched with buyers", "Lots appear in search, category feeds, and your own storefront page."],
          ["Ship and get paid", "Mark orders shipped from the seller hub. Payouts land after delivery."],
        ].map(([t, d]) => (
          <div key={t} className="card p-6">
            <h3 className="font-display text-lg font-semibold">{t}</h3>
            <p className="mt-1 text-sm text-muted">{d}</p>
          </div>
        ))}
      </section>
    </>
  );
}
