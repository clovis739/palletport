import { forbidden, redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { money } from "@/lib/format";
import { markInquiryHandled, setCertStatus, setSellerVerified, toggleFeatured } from "@/app/actions/admin";

export const metadata = { title: "Admin" };

export default async function Admin() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin");
  if (user.role !== "ADMIN") forbidden();

  const [pendingCerts, sellers, inquiries, lots, stats] = await Promise.all([
    db.user.findMany({ where: { certStatus: "PENDING" }, orderBy: { createdAt: "asc" } }),
    db.seller.findMany({ orderBy: [{ verified: "asc" }, { createdAt: "desc" }], include: { _count: { select: { lots: true } } } }),
    db.inquiry.findMany({ where: { handled: false }, orderBy: { createdAt: "desc" }, take: 30 }),
    db.lot.findMany({ where: { status: "ACTIVE" }, orderBy: [{ featured: "desc" }, { views: "desc" }], take: 20, select: { id: true, title: true, featured: true, views: true } }),
    Promise.all([db.user.count(), db.order.count(), db.order.aggregate({ _sum: { totalCents: true }, where: { status: { not: "CANCELLED" } } })]),
  ]);
  const [users, orders, gmv] = stats;

  return (
    <div className="container-pp space-y-10 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <h1 className="font-display text-3xl font-bold">Admin</h1>
        <div className="flex gap-6 text-sm">
          <span><strong className="font-display text-xl">{users}</strong> users</span>
          <span><strong className="font-display text-xl">{orders}</strong> orders</span>
          <span><strong className="font-display text-xl">{money(gmv._sum.totalCents ?? 0)}</strong> GMV</span>
        </div>
      </div>

      <section>
        <h2 className="mb-3 font-display text-xl font-bold">Resale certificates to review ({pendingCerts.length})</h2>
        <div className="card divide-y divide-line">
          {pendingCerts.map((u) => (
            <div key={u.id} className="flex flex-wrap items-center gap-4 p-4 text-sm">
              <div className="min-w-0 flex-1"><p className="font-semibold">{u.businessName ?? u.name}</p><p className="text-xs text-muted">{u.email} · {u.businessType ?? "—"}</p></div>
              <p className="font-mono">{u.certState} · {u.certNumber}</p>
              {(["APPROVED", "REJECTED"] as const).map((s) => (
                <form key={s} action={setCertStatus}>
                  <input type="hidden" name="userId" value={u.id} />
                  <input type="hidden" name="status" value={s} />
                  <button className={s === "APPROVED" ? "btn-dark py-1.5 text-xs" : "btn-ghost py-1.5 text-xs text-rust"}>{s === "APPROVED" ? "Approve" : "Reject"}</button>
                </form>
              ))}
            </div>
          ))}
          {pendingCerts.length === 0 && <p className="p-6 text-center text-sm text-muted">Nothing to review.</p>}
        </div>
      </section>

      <div className="grid gap-8 lg:grid-cols-2">
        <section>
          <h2 className="mb-3 font-display text-xl font-bold">Sellers</h2>
          <div className="card divide-y divide-line">
            {sellers.map((s) => (
              <div key={s.id} className="flex items-center gap-3 p-3 text-sm">
                <span className="min-w-0 flex-1 truncate">{s.name} <span className="text-xs text-muted">· {s._count.lots} lots</span></span>
                <form action={setSellerVerified}>
                  <input type="hidden" name="sellerId" value={s.id} />
                  <input type="hidden" name="verified" value={s.verified ? "0" : "1"} />
                  <button className={`rounded-full px-3 py-1 text-xs font-semibold ${s.verified ? "bg-moss/10 text-moss" : "bg-sand"}`}>{s.verified ? "✓ Verified" : "Verify"}</button>
                </form>
              </div>
            ))}
          </div>
        </section>
        <section>
          <h2 className="mb-3 font-display text-xl font-bold">Featured lots</h2>
          <div className="card divide-y divide-line">
            {lots.map((l) => (
              <div key={l.id} className="flex items-center gap-3 p-3 text-sm">
                <span className="min-w-0 flex-1 truncate">{l.title} <span className="text-xs text-muted">· {l.views} views</span></span>
                <form action={toggleFeatured}>
                  <input type="hidden" name="lotId" value={l.id} />
                  <button className={`rounded-full px-3 py-1 text-xs font-semibold ${l.featured ? "bg-signal text-white" : "bg-sand"}`}>{l.featured ? "★ Featured" : "Feature"}</button>
                </form>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section>
        <h2 className="mb-3 font-display text-xl font-bold">Inbox: contact & program requests</h2>
        <div className="card divide-y divide-line">
          {inquiries.map((q) => (
            <div key={q.id} className="flex flex-wrap items-start gap-4 p-4 text-sm">
              <span className="rounded bg-sand px-2 py-0.5 text-[11px] font-bold">{q.topic}</span>
              <div className="min-w-0 flex-1">
                <p className="font-semibold">{q.name || q.email} {q.company && <span className="font-normal text-muted">· {q.company}</span>}</p>
                <p className="text-xs text-muted">{q.email} · {q.createdAt.toLocaleString()}</p>
                {q.body && <p className="mt-1 whitespace-pre-wrap">{q.body}</p>}
              </div>
              <form action={markInquiryHandled}>
                <input type="hidden" name="id" value={q.id} />
                <button className="btn-ghost py-1.5 text-xs">Mark handled</button>
              </form>
            </div>
          ))}
          {inquiries.length === 0 && <p className="p-6 text-center text-sm text-muted">Inbox zero.</p>}
        </div>
      </section>
    </div>
  );
}
