import Link from "next/link";
import { db } from "@/lib/db";
import { COLLECTIONS } from "@/lib/collections";
import { LEGAL } from "@/content/legal";
import { GUIDES } from "@/content/guides";

export const metadata = { title: "Site map" };
export const dynamic = "force-dynamic";

export default async function SiteMap() {
  const [categories, sellers] = await Promise.all([
    db.category.findMany({ orderBy: { name: "asc" }, include: { subcategories: { orderBy: { name: "asc" } } } }),
    db.seller.findMany({ orderBy: { name: "asc" }, select: { name: true, slug: true } }),
  ]);
  const groups: [string, [string, string][]][] = [
    ["Shop", [["Live auctions", "/auctions"], ["Buy Now", "/buy-now"], ["Truckloads", "/truckloads"], ["Pallets", "/pallets"], ["Case packs", "/case-packs"], ["All lots", "/lots"], ["Categories", "/categories"], ["New arrivals", "/new"], ["Trending", "/trending"], ["Collections", "/collections"], ["Sellers", "/sellers"]]],
    ["Buyers", [["How to buy & bid", "/how-to-buy"], ["My bids", "/bids"], ["Create an account", "/register"], ["Sign in", "/login"], ["Cart", "/cart"], ["Orders", "/orders"], ["Saved", "/account/favorites"], ["Messages", "/messages"], ["Account", "/account"], ["Business verification", "/account/verification"], ["Refer a business", "/account/referrals"]]],
    ["Sellers", [["Sell on PalletPort", "/sell"], ["Seller hub", "/dashboard"], ["List a pallet", "/dashboard/new"], ["Seller referrals", "/sell/refer"], ["Seller resources", "/sell/resources"]]],
    ["Programs", [["PalletPort Pro", "/pro"], ["Volume buyers", "/volume-buyers"], ["Affiliates", "/affiliates"], ["Warehouse Days", "/events"], ["Integrations", "/integrations"]]],
    ["Learn", [["How it works", "/how-it-works"], ["Help center", "/help"], ["The Loading Dock blog", "/blog"], ["Market reports", "/reports"], ["Guides", "/guides"], ...GUIDES.map((g) => [g.title, `/guides/${g.slug}`] as [string, string])]],
    ["Company", [["About", "/about"], ["Contact", "/contact"], ...LEGAL.map((l) => [l.title, `/legal/${l.slug}`] as [string, string])]],
    ["Collections", COLLECTIONS.map((c) => [c.title, `/collections/${c.slug}`])],
    ["Sellers A–Z", sellers.map((s) => [s.name, `/sellers/${s.slug}`])],
  ];
  return (
    <div className="container-pp py-10">
      <h1 className="mb-8 font-display text-3xl font-bold">Site map</h1>
      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
        {groups.map(([title, links]) => (
          <section key={title}>
            <h2 className="label">{title}</h2>
            <ul className="space-y-1.5 text-sm">{links.map(([l, h]) => <li key={h}><Link href={h} className="hover:underline">{l}</Link></li>)}</ul>
          </section>
        ))}
        <section className="sm:col-span-2 lg:col-span-4">
          <h2 className="label">Categories</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {categories.map((c) => (
              <ul key={c.id} className="space-y-1 text-sm">
                <li><Link href={`/c/${c.slug}`} className="font-semibold hover:underline">{c.name}</Link></li>
                {c.subcategories.map((s) => <li key={s.id}><Link href={`/lots?category=${c.slug}&sub=${s.slug}`} className="text-ink/75 hover:underline">{s.name}</Link></li>)}
              </ul>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
