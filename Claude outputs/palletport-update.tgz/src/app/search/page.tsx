import { LotBrowser, type SearchParams } from "@/components/browse/LotBrowser";

export async function generateMetadata({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const q = (await searchParams).q;
  return { title: q ? `Search: ${Array.isArray(q) ? q[0] : q}` : "Search all lots" };
}

// Search results page: every auction and Buy Now lot, with the full filter sidebar.
export default async function SearchPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const sp = await searchParams;
  const q = (Array.isArray(sp.q) ? sp.q[0] : sp.q)?.trim();
  return <LotBrowser sp={sp} basePath="/search" heading={q ? `Results for “${q}”` : "Search all lots"} />;
}
