import Link from "next/link";
import { LOT_SIZES, money } from "@/lib/format";

export const metadata = { title: "How to buy & bid" };

const INCREMENTS: [string, number][] = [
  ["Under $100", 500],
  ["$100 – $499", 1000],
  ["$500 – $999", 2500],
  ["$1,000 – $4,999", 5000],
  ["$5,000 – $24,999", 10000],
  ["$25,000 and up", 25000],
];

export default function HowToBuy() {
  return (
    <>
      <section className="bg-ink text-white">
        <div className="container-pp py-14">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-signal">Buyer guide</p>
          <h1 className="mt-2 font-display text-4xl font-bold sm:text-5xl">How to buy & bid</h1>
          <p className="mt-3 max-w-2xl text-white/70">Everything you need to win your first lot: proxy bidding, soft close, paying for what you win, and getting it delivered.</p>
        </div>
        <div className="stripe h-2" />
      </section>

      <div className="container-pp grid gap-12 py-12 lg:grid-cols-[1fr_320px]">
        <div className="space-y-12">
          <section>
            <h2 className="font-display text-2xl font-bold">1. Two ways to buy</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div className="card p-5">
                <span className="rounded-md bg-ink px-2 py-1 text-[11px] font-bold uppercase text-white">Auction</span>
                <p className="mt-3 text-sm text-ink/80">Bid until the timer runs out. The highest bidder wins and pays their winning bid plus freight. Some auctions also offer a <strong>Buy it now</strong> price that ends the auction immediately.</p>
              </div>
              <div className="card p-5">
                <span className="rounded-md bg-signal px-2 py-1 text-[11px] font-bold uppercase text-white">Buy Now</span>
                <p className="mt-3 text-sm text-ink/80">Fixed-price lots. Add to cart and check out like any online store — sometimes several identical lots are available.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="font-display text-2xl font-bold">2. How proxy bidding works</h2>
            <p className="mt-3 text-ink/80">Enter the most you're willing to pay. We keep your maximum private and bid for you, one increment at a time, only as high as needed to keep you in the lead.</p>
            <div className="card mt-4 space-y-2 p-5 text-sm">
              <p className="font-semibold">Example</p>
              <p>Current bid is $400. You enter a maximum of $800 — the bid moves to $410 and you're winning.</p>
              <p>Another buyer bids $600. We automatically bid $610 for you. You're still winning.</p>
              <p>A third buyer enters $900. They beat your $800 maximum, so the bid moves to $825 and you're notified you've been outbid.</p>
            </div>
            <h3 className="mt-6 font-display text-lg font-bold">Bid increments</h3>
            <table className="mt-2 w-full max-w-md text-sm">
              <tbody className="divide-y divide-line">
                {INCREMENTS.map(([range, inc]) => (
                  <tr key={range}><td className="py-2">{range}</td><td className="py-2 text-right font-semibold">{money(inc)}</td></tr>
                ))}
              </tbody>
            </table>
          </section>

          <section>
            <h2 className="font-display text-2xl font-bold">3. Soft close</h2>
            <p className="mt-3 text-ink/80">If a bid lands in the final two minutes, the auction extends by two minutes. There's no advantage to sniping — enter your true maximum early.</p>
          </section>

          <section>
            <h2 className="font-display text-2xl font-bold">4. After you win</h2>
            <ul className="mt-3 list-disc space-y-1.5 pl-5 text-ink/80 marker:text-signal">
              <li>You'll find the lot under <Link href="/bids?tab=won" className="font-semibold text-signal-dark">My bids → Won</Link>.</li>
              <li>Confirm your delivery address and pay within <strong>3 days</strong> by card, wire/ACH, or Net 30 (verified resellers).</li>
              <li>The seller books freight and adds a tracking (PRO) number. Most pallets arrive in 3–7 business days.</li>
              <li>Unpaid lots may be offered to the next bidder and can affect your ability to bid.</li>
            </ul>
          </section>

          <section>
            <h2 className="font-display text-2xl font-bold">5. Lot sizes & shipping</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              {Object.entries(LOT_SIZES).map(([k, v]) => (
                <div key={k} className="card p-5">
                  <p className="font-display text-lg font-bold">{v.plural}</p>
                  <p className="mt-1 text-sm text-muted">{v.note}</p>
                </div>
              ))}
            </div>
            <p className="mt-4 text-sm text-ink/80">Pallet freight is estimated at {money(17500)} per pallet and free on orders over {money(750000)}. Truckloads are quoted per trailer. Many sellers offer free local pickup.</p>
          </section>
        </div>

        <aside className="space-y-4 lg:sticky lg:top-40 lg:h-fit">
          <div className="card p-5">
            <p className="font-display text-lg font-bold">Ready to bid?</p>
            <p className="mt-1 text-sm text-muted">Create a free business account in under a minute.</p>
            <Link href="/register" className="btn-primary mt-4 w-full">Register to bid</Link>
            <Link href="/auctions?ending=today" className="btn-ghost mt-2 w-full">Auctions ending today</Link>
          </div>
          <div className="rounded-2xl bg-sand p-5 text-sm">
            <p className="font-semibold">Tips from experienced buyers</p>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-ink/80">
              <li>Price in freight before you bid.</li>
              <li>Check the top five manifest lines — they carry most of the value.</li>
              <li>Compare with <Link href="/lots?sold=1" className="font-semibold text-signal-dark">recently sold</Link> lots.</li>
            </ul>
          </div>
        </aside>
      </div>
    </>
  );
}
