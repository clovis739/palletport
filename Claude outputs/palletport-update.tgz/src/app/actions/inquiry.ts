"use server";

import { z } from "zod";
import { db } from "@/lib/db";
import { LIMITS, clientIp, rateLimit } from "@/lib/rateLimit";

export type InquiryState = { error?: string; ok?: string } | undefined;

const schema = z.object({
  topic: z.enum(["CONTACT", "NEWSLETTER", "PRO", "VOLUME", "AFFILIATE", "EVENTS", "INTEGRATIONS"]),
  email: z.string().trim().toLowerCase().email("Enter a valid email"),
  name: z.string().trim().optional().default(""),
  company: z.string().trim().optional().default(""),
  body: z.string().trim().optional().default(""),
});

/** Shared handler for the contact form, newsletter box and program applications. */
export async function submitInquiry(_: InquiryState, formData: FormData): Promise<InquiryState> {
  const rl = rateLimit(`inquiry:${await clientIp()}`, LIMITS.inquiry.max, LIMITS.inquiry.windowMs);
  if (!rl.ok) return { error: rl.message };
  const parsed = schema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  await db.inquiry.create({ data: parsed.data });
  // TODO(email): notify the team inbox.
  return {
    ok: parsed.data.topic === "NEWSLETTER" ? "You're on the list. Watch your inbox on Mondays." : "Thanks — we'll be in touch within one business day.",
  };
}
