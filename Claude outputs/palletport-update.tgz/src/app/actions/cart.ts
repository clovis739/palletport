"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { purchasePrice } from "@/lib/format";

export async function addToCart(formData: FormData) {
  const lotId = String(formData.get("lotId"));
  const qty = Math.max(1, Number(formData.get("quantity") ?? 1));
  const session = await getSession();
  const lot = await db.lot.findUnique({ where: { id: lotId } });
  if (!lot) return;
  if (!session) redirect(`/login?next=/lots/${lot.slug}`);
  if (purchasePrice(lot) === null) return;

  const existing = await db.cartItem.findUnique({
    where: { userId_lotId: { userId: session.userId, lotId } },
  });
  const quantity = lot.saleType === "AUCTION" ? 1 : Math.min(lot.available, (existing?.quantity ?? 0) + qty);
  await db.cartItem.upsert({
    where: { userId_lotId: { userId: session.userId, lotId } },
    create: { userId: session.userId, lotId, quantity },
    update: { quantity },
  });
  revalidatePath("/", "layout");
  redirect("/cart");
}

export async function updateCartItem(formData: FormData) {
  const session = await getSession();
  if (!session) redirect("/login?next=/cart");
  const id = String(formData.get("id"));
  const quantity = Number(formData.get("quantity"));
  const item = await db.cartItem.findFirst({ where: { id, userId: session.userId }, include: { lot: true } });
  if (!item) return;
  if (quantity <= 0) {
    await db.cartItem.delete({ where: { id } });
  } else {
    await db.cartItem.update({ where: { id }, data: { quantity: Math.min(quantity, item.lot.available) } });
  }
  revalidatePath("/", "layout");
}
