"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { placeBid } from "@/lib/auctions";
import { LIMITS, rateLimit } from "@/lib/rateLimit";

export type BidState = { error?: string; ok?: string } | undefined;

export async function bidAction(_: BidState, formData: FormData): Promise<BidState> {
  const lotId = String(formData.get("lotId"));
  const session = await getSession();
  if (!session) {
    const lot = await db.lot.findUnique({ where: { id: lotId }, select: { slug: true } });
    redirect(`/login?next=${encodeURIComponent(`/lots/${lot?.slug ?? ""}`)}`);
  }
  const rl = rateLimit(`bid:${session.userId}`, LIMITS.bid.max, LIMITS.bid.windowMs);
  if (!rl.ok) return { error: rl.message };
  const dollars = Number(String(formData.get("max") ?? "").replace(/[$,\s]/g, ""));
  if (!Number.isFinite(dollars) || dollars <= 0) return { error: "Enter a bid amount" };


  const result = await placeBid(lotId, session.userId, Math.round(dollars * 100));
  const lot = await db.lot.findUnique({ where: { id: lotId }, select: { slug: true } });
  if (lot) revalidatePath(`/lots/${lot.slug}`);
  revalidatePath("/bids");
  if (!result.ok) return { error: result.error };
  return { ok: result.message };
}

