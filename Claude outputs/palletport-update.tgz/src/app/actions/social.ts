"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import type { FormState } from "./auth";
import { LIMITS, rateLimit } from "@/lib/rateLimit";

export async function toggleFavorite(formData: FormData) {
  const lotId = String(formData.get("lotId"));
  const back = String(formData.get("back") ?? "/");
  const session = await getSession();
  if (!session) redirect(`/login?next=${encodeURIComponent(back)}`);
  const key = { userId_lotId: { userId: session.userId, lotId } };
  const existing = await db.favorite.findUnique({ where: key });
  if (existing) await db.favorite.delete({ where: key });
  else await db.favorite.create({ data: { userId: session.userId, lotId } });
  revalidatePath(back);
  revalidatePath("/account/favorites");
}

export async function toggleFollow(formData: FormData) {
  const sellerId = String(formData.get("sellerId"));
  const back = String(formData.get("back") ?? "/");
  const session = await getSession();
  if (!session) redirect(`/login?next=${encodeURIComponent(back)}`);
  const key = { userId_sellerId: { userId: session.userId, sellerId } };
  const existing = await db.follow.findUnique({ where: key });
  if (existing) await db.follow.delete({ where: key });
  else await db.follow.create({ data: { userId: session.userId, sellerId } });
  revalidatePath(back);
  revalidatePath("/account/favorites");
}

/** Buyer starts (or continues) a conversation with a seller. */
export async function contactSeller(formData: FormData) {
  const sellerId = String(formData.get("sellerId"));
  const subject = String(formData.get("subject") ?? "").trim() || "General question";
  const session = await getSession();
  if (!session) redirect(`/login?next=/messages`);
  const seller = await db.seller.findUnique({ where: { id: sellerId } });
  if (!seller || seller.userId === session.userId) redirect("/messages");
  const convo = await db.conversation.upsert({
    where: { buyerId_sellerId: { buyerId: session.userId, sellerId } },
    create: { buyerId: session.userId, sellerId, subject },
    update: {},
  });
  redirect(`/messages/${convo.id}`);
}

const msgSchema = z.object({ conversationId: z.string(), body: z.string().trim().min(1, "Write a message").max(4000) });

export async function sendMessage(_: FormState, formData: FormData): Promise<FormState> {
  const session = await getSession();
  if (!session) redirect("/login?next=/messages");
  const rl = rateLimit(`msg:${session.userId}`, LIMITS.message.max, LIMITS.message.windowMs);
  if (!rl.ok) return { error: rl.message };
  const parsed = msgSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const convo = await db.conversation.findUnique({ where: { id: parsed.data.conversationId }, include: { seller: true } });
  if (!convo || (convo.buyerId !== session.userId && convo.seller.userId !== session.userId)) return { error: "Conversation not found" };
  await db.message.create({ data: { conversationId: convo.id, senderId: session.userId, body: parsed.data.body } });
  await db.conversation.update({ where: { id: convo.id }, data: { updatedAt: new Date() } });
  revalidatePath(`/messages/${convo.id}`);
  return { error: undefined };
}
