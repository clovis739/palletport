import Link from "next/link";
import { notFound } from "next/navigation";
import { LEGAL } from "@/content/legal";
import { Prose } from "@/components/Prose";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  return { title: LEGAL.find((l) => l.slug === slug)?.title ?? "Legal" };
}

export default async function LegalPage({ params }: { params: Params }) {
  const { slug } = await params;
  const doc = LEGAL.find((l) => l.slug === slug);
  if (!doc) notFound();
  return (
    <div className="container-pp grid gap-10 py-10 lg:grid-cols-[220px_1fr]">
      <aside>
        <p className="label">Policies</p>
        <nav className="flex flex-col gap-1 text-sm">
          {LEGAL.map((l) => (
            <Link key={l.slug} href={`/legal/${l.slug}`} className={`rounded-lg px-3 py-1.5 ${l.slug === slug ? "bg-sand font-semibold" : "hover:bg-sand"}`}>{l.title}</Link>
          ))}
        </nav>
      </aside>
      <article className="max-w-2xl">
        <h1 className="font-display text-3xl font-bold">{doc.title}</h1>
        <p className="mb-8 mt-1 text-sm text-muted">Last updated {new Date(doc.date!).toLocaleDateString("en-US", { dateStyle: "long" })}</p>
        <Prose body={doc.body} />
      </article>
    </div>
  );
}
