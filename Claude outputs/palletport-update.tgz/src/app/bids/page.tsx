import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { settleAuctions } from "@/lib/auctions";
import { money } from "@/lib/format";
import { PalletArt } from "@/components/PalletArt";
import { Countdown } from "@/components/Countdown";
import { AccountShell } from "../account/AccountNav";

export const metadata = { title: "My bids" };

const TABS = [
  ["active", "Active bids"],
  ["won", "Won"],
  ["lost", "Didn't win"],
] as const;

export default async function MyBids({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const { tab = "active" } = await searchParams;
  const u = await requireUser("/bids");
  await settleAuctions();

  const lotIds = (await db.bid.findMany({ where: { userId: u.id }, distinct: ["lotId"], select: { lotId: true } })).map((b) => b.lotId);
  const [lots, myMax, wonOrders] = await Promise.all([
    db.lot.findMany({ where: { id: { in: lotIds } }, include: { category: true }, orderBy: { endsAt: "asc" } }),
    db.bid.groupBy({ by: ["lotId"], where: { userId: u.id }, _max: { maxCents: true, amountCents: true } }),
    db.order.findMany({ where: { userId: u.id, fromAuction: true }, include: { items: { include: { lot: { include: { category: true } } } } }, orderBy: { createdAt: "desc" } }),
  ]);
  const maxOf = new Map<string, number>(myMax.map((m) => [m.lotId, m._max.maxCents ?? m._max.amountCents ?? 0]));
  const wonLotIds = new Set(wonOrders.flatMap((o) => o.items.map((i) => i.lotId)));
  const active = lots.filter((l) => l.status === "ACTIVE");
  const lost = lots.filter((l) => l.status !== "ACTIVE" && !wonLotIds.has(l.id));
  const awaiting = wonOrders.filter((o) => o.status === "AWAITING_PAYMENT").length;

  return (
    <AccountShell active="/bids" title="My bids">
      <div className="mb-6 flex gap-1 overflow-x-auto">
        {TABS.map(([k, label]) => (
          <Link key={k} href={`/bids?tab=${k}`} className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold ${tab === k ? "bg-ink text-white" : "border border-line bg-white"}`}>
            {label}
            <span className="ml-1.5 opacity-70">{k === "active" ? active.length : k === "won" ? wonOrders.length : lost.length}</span>
            {k === "won" && awaiting > 0 && <span className="ml-1.5 rounded-full bg-signal px-1.5 text-[11px] text-white">{awaiting} to pay</span>}
          </Link>
        ))}
      </div>

      {tab === "active" && (
        active.length === 0 ? (
          <Empty text="You have no active bids." />
        ) : (
          <ul className="space-y-3">
            {active.map((l) => {
              const leading = l.leaderId === u.id;
              return (
                <li key={l.id} className="card flex flex-wrap items-center gap-4 p-4">
                  <Link href={`/lots/${l.slug}`} className="w-24 shrink-0 overflow-hidden rounded-lg border border-line"><PalletArt seed={l.slug} hue={l.category.hue} className="w-full" /></Link>
                  <div className="min-w-0 flex-1">
                    <Link href={`/lots/${l.slug}`} className="font-semibold hover:underline">{l.title}</Link>
                    <p className="text-xs text-muted">{l.bidCount} bids · your max {money(maxOf.get(l.id) ?? 0)}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-lg font-bold">{money(l.priceCents)}</p>
                    {l.endsAt && <Countdown endsAt={l.endsAt.toISOString()} compact className="text-xs" />}
                  </div>
                  <span className={`rounded-full px-3 py-1 text-xs font-bold ${leading ? "bg-moss/10 text-moss" : "bg-rust/10 text-rust"}`}>{leading ? "Winning" : "Outbid"}</span>
                  {!leading && <Link href={`/lots/${l.slug}`} className="btn-primary py-2 text-xs">Bid again</Link>}
                </li>
              );
            })}
          </ul>
        )
      )}

      {tab === "won" && (
        wonOrders.length === 0 ? (
          <Empty text="Auctions you win show up here." />
        ) : (
          <ul className="space-y-3">
            {wonOrders.map((o) => {
              const item = o.items[0];
              return (
                <li key={o.id} className="card flex flex-wrap items-center gap-4 p-4">
                  <div className="w-24 shrink-0 overflow-hidden rounded-lg border border-line"><PalletArt seed={item.lot.slug} hue={item.lot.category.hue} className="w-full" /></div>
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">{item.title}</p>
                    <p className="text-xs text-muted">Won for {money(item.priceCents)} · order {o.number}</p>
                    {o.status === "AWAITING_PAYMENT" && o.payBy && <p className="text-xs font-semibold text-rust">Pay by {o.payBy.toLocaleDateString()}</p>}
                  </div>
                  {o.status === "AWAITING_PAYMENT" ? (
                    <Link href={`/orders/${o.id}`} className="btn-primary py-2 text-xs">Pay now</Link>
                  ) : (
                    <Link href={`/orders/${o.id}`} className="btn-ghost py-2 text-xs">View order</Link>
                  )}
                </li>
              );
            })}
          </ul>
        )
      )}

      {tab === "lost" && (
        lost.length === 0 ? (
          <Empty text="Nothing here." />
        ) : (
          <ul className="card divide-y divide-line">
            {lost.map((l) => (
              <li key={l.id} className="flex items-center justify-between gap-4 p-4 text-sm">
                <Link href={`/lots/${l.slug}`} className="min-w-0 truncate hover:underline">{l.title}</Link>
                <span className="shrink-0 text-muted">{l.status === "ENDED" ? "Ended without a winner" : `Sold for ${money(l.priceCents)}`}</span>
              </li>
            ))}
          </ul>
        )
      )}
    </AccountShell>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <div className="card p-10 text-center">
      <p className="text-sm text-muted">{text}</p>
      <Link href="/auctions" className="btn-primary mt-4">Browse live auctions</Link>
    </div>
  );
}
