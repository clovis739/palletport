import Link from "next/link";
import { notFound } from "next/navigation";
import { requireSeller } from "@/lib/auth";
import { db } from "@/lib/db";
import { deleteLot, updateLot } from "@/app/actions/seller";
import { LotForm } from "../../LotForm";

export const metadata = { title: "Edit lot" };

export default async function EditLotPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { seller } = await requireSeller();
  const [lot, categories] = await Promise.all([
    db.lot.findFirst({ where: { id, sellerId: seller.id }, include: { manifest: true } }),
    db.category.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, subcategories: { select: { id: true, name: true }, orderBy: { name: "asc" } } } }),
  ]);
  if (!lot) notFound();
  const manifest = lot.manifest.map((m) => `${m.name.replace(/,/g, " ")}, ${m.qty}, ${(m.unitMsrpCents / 100).toFixed(2)}, ${m.sku}`).join("\n");

  return (
    <>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <Link href="/dashboard/lots" className="text-xs text-muted hover:underline">← All lots</Link>
          <h1 className="font-display text-3xl font-bold">Edit lot</h1>
        </div>
        <div className="flex gap-2">
          <Link href={`/lots/${lot.slug}`} className="btn-ghost">View listing</Link>
          <form action={deleteLot}>
            <input type="hidden" name="id" value={lot.id} />
            <button className="btn-ghost text-rust">Delete</button>
          </form>
        </div>
      </div>
      {lot.saleType === "AUCTION" && lot.bidCount > 0 && (
        <p className="mb-4 max-w-3xl rounded-xl bg-amber-100 p-4 text-sm text-amber-900">This auction has {lot.bidCount} bids and can no longer be edited.</p>
      )}
      {lot.status === "ENDED" && (
        <p className="mb-4 max-w-3xl rounded-xl bg-sand p-4 text-sm">This auction ended without a winner. Adjust the starting bid if you like and save to relist it.</p>
      )}
      <div className="max-w-3xl">
        <LotForm
          categories={categories}
          action={updateLot}
          submitLabel={lot.status === "ENDED" ? "Relist auction" : "Save changes"}
          defaults={{
            id: lot.id,
            title: lot.title,
            description: lot.description,
            categoryId: lot.categoryId,
            subcategoryId: lot.subcategoryId,
            condition: lot.condition,
            price: (lot.saleType === "AUCTION" ? lot.startPriceCents ?? lot.priceCents : lot.priceCents) / 100,
            saleType: lot.saleType,
            lotSize: lot.lotSize,
            source: lot.source,
            buyNow: lot.buyNowCents ? lot.buyNowCents / 100 : null,
            palletCount: lot.palletCount,
            weightLbs: lot.weightLbs,
            available: lot.available,
            manifest,
          }}
        />
      </div>
    </>
  );
}
