"use client";

import { useActionState, useState } from "react";
import { SubmitButton } from "@/components/SubmitButton";
import { CONDITIONS, LOT_SIZES, SOURCES } from "@/lib/format";

type Cat = { id: string; name: string; subcategories: { id: string; name: string }[] };
type State = { error?: string } | undefined;
export type LotDefaults = {
  id?: string;
  title?: string;
  description?: string;
  categoryId?: string;
  subcategoryId?: string | null;
  condition?: string;
  price?: number;
  palletCount?: number;
  weightLbs?: number;
  available?: number;
  manifest?: string;
  saleType?: string;
  lotSize?: string;
  source?: string;
  buyNow?: number | null;
};

export function LotForm({
  categories,
  action,
  defaults = {},
  submitLabel,
}: {
  categories: Cat[];
  action: (s: State, fd: FormData) => Promise<State>;
  defaults?: LotDefaults;
  submitLabel: string;
}) {
  const [state, formAction] = useActionState(action, undefined);
  const [catId, setCatId] = useState(defaults.categoryId ?? "");
  const subs = categories.find((c) => c.id === catId)?.subcategories ?? [];
  const [saleType, setSaleType] = useState(defaults.saleType ?? "AUCTION");
  const auction = saleType === "AUCTION";

  return (
    <form action={formAction} className="card space-y-5 p-6">
      {defaults.id && <input type="hidden" name="id" value={defaults.id} />}
      <fieldset>
        <legend className="label">How do you want to sell?</legend>
        <div className="grid gap-3 sm:grid-cols-2">
          {[
            ["AUCTION", "Auction", "Buyers bid until the timer ends. Optional Buy Now price."],
            ["BUY_NOW", "Fixed price", "Sell at a set price; list several identical lots."],
          ].map(([v, t, d]) => (
            <label key={v} className={`cursor-pointer rounded-xl border p-4 ${saleType === v ? "border-ink bg-sand/50" : "border-line"}`}>
              <input type="radio" name="saleType" value={v} checked={saleType === v} onChange={() => setSaleType(v)} className="sr-only" />
              <span className="block font-semibold">{t}</span>
              <span className="text-xs text-muted">{d}</span>
            </label>
          ))}
        </div>
      </fieldset>
      <div><label className="label" htmlFor="title">Title</label><input id="title" name="title" defaultValue={defaults.title} className="input" placeholder="e.g. Small Kitchen Appliances Pallet" required /></div>
      <div className="grid gap-4 sm:grid-cols-3">
        <div>
          <label className="label" htmlFor="categoryId">Category</label>
          <select id="categoryId" name="categoryId" className="input" required value={catId} onChange={(e) => setCatId(e.target.value)}>
            <option value="" disabled>Choose…</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="subcategoryId">Subcategory</label>
          <select id="subcategoryId" name="subcategoryId" className="input" defaultValue={defaults.subcategoryId ?? ""} key={catId}>
            <option value="">None</option>
            {subs.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="condition">Condition</label>
          <select id="condition" name="condition" className="input" required defaultValue={defaults.condition ?? "CUSTOMER_RETURN"}>
            {Object.entries(CONDITIONS).map(([k, c]) => <option key={k} value={k}>{c.label}</option>)}
          </select>
        </div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="lotSize">Lot size</label>
          <select id="lotSize" name="lotSize" className="input" defaultValue={defaults.lotSize ?? "PALLET"}>
            {Object.entries(LOT_SIZES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="source">Source</label>
          <select id="source" name="source" className="input" defaultValue={defaults.source ?? ""}>
            <option value="">Not specified</option>
            {SOURCES.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>
      {auction && (
        <div className="grid gap-4 rounded-xl bg-sand/50 p-4 sm:grid-cols-3">
          <div><label className="label" htmlFor="price">Starting bid (USD)</label><input id="price" name="price" type="number" min={1} step="1" defaultValue={defaults.price} className="input" required /></div>
          <div><label className="label" htmlFor="buyNow">Buy Now price (optional)</label><input id="buyNow" name="buyNow" type="number" min={0} step="1" defaultValue={defaults.buyNow ?? ""} className="input" /></div>
          <div>
            <label className="label" htmlFor="durationDays">Duration</label>
            <select id="durationDays" name="durationDays" className="input" defaultValue="3">
              {[1, 2, 3, 5, 7, 10].map((d) => <option key={d} value={d}>{d} day{d > 1 ? "s" : ""}</option>)}
            </select>
          </div>
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-4">
        {!auction && <div><label className="label" htmlFor="price">Price (USD)</label><input id="price" name="price" type="number" min={1} step="1" defaultValue={defaults.price} className="input" required /></div>}
        <div><label className="label" htmlFor="palletCount">Pallets</label><input id="palletCount" name="palletCount" type="number" min={1} max={26} defaultValue={defaults.palletCount ?? 1} className="input" required /></div>
        <div><label className="label" htmlFor="weightLbs">Weight (lbs)</label><input id="weightLbs" name="weightLbs" type="number" min={1} defaultValue={defaults.weightLbs} className="input" required /></div>
        {!auction && <div><label className="label" htmlFor="available">Qty of lot</label><input id="available" name="available" type="number" min={1} defaultValue={defaults.available ?? 1} className="input" required /></div>}
      </div>
      <div><label className="label" htmlFor="description">Description</label><textarea id="description" name="description" rows={4} defaultValue={defaults.description} className="input" placeholder="Source, packaging, grading notes, pickup options…" required /></div>
      <div>
        <label className="label" htmlFor="manifest">Manifest</label>
        <textarea id="manifest" name="manifest" rows={8} defaultValue={defaults.manifest} className="input font-mono text-xs" placeholder={"Air fryer 5qt, 24, 89.99, SKU-001\nStand blender, 18, 69\nElectric kettle, 40, 34.50"} required />
        <p className="mt-1 text-xs text-muted">One line per item: <code>name, quantity, unit MSRP[, SKU]</code>. Paste rows from a spreadsheet saved as CSV.</p>
      </div>
      {state?.error && <p className="rounded-lg bg-rust/10 p-3 text-sm font-medium text-rust">{state.error}</p>}
      <SubmitButton className="btn-primary w-full py-3" pendingText="Saving…">{submitLabel}</SubmitButton>
    </form>
  );
}
