import { requireSeller } from "@/lib/auth";
import { db } from "@/lib/db";
import { money } from "@/lib/format";

export const metadata = { title: "Payouts · Seller hub" };

const COMMISSION = 0.1;

export default async function Payouts() {
  const { seller } = await requireSeller();
  const [payouts, pendingItems] = await Promise.all([
    db.payout.findMany({ where: { sellerId: seller.id }, orderBy: { arrivesAt: "desc" } }),
    db.orderItem.findMany({ where: { sellerId: seller.id, order: { status: { in: ["PENDING", "CONFIRMED", "SHIPPED"] } } } }),
  ]);
  const inTransit = pendingItems.reduce((a, i) => a + i.priceCents * i.quantity, 0);
  const scheduled = payouts.filter((p) => p.status === "SCHEDULED").reduce((a, p) => a + p.amountCents, 0);
  const paid = payouts.filter((p) => p.status === "PAID").reduce((a, p) => a + p.amountCents, 0);

  return (
    <>
      <h1 className="mb-2 font-display text-3xl font-bold">Payouts</h1>
      <p className="mb-6 text-sm text-muted">Payouts are sent two business days after an order is marked delivered, minus a {COMMISSION * 100}% marketplace commission.</p>
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <div className="card p-5"><p className="text-xs text-muted">On open orders (gross)</p><p className="font-display text-2xl font-bold">{money(inTransit)}</p></div>
        <div className="card p-5"><p className="text-xs text-muted">Scheduled</p><p className="font-display text-2xl font-bold">{money(scheduled)}</p></div>
        <div className="card p-5"><p className="text-xs text-muted">Paid to date</p><p className="font-display text-2xl font-bold">{money(paid)}</p></div>
      </div>
      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-sand/60 text-left text-xs uppercase tracking-wider text-muted"><tr><th className="px-4 py-3">Date</th><th className="px-4 py-3">Status</th><th className="px-4 py-3 text-right">Amount</th></tr></thead>
          <tbody className="divide-y divide-line">
            {payouts.map((p) => (
              <tr key={p.id}>
                <td className="px-4 py-3">{p.arrivesAt.toLocaleDateString()}</td>
                <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${p.status === "PAID" ? "bg-moss/10 text-moss" : "bg-sky-100 text-sky-800"}`}>{p.status === "PAID" ? "Paid" : "Scheduled"}</span></td>
                <td className="px-4 py-3 text-right font-semibold">{money(p.amountCents, { cents: true })}</td>
              </tr>
            ))}
            {payouts.length === 0 && <tr><td colSpan={3} className="p-8 text-center text-muted">No payouts yet.</td></tr>}
          </tbody>
        </table>
      </div>
      <p className="mt-4 rounded-xl bg-sand p-4 text-xs text-ink/75">Bank account setup: connect Stripe Connect (see README) to send real payouts. Until then, payouts are tracked here for reconciliation.</p>
    </>
  );
}
