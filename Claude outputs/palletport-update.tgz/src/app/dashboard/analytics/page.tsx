import { requireSeller } from "@/lib/auth";
import { db } from "@/lib/db";
import { money } from "@/lib/format";

export const metadata = { title: "Analytics · Seller hub" };

export default async function Analytics() {
  const { seller } = await requireSeller();
  const since = new Date(Date.now() - 30 * 86400000);
  const [items, lots, favs] = await Promise.all([
    db.orderItem.findMany({ where: { sellerId: seller.id, order: { createdAt: { gte: since }, status: { not: "CANCELLED" } } }, include: { order: { select: { createdAt: true, userId: true } }, lot: { select: { category: { select: { name: true } } } } } }),
    db.lot.findMany({ where: { sellerId: seller.id }, select: { id: true, title: true, views: true, _count: { select: { orderItems: true, favorites: true } } }, orderBy: { views: "desc" }, take: 8 }),
    db.favorite.count({ where: { lot: { sellerId: seller.id } } }),
  ]);

  const days = Array.from({ length: 30 }, (_, i) => {
    const d = new Date(Date.now() - (29 - i) * 86400000);
    return { key: d.toISOString().slice(0, 10), label: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }), cents: 0 };
  });
  for (const i of items) {
    const k = i.order.createdAt.toISOString().slice(0, 10);
    const d = days.find((x) => x.key === k);
    if (d) d.cents += i.priceCents * i.quantity;
  }
  const max = Math.max(1, ...days.map((d) => d.cents));
  const total = days.reduce((a, d) => a + d.cents, 0);
  const orders = new Set(items.map((i) => i.orderId)).size;
  const buyers = new Set(items.map((i) => i.order.userId)).size;
  const byCat = new Map<string, number>();
  for (const i of items) byCat.set(i.lot.category.name, (byCat.get(i.lot.category.name) ?? 0) + i.priceCents * i.quantity);
  const totalViews = lots.reduce((a, l) => a + l.views, 0);

  return (
    <>
      <h1 className="mb-6 font-display text-3xl font-bold">Analytics <span className="text-base font-normal text-muted">· last 30 days</span></h1>
      <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[["Sales", money(total)], ["Orders", String(orders)], ["Avg. order", money(orders ? Math.round(total / orders) : 0)], ["Unique buyers", String(buyers)]].map(([k, v]) => (
          <div key={k} className="card p-5"><p className="text-xs text-muted">{k}</p><p className="font-display text-2xl font-bold">{v}</p></div>
        ))}
      </div>

      <section className="card mb-6 p-5">
        <h2 className="mb-4 font-display font-bold">Daily sales</h2>
        <div className="flex h-48 items-end gap-1" role="img" aria-label="Bar chart of daily sales over the last 30 days">
          {days.map((d) => (
            <div key={d.key} className="group relative flex-1">
              <div className="w-full rounded-t bg-signal/80 transition group-hover:bg-signal" style={{ height: `${Math.max(2, (d.cents / max) * 176)}px` }} />
              <div className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-1 hidden -translate-x-1/2 whitespace-nowrap rounded bg-ink px-2 py-1 text-[11px] text-white group-hover:block">
                {d.label}: {money(d.cents)}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-2 flex justify-between text-[11px] text-muted"><span>{days[0].label}</span><span>{days[29].label}</span></div>
      </section>

      <div className="grid gap-6 xl:grid-cols-2">
        <section className="card p-5">
          <h2 className="mb-3 font-display font-bold">Top lots by views</h2>
          <p className="mb-3 text-xs text-muted">{totalViews.toLocaleString()} views · {favs} saves across all lots</p>
          <table className="w-full text-sm">
            <thead className="text-left text-xs text-muted"><tr><th className="pb-2">Lot</th><th className="pb-2 text-right">Views</th><th className="pb-2 text-right">Saves</th><th className="pb-2 text-right">Sold</th></tr></thead>
            <tbody className="divide-y divide-line">
              {lots.map((l) => (
                <tr key={l.id}><td className="max-w-[16rem] truncate py-2">{l.title}</td><td className="py-2 text-right">{l.views}</td><td className="py-2 text-right">{l._count.favorites}</td><td className="py-2 text-right">{l._count.orderItems}</td></tr>
              ))}
            </tbody>
          </table>
        </section>
        <section className="card p-5">
          <h2 className="mb-3 font-display font-bold">Sales by category</h2>
          {byCat.size === 0 ? <p className="text-sm text-muted">No sales in this period.</p> : (
            <ul className="space-y-3">
              {[...byCat.entries()].sort((a, b) => b[1] - a[1]).map(([name, cents]) => (
                <li key={name}>
                  <div className="flex justify-between text-sm"><span>{name}</span><span className="font-semibold">{money(cents)}</span></div>
                  <div className="mt-1 h-2 rounded-full bg-sand"><div className="h-full rounded-full bg-ink" style={{ width: `${(cents / total) * 100}%` }} /></div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </>
  );
}
