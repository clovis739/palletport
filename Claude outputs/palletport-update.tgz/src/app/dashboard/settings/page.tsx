import { requireSeller } from "@/lib/auth";
import { updateStore } from "@/app/actions/seller";
import { ActionForm } from "@/components/forms/ActionForm";
import { BADGES, parseBadges } from "@/lib/format";

export const metadata = { title: "Store settings · Seller hub" };

const HUES = [215, 24, 330, 45, 150, 280, 0, 90];

export default async function StoreSettings() {
  const { seller } = await requireSeller();
  const badges = parseBadges(seller.badges);
  return (
    <>
      <h1 className="mb-6 font-display text-3xl font-bold">Store settings</h1>
      <div className="card max-w-2xl p-6">
        <ActionForm action={updateStore} submitLabel="Save storefront" successText="Storefront updated">
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="name">Store name</label><input id="name" name="name" defaultValue={seller.name} className="input" required /></div>
            <div><label className="label" htmlFor="location">Warehouse location</label><input id="location" name="location" defaultValue={seller.location} className="input" required /></div>
          </div>
          <div><label className="label" htmlFor="bio">About your inventory</label><textarea id="bio" name="bio" rows={4} defaultValue={seller.bio} className="input" required /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="minOrder">Minimum order ($)</label><input id="minOrder" name="minOrder" type="number" min={0} defaultValue={seller.minOrderCents / 100} className="input" /></div>
            <label className="mt-6 flex items-center gap-2 text-sm"><input type="checkbox" name="pickup" defaultChecked={seller.pickup} className="accent-signal" /> Buyers can pick up at my dock</label>
          </div>
          <fieldset>
            <legend className="label">Banner color</legend>
            <div className="flex flex-wrap gap-2">
              {HUES.map((h) => (
                <label key={h} className="cursor-pointer">
                  <input type="radio" name="bannerHue" value={h} defaultChecked={seller.bannerHue === h} className="peer sr-only" />
                  <span className="block h-9 w-9 rounded-full ring-offset-2 peer-checked:ring-2 peer-checked:ring-ink" style={{ background: `hsl(${h} 45% 40%)` }} />
                </label>
              ))}
            </div>
          </fieldset>
          <fieldset>
            <legend className="label">Seller values (shown as badges; buyers can filter by these)</legend>
            <div className="grid gap-2 sm:grid-cols-2">
              {Object.entries(BADGES).map(([k, b]) => (
                <label key={k} className="flex items-center gap-2 text-sm"><input type="checkbox" name="badges" value={k} defaultChecked={badges.includes(k)} className="accent-signal" /> {b.label}</label>
              ))}
            </div>
          </fieldset>
        </ActionForm>
      </div>
    </>
  );
}
