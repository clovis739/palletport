"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  ["/dashboard", "Overview"],
  ["/dashboard/orders", "Orders"],
  ["/dashboard/lots", "Lots"],
  ["/dashboard/new", "+ List a pallet"],
  ["/dashboard/customers", "Customers"],
  ["/dashboard/promotions", "Promotions"],
  ["/dashboard/analytics", "Analytics"],
  ["/dashboard/payouts", "Payouts"],
  ["/messages", "Messages"],
  ["/dashboard/settings", "Store settings"],
];

export function DashNav() {
  const path = usePathname();
  return (
    <nav className="flex gap-1 overflow-x-auto lg:flex-col">
      {LINKS.map(([href, label]) => {
        const active = href === "/dashboard" ? path === href : path.startsWith(href);
        return (
          <Link key={href} href={href} className={`shrink-0 rounded-lg px-3 py-2 text-sm ${active ? "bg-sand font-semibold" : "text-ink/80 hover:bg-sand"}`}>
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
