import { requireSeller } from "@/lib/auth";
import { db } from "@/lib/db";
import { money } from "@/lib/format";
import { createPromo, togglePromo } from "@/app/actions/seller";
import { ActionForm } from "@/components/forms/ActionForm";

export const metadata = { title: "Promotions · Seller hub" };

export default async function Promotions() {
  const { seller } = await requireSeller();
  const promos = await db.promo.findMany({ where: { sellerId: seller.id }, orderBy: { createdAt: "desc" } });
  return (
    <>
      <h1 className="mb-2 font-display text-3xl font-bold">Promotions</h1>
      <p className="mb-6 text-sm text-muted">Codes apply only to your lots. Active codes are shown on your storefront.</p>
      <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="bg-sand/60 text-left text-xs uppercase tracking-wider text-muted">
              <tr><th className="px-4 py-3">Code</th><th className="px-4 py-3">Offer</th><th className="px-4 py-3">Min.</th><th className="px-4 py-3 text-right">Uses</th><th className="px-4 py-3" /></tr>
            </thead>
            <tbody className="divide-y divide-line">
              {promos.map((p) => (
                <tr key={p.id} className={p.active ? "" : "opacity-50"}>
                  <td className="px-4 py-3 font-mono font-bold">{p.code}</td>
                  <td className="px-4 py-3">{p.percentOff ? `${p.percentOff}% off` : `${money(p.amountOffCents ?? 0)} off`}{p.firstOrderOnly && <span className="ml-1 text-xs text-muted">(first order)</span>}</td>
                  <td className="px-4 py-3">{p.minSubtotalCents ? money(p.minSubtotalCents) : "—"}</td>
                  <td className="px-4 py-3 text-right">{p.uses}</td>
                  <td className="px-4 py-3 text-right">
                    <form action={togglePromo}>
                      <input type="hidden" name="id" value={p.id} />
                      <button className="text-xs font-semibold text-signal-dark hover:underline">{p.active ? "Pause" : "Activate"}</button>
                    </form>
                  </td>
                </tr>
              ))}
              {promos.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-muted">No promotions yet.</td></tr>}
            </tbody>
          </table>
        </div>
        <div className="card h-fit p-5">
          <h2 className="mb-3 font-display font-bold">New promotion</h2>
          <ActionForm action={createPromo} submitLabel="Create code" successText="Promotion created" resetOnSuccess className="space-y-3">
            <div><label className="label" htmlFor="code">Code</label><input id="code" name="code" className="input font-mono uppercase" placeholder="SPRING15" required /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label" htmlFor="kind">Type</label>
                <select id="kind" name="kind" className="input"><option value="percent">% off</option><option value="amount">$ off</option></select>
              </div>
              <div><label className="label" htmlFor="value">Value</label><input id="value" name="value" type="number" min={1} className="input" required /></div>
            </div>
            <div><label className="label" htmlFor="minSubtotal">Minimum spend ($)</label><input id="minSubtotal" name="minSubtotal" type="number" min={0} defaultValue={0} className="input" /></div>
            <div><label className="label" htmlFor="description">Description (optional)</label><input id="description" name="description" className="input" /></div>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="firstOrderOnly" className="accent-signal" /> First-time buyers only</label>
          </ActionForm>
        </div>
      </div>
    </>
  );
}
