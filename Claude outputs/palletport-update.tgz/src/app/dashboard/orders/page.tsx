import Link from "next/link";
import { requireSeller } from "@/lib/auth";
import { db } from "@/lib/db";
import { money } from "@/lib/format";
import { updateOrderStatus } from "@/app/actions/seller";
import { StatusPill } from "../../orders/StatusPill";

export const metadata = { title: "Orders · Seller hub" };

const NEXT_STATUS: Record<string, string | undefined> = { PENDING: "CONFIRMED", CONFIRMED: "SHIPPED", SHIPPED: "DELIVERED" };
const TABS = ["ALL", "AWAITING_PAYMENT", "PENDING", "CONFIRMED", "SHIPPED", "DELIVERED", "CANCELLED"];

export default async function SellerOrders({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const { status = "ALL" } = await searchParams;
  const { seller } = await requireSeller();
  const orders = await db.order.findMany({
    where: { items: { some: { sellerId: seller.id } }, ...(status !== "ALL" ? { status } : {}) },
    include: { items: { where: { sellerId: seller.id } }, user: { select: { businessName: true, name: true, email: true, certStatus: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <>
      <h1 className="mb-4 font-display text-3xl font-bold">Orders</h1>
      <div className="mb-6 flex gap-1 overflow-x-auto">
        {TABS.map((t) => (
          <Link key={t} href={t === "ALL" ? "/dashboard/orders" : `/dashboard/orders?status=${t}`} className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold ${status === t ? "bg-ink text-white" : "bg-white border border-line"}`}>
            {t === "AWAITING_PAYMENT" ? "Awaiting payment" : t.charAt(0) + t.slice(1).toLowerCase()}
          </Link>
        ))}
      </div>
      {orders.length === 0 ? (
        <p className="card p-10 text-center text-sm text-muted">No orders here.</p>
      ) : (
        <div className="space-y-4">
          {orders.map((o) => {
            const next = NEXT_STATUS[o.status];
            const total = o.items.reduce((a, i) => a + i.priceCents * i.quantity, 0);
            return (
              <div key={o.id} className="card p-5">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-mono font-semibold">{o.number}</span>
                  <StatusPill status={o.status} />
                  <span className="text-xs text-muted">{o.createdAt.toLocaleDateString()} · {o.paymentMethod === "NET30" ? "Net 30" : o.paymentMethod === "WIRE" ? "Wire/ACH" : "Card"}</span>
                  <span className="ml-auto font-display text-lg font-bold">{money(total)}</span>
                </div>
                <div className="mt-3 grid gap-4 text-sm md:grid-cols-3">
                  <div>
                    <p className="label">Lots</p>
                    {o.items.map((i) => <p key={i.id}>{i.quantity}× {i.title}</p>)}
                  </div>
                  <div>
                    <p className="label">Buyer</p>
                    <p>{o.user.businessName ?? o.user.name}</p>
                    <p className="text-xs text-muted">{o.user.email} · {o.user.certStatus === "APPROVED" ? "Verified" : "Unverified"}</p>
                  </div>
                  <div>
                    <p className="label">Ship to</p>
                    <p>{o.shipName}</p>
                    <p className="text-xs text-muted">{o.shipAddress}, {o.shipCity}, {o.shipRegion} {o.shipPostal} · {o.dockAccess ? "Dock" : "Liftgate"}</p>
                    {o.trackingNo && <p className="text-xs">PRO <span className="font-mono">{o.trackingNo}</span></p>}
                  </div>
                </div>
                {next && (
                  <form action={updateOrderStatus} className="mt-4 flex flex-wrap items-center gap-2 border-t border-line pt-4">
                    <input type="hidden" name="orderId" value={o.id} />
                    <input type="hidden" name="status" value={next} />
                    {next === "SHIPPED" && <input name="trackingNo" placeholder="Freight PRO / tracking #" className="input w-60 py-2" />}
                    <button className="btn-dark py-2 text-xs">Mark {next.toLowerCase()}</button>
                  </form>
                )}
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
