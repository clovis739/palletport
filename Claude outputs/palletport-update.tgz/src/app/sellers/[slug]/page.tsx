import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { LotCard } from "@/components/LotCard";
import { Stars } from "@/components/Stars";
import { contactSeller, toggleFollow } from "@/app/actions/social";
import { BADGES, initials, money, parseBadges, timeAgo } from "@/lib/format";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  const s = await db.seller.findUnique({ where: { slug }, select: { name: true } });
  return { title: s?.name ?? "Seller" };
}

export default async function SellerPage({ params }: { params: Params }) {
  const { slug } = await params;
  const seller = await db.seller.findUnique({
    where: { slug },
    include: {
      lots: { where: { status: { in: ["ACTIVE", "SOLD_OUT"] } }, include: { category: true, seller: true }, orderBy: { createdAt: "desc" } },
      reviews: { include: { user: { select: { name: true, businessName: true } } }, orderBy: { createdAt: "desc" }, take: 6 },
      promos: { where: { active: true } },
      _count: { select: { followers: true, reviews: true } },
    },
  });
  if (!seller) notFound();
  const session = await getSession();
  const following = session ? await db.follow.findUnique({ where: { userId_sellerId: { userId: session.userId, sellerId: seller.id } } }) : null;
  const isOwner = session?.userId === seller.userId;
  const active = seller.lots.filter((l) => l.status === "ACTIVE");
  const sold = seller.lots.filter((l) => l.status === "SOLD_OUT");
  const cats = [...new Map(active.map((l) => [l.category.slug, l.category.name] as const)).entries()];
  const back = `/sellers/${seller.slug}`;

  return (
    <>
      <div className="h-36" style={{ background: `linear-gradient(120deg, hsl(${seller.bannerHue} 45% 30%), hsl(${seller.bannerHue} 50% 58%))` }} />
      <section className="border-b border-line">
        <div className="container-pp -mt-12 flex flex-wrap items-end gap-6 pb-8">
          <div className="grid h-24 w-24 place-items-center rounded-2xl border-4 border-paper bg-ink font-display text-3xl font-bold text-white">{initials(seller.name)}</div>
          <div className="min-w-0 flex-1 pt-14">
            <h1 className="font-display text-3xl font-bold">
              {seller.name} {seller.verified && <span className="align-middle text-base text-moss">✓ Verified seller</span>}
            </h1>
            <p className="flex flex-wrap items-center gap-2 text-sm text-muted">
              <Stars value={seller.rating} /> {seller.rating.toFixed(1)} ({seller._count.reviews}) · {seller.location} · {seller._count.followers} followers · Since {seller.createdAt.getFullYear()}
            </p>
          </div>
          {!isOwner && (
            <div className="flex gap-2">
              <form action={toggleFollow}>
                <input type="hidden" name="sellerId" value={seller.id} />
                <input type="hidden" name="back" value={back} />
                <button className={following ? "btn-ghost" : "btn-dark"}>{following ? "Following ✓" : "+ Follow"}</button>
              </form>
              <form action={contactSeller}>
                <input type="hidden" name="sellerId" value={seller.id} />
                <button className="btn-ghost">Message</button>
              </form>
            </div>
          )}
          {isOwner && <Link href="/dashboard/settings" className="btn-ghost">Edit storefront</Link>}
        </div>
      </section>

      <div className="container-pp grid gap-10 py-10 lg:grid-cols-[280px_1fr]">
        <aside className="space-y-6">
          <div className="card space-y-3 p-5 text-sm">
            <p>{seller.bio}</p>
            <dl className="space-y-1.5 border-t border-line pt-3">
              <div className="flex justify-between"><dt className="text-muted">Minimum order</dt><dd className="font-semibold">{seller.minOrderCents ? money(seller.minOrderCents) : "None"}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Local pickup</dt><dd className="font-semibold">{seller.pickup ? "Yes" : "No"}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Live lots</dt><dd className="font-semibold">{active.length}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Lots sold</dt><dd className="font-semibold">{sold.length}</dd></div>
            </dl>
            {parseBadges(seller.badges).length > 0 && (
              <div className="flex flex-wrap gap-1.5 border-t border-line pt-3">
                {parseBadges(seller.badges).map((b) => <span key={b} className="rounded-full bg-sand px-2.5 py-0.5 text-xs font-semibold">{BADGES[b].label}</span>)}
              </div>
            )}
          </div>
          {seller.promos.length > 0 && (
            <div className="rounded-2xl border-2 border-dashed border-signal bg-signal/5 p-5 text-sm">
              <p className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-signal-dark">Seller offers</p>
              {seller.promos.map((p) => (
                <p key={p.id} className="mt-1"><span className="font-mono font-bold">{p.code}</span> — {p.description}</p>
              ))}
            </div>
          )}
          {cats.length > 0 && (
            <div>
              <p className="label">Shop this seller by category</p>
              <ul className="space-y-1 text-sm">
                {cats.map(([slug, name]) => (
                  <li key={slug}><Link href={`/lots?seller=${seller.slug}&category=${slug}`} className="hover:underline">{name}</Link></li>
                ))}
              </ul>
            </div>
          )}
        </aside>

        <div>
          <h2 className="mb-5 font-display text-2xl font-bold">Available lots</h2>
          {active.length ? (
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{active.map((l) => <LotCard key={l.id} lot={l} />)}</div>
          ) : (
            <p className="text-muted">No live lots right now. Follow this seller to hear about new pallets.</p>
          )}

          <h2 className="mb-5 mt-12 font-display text-2xl font-bold">Reviews</h2>
          {seller.reviews.length === 0 ? (
            <p className="text-muted">No reviews yet.</p>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {seller.reviews.map((r) => (
                <div key={r.id} className="card p-5">
                  <div className="flex items-center justify-between"><Stars value={r.rating} /><span className="text-xs text-muted">{timeAgo(r.createdAt)}</span></div>
                  <p className="mt-2 text-sm">{r.body}</p>
                  <p className="mt-2 text-xs font-semibold text-muted">{r.user.businessName ?? r.user.name}</p>
                </div>
              ))}
            </div>
          )}

          {sold.length > 0 && (
            <>
              <h2 className="mb-5 mt-12 font-display text-2xl font-bold">Recently sold</h2>
              <div className="grid gap-5 opacity-80 sm:grid-cols-2 xl:grid-cols-3">{sold.slice(0, 6).map((l) => <LotCard key={l.id} lot={l} />)}</div>
            </>
          )}
        </div>
      </div>
    </>
  );
}
