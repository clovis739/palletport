import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { BADGES, initials, money, parseBadges } from "@/lib/format";

export const metadata = { title: "Sellers" };

export default async function SellersDirectory({ searchParams }: { searchParams: Promise<{ q?: string; badge?: string }> }) {
  const { q = "", badge = "" } = await searchParams;
  const where: Prisma.SellerWhereInput = {
    ...(q ? { OR: [{ name: { contains: q } }, { location: { contains: q } }] } : {}),
    ...(badge && BADGES[badge] ? { badges: { contains: badge } } : {}),
  };
  const sellers = await db.seller.findMany({
    where,
    orderBy: [{ verified: "desc" }, { rating: "desc" }],
    include: { _count: { select: { lots: { where: { status: "ACTIVE" } }, reviews: true } } },
  });

  return (
    <div className="container-pp py-10">
      <h1 className="font-display text-3xl font-bold">Sellers</h1>
      <p className="mb-6 text-muted">Liquidators, distributors and returns processors selling on PalletPort.</p>
      <div className="mb-8 flex flex-wrap items-center gap-2">
        <form className="mr-2">
          {badge && <input type="hidden" name="badge" value={badge} />}
          <input name="q" defaultValue={q} placeholder="Search sellers or cities" className="input w-64 rounded-full" />
        </form>
        <Link href={q ? `/sellers?q=${encodeURIComponent(q)}` : "/sellers"} className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${!badge ? "border-ink bg-ink text-white" : "border-line bg-white"}`}>All</Link>
        {Object.entries(BADGES).map(([k, b]) => (
          <Link key={k} href={`/sellers?badge=${k}${q ? `&q=${encodeURIComponent(q)}` : ""}`} className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${badge === k ? "border-ink bg-ink text-white" : "border-line bg-white"}`}>{b.label}</Link>
        ))}
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {sellers.map((s) => (
          <Link key={s.id} href={`/sellers/${s.slug}`} className="card overflow-hidden transition hover:border-ink">
            <div className="h-16" style={{ background: `linear-gradient(120deg, hsl(${s.bannerHue} 45% 35%), hsl(${s.bannerHue} 45% 60%))` }} />
            <div className="-mt-8 p-5 pt-0">
              <span className="grid h-14 w-14 place-items-center rounded-2xl border-4 border-white bg-ink font-display font-bold text-white">{initials(s.name)}</span>
              <p className="mt-2 font-display text-lg font-bold">{s.name} {s.verified && <span className="text-sm text-moss">✓</span>}</p>
              <p className="text-xs text-muted">{s.location} · ★ {s.rating.toFixed(1)} ({s._count.reviews}) · {s._count.lots} live lots</p>
              <p className="mt-2 line-clamp-2 text-sm text-ink/75">{s.bio}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {parseBadges(s.badges).map((b) => <span key={b} className="rounded-full bg-sand px-2 py-0.5 text-[11px] font-semibold">{BADGES[b].short}</span>)}
                <span className="rounded-full bg-sand px-2 py-0.5 text-[11px] font-semibold">{s.minOrderCents ? `${money(s.minOrderCents)} min` : "No minimum"}</span>
              </div>
            </div>
          </Link>
        ))}
        {sellers.length === 0 && <p className="text-muted">No sellers match.</p>}
      </div>
    </div>
  );
}
