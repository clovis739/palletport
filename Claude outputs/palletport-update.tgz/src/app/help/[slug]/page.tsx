import Link from "next/link";
import { notFound } from "next/navigation";
import { HELP } from "@/content/help";
import { Prose } from "@/components/Prose";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  return { title: HELP.find((a) => a.slug === slug)?.title ?? "Help" };
}

export default async function HelpArticle({ params }: { params: Params }) {
  const { slug } = await params;
  const a = HELP.find((x) => x.slug === slug);
  if (!a) notFound();
  const related = HELP.filter((x) => x.category === a.category && x.slug !== a.slug);
  return (
    <div className="container-pp grid gap-10 py-10 lg:grid-cols-[1fr_280px]">
      <article className="max-w-2xl">
        <nav className="mb-2 text-xs text-muted"><Link href="/help" className="hover:underline">Help center</Link> / {a.category}</nav>
        <h1 className="mb-2 font-display text-3xl font-bold">{a.title}</h1>
        <p className="mb-8 text-lg text-muted">{a.excerpt}</p>
        <Prose body={a.body} />
        <div className="mt-10 rounded-xl border border-line bg-white p-5 text-sm">
          Still stuck? <Link href="/contact" className="font-semibold text-signal-dark hover:underline">Contact support</Link> and we'll reply within one business day.
        </div>
      </article>
      <aside>
        <p className="label">More in {a.category}</p>
        <ul className="space-y-2 text-sm">
          {related.map((r) => <li key={r.slug}><Link href={`/help/${r.slug}`} className="hover:underline">{r.title}</Link></li>)}
        </ul>
      </aside>
    </div>
  );
}
