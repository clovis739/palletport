import Link from "next/link";
import { HELP, HELP_TOPICS } from "@/content/help";

export const metadata = { title: "Help center" };

export default async function HelpCenter({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  const term = q.trim().toLowerCase();
  const results = term
    ? HELP.filter((a) => [a.title, a.excerpt, ...a.body.flatMap((s) => [s.h ?? "", ...(s.p ?? []), ...(s.list ?? [])])].join(" ").toLowerCase().includes(term))
    : [];
  return (
    <>
      <section className="bg-sand/70">
        <div className="container-pp py-14 text-center">
          <h1 className="font-display text-4xl font-bold">How can we help?</h1>
          <form className="mx-auto mt-6 max-w-xl">
            <input name="q" defaultValue={q} placeholder="Search: freight, Net 30, promo codes…" className="input rounded-full py-3.5 text-base" />
          </form>
        </div>
      </section>
      <div className="container-pp py-12">
        {term ? (
          <section className="mx-auto max-w-3xl">
            <h2 className="mb-4 font-display text-xl font-bold">{results.length} result{results.length === 1 ? "" : "s"} for “{q}”</h2>
            <ul className="card divide-y divide-line">
              {results.map((a) => (
                <li key={a.slug}><Link href={`/help/${a.slug}`} className="block p-4 hover:bg-sand/40"><span className="font-semibold">{a.title}</span><span className="block text-sm text-muted">{a.excerpt}</span></Link></li>
              ))}
              {results.length === 0 && <li className="p-6 text-center text-sm text-muted">Nothing found. <Link href="/contact" className="font-semibold text-signal-dark">Contact support</Link></li>}
            </ul>
          </section>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            {HELP_TOPICS.map((t) => (
              <section key={t.key} className="card p-6">
                <h2 className="font-display text-xl font-bold">{t.key}</h2>
                <p className="mb-3 text-sm text-muted">{t.blurb}</p>
                <ul className="space-y-2 text-sm">
                  {HELP.filter((a) => a.category === t.key).map((a) => (
                    <li key={a.slug}><Link href={`/help/${a.slug}`} className="font-medium hover:text-signal-dark hover:underline">{a.title}</Link></li>
                  ))}
                </ul>
              </section>
            ))}
          </div>
        )}
        <div className="mt-12 rounded-2xl bg-ink p-8 text-center text-white">
          <p className="font-display text-xl font-bold">Can't find an answer?</p>
          <p className="text-sm text-white/70">Our support team replies within one business day.</p>
          <Link href="/contact" className="btn-primary mt-4">Contact support</Link>
        </div>
      </div>
    </>
  );
}
