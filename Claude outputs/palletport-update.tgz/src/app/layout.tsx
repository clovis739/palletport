import type { Metadata } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { NetworkStatus } from "@/components/states/NetworkStatus";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const grotesk = Space_Grotesk({ subsets: ["latin"], variable: "--font-grotesk" });

export const metadata: Metadata = {
  title: { default: "PalletPort — Wholesale liquidation pallets", template: "%s · PalletPort" },
  description: "Buy manifested liquidation pallets and truckloads from verified sellers.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${grotesk.variable}`}>
      <body className="min-h-screen bg-paper">
        <Header />
        <main>{children}</main>
        <Footer />
        <NetworkStatus />
      </body>
    </html>
  );
}
