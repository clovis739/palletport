import Link from "next/link";
import { CONDITIONS, FREE_FREIGHT_THRESHOLD_CENTS, money } from "@/lib/format";

export const metadata = { title: "How PalletPort works" };

export default function HowItWorks() {
  return (
    <>
      <section className="bg-ink text-white">
        <div className="container-pp py-16 text-center">
          <h1 className="font-display text-4xl font-bold sm:text-5xl">How PalletPort works</h1>
          <p className="mx-auto mt-3 max-w-2xl text-white/70">A wholesale marketplace built around the manifest. Buyers see exactly what's on a pallet; sellers reach resellers nationwide without running their own auctions.</p>
        </div>
        <div className="stripe h-2" />
      </section>

      <section className="container-pp grid gap-10 py-16 lg:grid-cols-2">
        <div>
          <p className="label">For buyers</p>
          <h2 className="font-display text-3xl font-bold">Buy with the full picture</h2>
          <ol className="mt-6 space-y-5">
            {[
              ["Create a business account", "Free for any reseller. Add your resale certificate to unlock Net 30 terms."],
              ["Browse and compare", "Filter by category, condition, price and seller values. Every lot shows its manifest, percent of retail and price per unit."],
              ["Ask before you buy", "Message sellers about photos, testing or bundle deals."],
              ["Check out", "Pay by card, wire/ACH, or Net 30. Add a promo code if you have one."],
              ["Receive and review", `Freight is ${money(17500)} per pallet and free over ${money(FREE_FREIGHT_THRESHOLD_CENTS)}. Track your PRO number and leave a review after delivery.`],
            ].map(([t, d], i) => (
              <li key={t} className="flex gap-4">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-signal font-display font-bold text-white">{i + 1}</span>
                <span><span className="block font-display text-lg font-semibold">{t}</span><span className="text-sm text-muted">{d}</span></span>
              </li>
            ))}
          </ol>
          <Link href="/register" className="btn-primary mt-8">Create a buyer account</Link>
        </div>
        <div>
          <p className="label">For sellers</p>
          <h2 className="font-display text-3xl font-bold">Move inventory without the auction grind</h2>
          <ol className="mt-6 space-y-5">
            {[
              ["Open a store in minutes", "Tell buyers where your stock comes from and how you grade it."],
              ["List by pasting a manifest", "We total units and retail value automatically."],
              ["Fulfil from your dock", "Confirm, add a PRO number, mark delivered."],
              ["Get paid", "Payout two business days after delivery, minus a 10% commission. No listing fees."],
            ].map(([t, d], i) => (
              <li key={t} className="flex gap-4">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-ink font-display font-bold text-white">{i + 1}</span>
                <span><span className="block font-display text-lg font-semibold">{t}</span><span className="text-sm text-muted">{d}</span></span>
              </li>
            ))}
          </ol>
          <Link href="/sell" className="btn-dark mt-8">Start selling</Link>
        </div>
      </section>

      <section className="border-y border-line bg-sand/50">
        <div className="container-pp py-14">
          <h2 className="mb-6 font-display text-2xl font-bold">Condition grades</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {Object.entries(CONDITIONS).map(([k, c]) => (
              <div key={k} className="card p-4">
                <span className={`inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${c.tone}`}>{c.label}</span>
                <p className="mt-2 text-sm text-ink/75">{c.note}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container-pp py-14 text-center">
        <h2 className="font-display text-2xl font-bold">Still have questions?</h2>
        <p className="mt-1 text-muted">Our help center covers payments, freight, disputes and selling.</p>
        <Link href="/help" className="btn-ghost mt-5">Visit the help center</Link>
      </section>
    </>
  );
}
