import { LotBrowser, type SearchParams } from "@/components/browse/LotBrowser";
import { LOT_SIZES } from "@/lib/format";

export const metadata = { title: "Truckloads" };

export default async function TruckloadsPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  return <LotBrowser sp={await searchParams} basePath="/truckloads" fixed={{ size: "TRUCKLOAD" }} heading="Truckloads" intro={LOT_SIZES.TRUCKLOAD.note} />;
}
