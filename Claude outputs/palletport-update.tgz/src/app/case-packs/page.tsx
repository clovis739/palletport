import { LotBrowser, type SearchParams } from "@/components/browse/LotBrowser";
import { LOT_SIZES } from "@/lib/format";

export const metadata = { title: "Case packs" };

export default async function CasepacksPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  return <LotBrowser sp={await searchParams} basePath="/case-packs" fixed={{ size: "CASE" }} heading="Case packs" intro={LOT_SIZES.CASE.note} />;
}
