import { LotBrowser, type SearchParams } from "@/components/browse/LotBrowser";
import { LOT_SIZES } from "@/lib/format";

export const metadata = { title: "Pallets" };

export default async function PalletsPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  return <LotBrowser sp={await searchParams} basePath="/pallets" fixed={{ size: "PALLET" }} heading="Pallets" intro={LOT_SIZES.PALLET.note} />;
}
