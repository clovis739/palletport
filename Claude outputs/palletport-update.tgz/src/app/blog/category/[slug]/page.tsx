import { notFound } from "next/navigation";
import { BlogIndex } from "@/components/blog/BlogIndex";
import { categoryFromSlug } from "@/lib/blog";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const c = categoryFromSlug((await params).slug);
  return { title: c ? `${c} — Blog` : "Blog" };
}

export default async function BlogCategoryPage({ params, searchParams }: { params: Params; searchParams: Promise<{ page?: string }> }) {
  const { slug } = await params;
  const category = categoryFromSlug(slug);
  if (!category) notFound();
  const { page } = await searchParams;
  return <BlogIndex category={category} page={Math.max(1, Number(page) || 1)} basePath={`/blog/category/${slug}`} />;
}
