import Link from "next/link";
import { notFound } from "next/navigation";
import { PalletArt } from "@/components/PalletArt";
import { PostCard } from "@/components/blog/PostCard";
import { ShareBar } from "@/components/blog/ShareBar";
import { authorOf, categorySlug, formatDate, getPost, neighbours, relatedPosts, slugifyText } from "@/lib/blog";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const p = getPost((await params).slug);
  return { title: p?.title ?? "Article", description: p?.excerpt };
}

export default async function BlogPost({ params }: { params: Params }) {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) notFound();
  const author = authorOf(post);
  const toc = post.body.filter((s) => s.h).map((s) => ({ id: slugifyText(s.h!), h: s.h! }));
  const { newer, older } = neighbours(slug);
  const related = relatedPosts(post);

  return (
    <>
      <header className="border-b border-line bg-sand/50">
        <div className="container-pp max-w-4xl py-10">
          <nav className="mb-4 text-xs text-muted">
            <Link href="/" className="hover:underline">Home</Link> / <Link href="/blog" className="hover:underline">Blog</Link> /{" "}
            <Link href={`/blog/category/${categorySlug(post.category ?? "")}`} className="hover:underline">{post.category}</Link>
          </nav>
          <div className="mb-3 flex flex-wrap gap-2">
            <Link href={`/blog/category/${categorySlug(post.category ?? "")}`} className="rounded-full bg-ink px-3 py-1 text-xs font-bold uppercase tracking-wide text-white hover:bg-ink-2">{post.category}</Link>
            {post.tags?.map((t) => (
              <Link key={t} href={`/blog?tag=${encodeURIComponent(t)}`} className="rounded-full border border-line bg-white px-3 py-1 text-xs font-semibold hover:border-ink">{t}</Link>
            ))}
          </div>
          <h1 className="font-display text-3xl font-bold leading-tight sm:text-5xl">{post.title}</h1>
          <p className="mt-4 text-lg text-ink/70">{post.excerpt}</p>
          <div className="mt-6 flex flex-wrap items-center gap-3 text-sm">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-ink font-display text-xs font-bold text-white">PP</span>
            <span>
              <span className="block font-semibold">{author.name}</span>
              <span className="text-xs text-muted">{formatDate(post.date, "long")} · {post.readMins} min read</span>
            </span>
          </div>
        </div>
      </header>

      <div className="container-pp grid gap-10 py-10 lg:grid-cols-[220px_minmax(0,1fr)_220px]">
        {/* TOC */}
        <aside className="hidden lg:block">
          {toc.length > 0 && (
            <nav className="sticky top-[130px] text-sm" aria-label="On this page">
              <p className="label">On this page</p>
              <ol className="space-y-1.5 border-l border-line pl-3">
                {toc.map((t) => <li key={t.id}><a href={`#${t.id}`} className="block text-ink/70 hover:text-signal-dark">{t.h}</a></li>)}
              </ol>
            </nav>
          )}
        </aside>

        <article className="min-w-0 max-w-2xl">
          <PalletArt seed={post.slug} hue={post.hue} className="mb-8 w-full rounded-2xl" />
          <div className="space-y-8 text-[16px] leading-relaxed text-ink/85">
            {post.body.map((s, i) => (
              <section key={i} id={s.h ? slugifyText(s.h) : undefined} className="scroll-mt-40 space-y-3">
                {s.h && <h2 className="font-display text-2xl font-bold text-ink">{s.h}</h2>}
                {s.p?.map((t, j) => <p key={j}>{t}</p>)}
                {s.list && <ul className="list-disc space-y-1.5 pl-5 marker:text-signal">{s.list.map((t, j) => <li key={j}>{t}</li>)}</ul>}
              </section>
            ))}
          </div>

          {/* CTA */}
          <Link href="/auctions" className="group mt-12 flex flex-wrap items-center justify-between gap-4 rounded-2xl bg-ink p-6 text-white">
            <span>
              <span className="block font-display text-xl font-bold">Ready to start buying?</span>
              <span className="text-sm text-white/70">Browse manifested lots from verified sellers — auctions and Buy Now.</span>
            </span>
            <span className="btn-primary">Browse lots <span className="transition group-hover:translate-x-1">→</span></span>
          </Link>

          {/* Author */}
          <div className="card mt-8 flex gap-4 p-5">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-ink font-display text-sm font-bold text-white">PP</span>
            <div>
              <p className="font-semibold">{author.name} <span className="font-normal text-muted">· {author.role}</span></p>
              <p className="mt-1 text-sm text-ink/75">{author.bio}</p>
            </div>
          </div>

          {/* Prev / next */}
          <nav className="mt-8 grid gap-4 sm:grid-cols-2" aria-label="More articles">
            {older ? (
              <Link href={`/blog/${older.slug}`} className="group card p-5 hover:border-ink">
                <span className="text-xs font-semibold uppercase tracking-wider text-muted">← Previous</span>
                <span className="mt-1 block font-display font-bold leading-snug group-hover:text-signal-dark">{older.title}</span>
              </Link>
            ) : <span />}
            {newer && (
              <Link href={`/blog/${newer.slug}`} className="group card p-5 text-right hover:border-ink">
                <span className="text-xs font-semibold uppercase tracking-wider text-muted">Next →</span>
                <span className="mt-1 block font-display font-bold leading-snug group-hover:text-signal-dark">{newer.title}</span>
              </Link>
            )}
          </nav>
        </article>

        <aside className="space-y-6 lg:sticky lg:top-[130px] lg:h-fit">
          <ShareBar title={post.title} />
          <div className="rounded-2xl bg-sand p-5 text-sm">
            <p className="font-display font-bold">New to liquidation?</p>
            <p className="mt-1 text-ink/75">Our bidding guide covers proxy bids, soft close and paying for what you win.</p>
            <Link href="/how-to-buy" className="mt-3 inline-block font-semibold text-signal-dark hover:underline">How to buy & bid →</Link>
          </div>
        </aside>
      </div>

      {related.length > 0 && (
        <section className="border-t border-line bg-sand/40">
          <div className="container-pp py-12">
            <div className="mb-6 flex items-end justify-between">
              <h2 className="font-display text-2xl font-bold">Keep reading</h2>
              <Link href="/blog" className="text-sm font-semibold text-signal-dark hover:underline">All articles →</Link>
            </div>
            <div className="grid gap-6 md:grid-cols-3">{related.map((p) => <PostCard key={p.slug} post={p} />)}</div>
          </div>
        </section>
      )}
    </>
  );
}
