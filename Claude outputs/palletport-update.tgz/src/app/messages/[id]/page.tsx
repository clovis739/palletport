import Link from "next/link";
import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { sendMessage } from "@/app/actions/social";
import { ActionForm } from "@/components/forms/ActionForm";

export const metadata = { title: "Conversation" };

export default async function ConversationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const u = await requireUser(`/messages/${id}`);
  const convo = await db.conversation.findUnique({
    where: { id },
    include: {
      buyer: { select: { id: true, name: true, businessName: true, businessType: true, certStatus: true } },
      seller: { select: { name: true, slug: true, userId: true } },
      messages: { orderBy: { createdAt: "asc" }, include: { sender: { select: { name: true } } } },
    },
  });
  if (!convo || (convo.buyerId !== u.id && convo.seller.userId !== u.id)) notFound();

  await db.message.updateMany({ where: { conversationId: id, senderId: { not: u.id }, readAt: null }, data: { readAt: new Date() } });

  const iAmBuyer = convo.buyerId === u.id;
  const otherName = iAmBuyer ? convo.seller.name : convo.buyer.businessName ?? convo.buyer.name;

  return (
    <div className="container-pp max-w-3xl py-10">
      <Link href="/messages" className="text-xs text-muted hover:underline">← All messages</Link>
      <div className="mb-4 mt-1 flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="font-display text-2xl font-bold">{otherName}</h1>
          <p className="text-sm text-muted">{convo.subject}</p>
        </div>
        {iAmBuyer ? (
          <Link href={`/sellers/${convo.seller.slug}`} className="btn-ghost py-2 text-xs">View storefront</Link>
        ) : (
          <p className="text-xs text-muted">
            {convo.buyer.businessType ?? "Reseller"} · {convo.buyer.certStatus === "APPROVED" ? <span className="font-semibold text-moss">Verified reseller</span> : "Unverified"}
          </p>
        )}
      </div>

      <div className="card space-y-3 p-5">
        {convo.messages.length === 0 && <p className="py-6 text-center text-sm text-muted">Say hello — ask about photos, testing, freight or bundle pricing.</p>}
        {convo.messages.map((m) => {
          const mine = m.senderId === u.id;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${mine ? "rounded-br-sm bg-ink text-white" : "rounded-bl-sm bg-sand"}`}>
                <p className="whitespace-pre-wrap">{m.body}</p>
                <p className={`mt-1 text-[10px] ${mine ? "text-white/60" : "text-muted"}`}>{m.createdAt.toLocaleString()}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="card mt-4 p-4">
        <ActionForm action={sendMessage} submitLabel="Send" submitClass="btn-primary" resetOnSuccess className="space-y-3">
          <input type="hidden" name="conversationId" value={convo.id} />
          <textarea name="body" rows={3} required placeholder="Write a message…" className="input" />
        </ActionForm>
      </div>
    </div>
  );
}
