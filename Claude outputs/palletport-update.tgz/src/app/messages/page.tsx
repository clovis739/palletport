import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getInbox } from "@/lib/messages";
import { initials, timeAgo } from "@/lib/format";
import { AccountShell } from "../account/AccountNav";

export const metadata = { title: "Messages" };

export default async function MessagesPage() {
  const u = await requireUser("/messages");
  const { convos } = await getInbox(u.id);
  return (
    <AccountShell active="/messages" title="Messages">
      {convos.length === 0 ? (
        <div className="card p-10 text-center">
          <p className="font-display text-lg font-semibold">No conversations yet</p>
          <p className="mt-1 text-sm text-muted">Use “Message seller” on any lot or storefront to ask about condition, photos or freight.</p>
        </div>
      ) : (
        <ul className="card divide-y divide-line">
          {convos.map((c) => {
            const iAmBuyer = c.buyerId === u.id;
            const other = iAmBuyer ? c.seller.name : c.buyer.businessName ?? c.buyer.name;
            const last = c.messages[0];
            const unread = last && !last.readAt && last.senderId !== u.id;
            return (
              <li key={c.id}>
                <Link href={`/messages/${c.id}`} className="flex items-center gap-4 p-4 hover:bg-sand/40">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-ink font-display text-sm font-bold text-white">{initials(other)}</span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className={`truncate ${unread ? "font-bold" : "font-semibold"}`}>{other}</span>
                      <span className="rounded bg-sand px-1.5 text-[10px] font-semibold uppercase text-muted">{iAmBuyer ? "Seller" : "Buyer"}</span>
                    </span>
                    <span className="block truncate text-xs text-muted">{c.subject}</span>
                    <span className={`block truncate text-sm ${unread ? "text-ink" : "text-ink/60"}`}>{last?.body ?? "No messages yet"}</span>
                  </span>
                  <span className="shrink-0 text-xs text-muted">{last ? timeAgo(last.createdAt) : ""}</span>
                  {unread && <span className="h-2.5 w-2.5 rounded-full bg-signal" />}
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </AccountShell>
  );
}
