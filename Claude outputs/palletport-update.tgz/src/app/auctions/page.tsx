import { LotBrowser, type SearchParams } from "@/components/browse/LotBrowser";

export const metadata = { title: "Live auctions" };

export default async function AuctionsPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  return <LotBrowser sp={await searchParams} basePath="/auctions" fixed={{ type: "AUCTION" }} heading="Live auctions" />;
}
