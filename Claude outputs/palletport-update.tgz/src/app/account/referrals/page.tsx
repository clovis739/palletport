import { headers } from "next/headers";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { AccountShell } from "../AccountNav";

export const metadata = { title: "Refer a business" };

export default async function ReferralsPage() {
  const u = await requireUser("/account/referrals");
  const referred = await db.user.findMany({ where: { referredBy: u.referralCode }, select: { businessName: true, name: true, createdAt: true, _count: { select: { orders: true } } } });
  const h = await headers();
  const origin = `${h.get("x-forwarded-proto") ?? "http"}://${h.get("host") ?? "localhost:3000"}`;
  const link = `${origin}/register?ref=${u.referralCode}`;
  return (
    <AccountShell active="/account/referrals" title="Refer a business">
      <div className="max-w-2xl space-y-6">
        <div className="rounded-2xl bg-ink p-6 text-white">
          <p className="font-display text-2xl font-bold">Give $100, get $100</p>
          <p className="mt-1 text-sm text-white/70">When a business you refer places its first order over $1,000, you both get $100 off your next order.</p>
          <div className="mt-4 flex gap-2">
            <input readOnly value={link} className="w-full rounded-lg border border-white/20 bg-white/10 px-3.5 py-2.5 text-sm text-white" aria-label="Your referral link" />
          </div>
          <p className="mt-2 text-xs text-white/60">Your code: <span className="font-mono font-bold text-white">{u.referralCode}</span></p>
        </div>
        <div className="card p-6">
          <h2 className="font-display text-lg font-bold">Your referrals ({referred.length})</h2>
          {referred.length === 0 ? (
            <p className="mt-2 text-sm text-muted">No referrals yet. Share your link with other resellers.</p>
          ) : (
            <ul className="mt-3 divide-y divide-line text-sm">
              {referred.map((r, i) => (
                <li key={i} className="flex justify-between py-2">
                  <span>{r.businessName ?? r.name}</span>
                  <span className={r._count.orders ? "font-semibold text-moss" : "text-muted"}>{r._count.orders ? "Reward earned" : "Signed up"}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </AccountShell>
  );
}
