import Link from "next/link";

const LINKS = [
  ["/account", "Profile & address"],
  ["/account/verification", "Business verification"],
  ["/bids", "My bids"],
  ["/account/favorites", "Watchlist & sellers"],
  ["/orders", "Orders"],
  ["/messages", "Messages"],
  ["/account/referrals", "Refer a business"],
  ["/account/security", "Password & security"],
];

export function AccountNav({ active }: { active: string }) {
  return (
    <nav className="flex gap-1 overflow-x-auto lg:flex-col">
      {LINKS.map(([href, label]) => (
        <Link key={href} href={href} className={`shrink-0 rounded-lg px-3 py-2 text-sm ${active === href ? "bg-ink font-semibold text-white" : "hover:bg-sand"}`}>
          {label}
        </Link>
      ))}
    </nav>
  );
}

export function AccountShell({ active, title, children }: { active: string; title: string; children: React.ReactNode }) {
  return (
    <div className="container-pp grid gap-8 py-10 lg:grid-cols-[220px_1fr]">
      <aside><AccountNav active={active} /></aside>
      <div>
        <h1 className="mb-6 font-display text-3xl font-bold">{title}</h1>
        {children}
      </div>
    </div>
  );
}
