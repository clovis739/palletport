import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { LotCard } from "@/components/LotCard";
import { toggleFollow } from "@/app/actions/social";
import { initials } from "@/lib/format";
import { AccountShell } from "../AccountNav";

export const metadata = { title: "Saved" };

export default async function FavoritesPage() {
  const u = await requireUser("/account/favorites");
  const [favorites, follows] = await Promise.all([
    db.favorite.findMany({ where: { userId: u.id }, include: { lot: { include: { category: true, seller: true } } }, orderBy: { createdAt: "desc" } }),
    db.follow.findMany({ where: { userId: u.id }, include: { seller: { include: { _count: { select: { lots: { where: { status: "ACTIVE" } } } } } } } }),
  ]);
  return (
    <AccountShell active="/account/favorites" title="Watchlist & sellers">
      <h2 className="mb-4 font-display text-xl font-bold">Sellers you follow</h2>
      {follows.length === 0 ? (
        <p className="mb-10 text-sm text-muted">Follow sellers from their storefront to see them here.</p>
      ) : (
        <div className="mb-10 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {follows.map((f) => (
            <div key={f.id} className="card flex items-center gap-3 p-4">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-ink font-display text-sm font-bold text-white">{initials(f.seller.name)}</span>
              <Link href={`/sellers/${f.seller.slug}`} className="min-w-0 flex-1">
                <span className="block truncate font-semibold hover:underline">{f.seller.name}</span>
                <span className="text-xs text-muted">{f.seller._count.lots} live lots</span>
              </Link>
              <form action={toggleFollow}>
                <input type="hidden" name="sellerId" value={f.sellerId} />
                <input type="hidden" name="back" value="/account/favorites" />
                <button className="text-xs font-semibold text-muted hover:text-rust">Unfollow</button>
              </form>
            </div>
          ))}
        </div>
      )}
      <h2 className="mb-4 font-display text-xl font-bold">Watchlist</h2>
      {favorites.length === 0 ? (
        <p className="text-sm text-muted">Tap "Watch" on any lot to track it here. <Link href="/lots" className="font-semibold text-signal-dark">Browse lots</Link></p>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{favorites.map((f) => <LotCard key={f.id} lot={f.lot} />)}</div>
      )}
    </AccountShell>
  );
}
