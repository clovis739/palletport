import { StatusScreen } from "@/components/states/StatusScreen";

export default function LotNotFound() {
  return (
    <StatusScreen
      code={404}
      title="We can't find that lot"
      message="It may have been removed by the seller, or the link is mistyped. New lots are listed every day."
      actions={[{ href: "/auctions", label: "Browse live auctions", primary: true }, { href: "/buy-now", label: "Buy Now lots" }]}
    />
  );
}
