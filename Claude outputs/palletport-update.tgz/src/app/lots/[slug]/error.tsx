"use client";

import { ErrorScreen } from "@/components/states/ErrorScreen";

export default function LotError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <ErrorScreen
      error={error}
      reset={reset}
      title="We couldn't load this lot"
      message="The lot details or bid information failed to load. Your bids are safe — try again in a moment."
      backHref="/auctions"
      backLabel="Back to auctions"
    />
  );
}
