import { LotDetailSkeleton } from "@/components/states/PageSkeletons";

export default function Loading() {
  return <LotDetailSkeleton />;
}
