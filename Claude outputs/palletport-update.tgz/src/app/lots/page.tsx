import { LotBrowser, type SearchParams } from "@/components/browse/LotBrowser";

export const metadata = { title: "Browse all lots" };

export default async function LotsPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  return <LotBrowser sp={await searchParams} />;
}
