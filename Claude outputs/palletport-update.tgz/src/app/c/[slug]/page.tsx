import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { LotCard } from "@/components/LotCard";
import { PalletArt } from "@/components/PalletArt";
import { initials } from "@/lib/format";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  const c = await db.category.findUnique({ where: { slug }, select: { name: true } });
  return { title: c ? `${c.name} pallets` : "Category" };
}

const lotInclude = { category: true, seller: true } as const;

export default async function CategoryLanding({ params }: { params: Params }) {
  const { slug } = await params;
  const category = await db.category.findUnique({
    where: { slug },
    include: { subcategories: { orderBy: { name: "asc" }, include: { _count: { select: { lots: { where: { status: "ACTIVE" } } } } } } },
  });
  if (!category) notFound();

  const base = { categoryId: category.id, status: "ACTIVE" };
  const [newest, bestValue, sellers] = await Promise.all([
    db.lot.findMany({ where: base, include: lotInclude, orderBy: { createdAt: "desc" }, take: 8 }),
    db.lot.findMany({ where: base, include: lotInclude }),
    db.seller.findMany({ where: { lots: { some: base } }, orderBy: { rating: "desc" }, take: 6 }),
  ]);
  const value = bestValue.sort((a, b) => a.priceCents / a.msrpCents - b.priceCents / b.msrpCents).slice(0, 4);

  return (
    <>
      <section className="border-b border-line" style={{ background: `hsl(${category.hue} 45% 94%)` }}>
        <div className="container-pp grid items-center gap-8 py-12 md:grid-cols-[1.2fr_1fr]">
          <div>
            <nav className="mb-2 text-xs text-muted"><Link href="/categories" className="hover:underline">Categories</Link> / {category.name}</nav>
            <h1 className="font-display text-4xl font-bold sm:text-5xl">{category.name}</h1>
            <p className="mt-2 max-w-lg text-ink/70">{category.blurb}. Manifested pallets from verified liquidators, priced well below retail.</p>
            <Link href={`/lots?category=${category.slug}`} className="btn-dark mt-5">Shop all {category.name.toLowerCase()}</Link>
          </div>
          <PalletArt seed={`${category.slug}-hero`} hue={category.hue} className="w-full rounded-2xl" />
        </div>
      </section>

      <div className="container-pp space-y-14 py-12">
        <section>
          <h2 className="mb-4 font-display text-2xl font-bold">Shop by subcategory</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {category.subcategories.map((s) => (
              <Link key={s.id} href={`/lots?category=${category.slug}&sub=${s.slug}`} className="card p-4 transition hover:border-ink">
                <p className="font-display font-semibold">{s.name}</p>
                <p className="text-xs text-muted">{s._count.lots} lots</p>
              </Link>
            ))}
          </div>
        </section>

        <section>
          <div className="mb-4 flex items-end justify-between">
            <h2 className="font-display text-2xl font-bold">Best value right now</h2>
            <Link href={`/lots?category=${category.slug}&sort=value`} className="text-sm font-semibold text-signal-dark hover:underline">See more →</Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{value.map((l) => <LotCard key={l.id} lot={l} />)}</div>
        </section>

        <section>
          <h2 className="mb-4 font-display text-2xl font-bold">Sellers in {category.name}</h2>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {sellers.map((s) => (
              <Link key={s.id} href={`/sellers/${s.slug}`} className="card flex w-56 shrink-0 items-center gap-3 p-4 hover:border-ink">
                <span className="grid h-10 w-10 place-items-center rounded-full font-display text-sm font-bold text-white" style={{ background: `hsl(${s.bannerHue} 45% 35%)` }}>{initials(s.name)}</span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-semibold">{s.name}</span>
                  <span className="text-xs text-muted">★ {s.rating.toFixed(1)} · {s.location}</span>
                </span>
              </Link>
            ))}
          </div>
        </section>

        <section>
          <div className="mb-4 flex items-end justify-between">
            <h2 className="font-display text-2xl font-bold">Newly listed</h2>
            <Link href={`/lots?category=${category.slug}`} className="text-sm font-semibold text-signal-dark hover:underline">View all →</Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{newest.map((l) => <LotCard key={l.id} lot={l} />)}</div>
        </section>
      </div>
    </>
  );
}
