import Link from "next/link";
import { GUIDES } from "@/content/guides";
import { PalletArt } from "@/components/PalletArt";

export const metadata = { title: "Guides by store type" };

export default function GuidesIndex() {
  return (
    <div className="container-pp py-10">
      <h1 className="font-display text-4xl font-bold">Buying guides by store type</h1>
      <p className="mb-8 text-muted">What to buy — and what to skip — for the way you sell.</p>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {GUIDES.map((g) => (
          <Link key={g.slug} href={`/guides/${g.slug}`} className="group card overflow-hidden">
            <PalletArt seed={g.slug} hue={g.hue} className="aspect-[16/9] w-full" />
            <div className="p-5">
              <h2 className="font-display text-xl font-bold group-hover:text-signal-dark">{g.title}</h2>
              <p className="text-sm text-muted">{g.excerpt}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
