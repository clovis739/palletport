import Link from "next/link";
import { notFound } from "next/navigation";
import { GUIDES } from "@/content/guides";
import { getCollection } from "@/lib/collections";
import { db } from "@/lib/db";
import { Prose } from "@/components/Prose";
import { LotCard } from "@/components/LotCard";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  return { title: GUIDES.find((g) => g.slug === slug)?.title ?? "Guide" };
}

export default async function GuidePage({ params }: { params: Params }) {
  const { slug } = await params;
  const g = GUIDES.find((x) => x.slug === slug);
  if (!g) notFound();
  const lots = await db.lot.findMany({
    where: { status: "ACTIVE", category: { slug: { in: g.categories } } },
    include: { category: true, seller: true },
    orderBy: { views: "desc" },
    take: 4,
  });
  const collection = g.collection ? getCollection(g.collection) : undefined;
  return (
    <>
      <section style={{ background: `hsl(${g.hue} 45% 93%)` }}>
        <div className="container-pp py-12">
          <nav className="mb-2 text-xs text-muted"><Link href="/guides" className="hover:underline">Guides</Link></nav>
          <h1 className="font-display text-4xl font-bold">{g.title}</h1>
          <p className="mt-2 max-w-xl text-ink/70">{g.excerpt}</p>
        </div>
      </section>
      <div className="container-pp grid gap-10 py-10 lg:grid-cols-[1fr_300px]">
        <div className="max-w-2xl"><Prose body={g.body} /></div>
        {collection && (
          <aside className="card h-fit p-5">
            <p className="label">Recommended collection</p>
            <p className="font-display text-lg font-bold">{collection.title}</p>
            <p className="text-sm text-muted">{collection.tagline}</p>
            <Link href={`/collections/${collection.slug}`} className="btn-dark mt-4 w-full">Shop the collection</Link>
          </aside>
        )}
      </div>
      {lots.length > 0 && (
        <section className="container-pp pb-6">
          <h2 className="mb-4 font-display text-2xl font-bold">Popular lots for this store type</h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{lots.map((l) => <LotCard key={l.id} lot={l} />)}</div>
        </section>
      )}
    </>
  );
}
