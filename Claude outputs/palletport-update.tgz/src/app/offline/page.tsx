import { StatusScreen } from "@/components/states/StatusScreen";

export const metadata = { title: "You're offline", robots: { index: false } };

export default function Offline() {
  return (
    <StatusScreen
      code={0}
      showCode={false} artLabel="OFF"
      title="You're offline"
      message="PalletPort needs an internet connection to show live bids and prices. Reconnect and refresh the page."
      actions={[{ href: "/", label: "Retry", primary: true }]}
    />
  );
}
