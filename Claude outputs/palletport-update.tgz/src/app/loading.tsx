import { LoadingLabel } from "@/components/states/Skeleton";

// Fallback for any route without its own skeleton: a slim progress bar plus a centered loader.
export default function Loading() {
  return (
    <>
      <div className="fixed inset-x-0 top-0 z-50 h-1 overflow-hidden bg-signal/20">
        <div className="h-full w-1/3 animate-[pp-progress_1.1s_ease-in-out_infinite] bg-signal" />
      </div>
      <div className="grid min-h-[50vh] place-items-center">
        <div className="flex flex-col items-center gap-3 text-muted">
          <svg viewBox="0 0 48 48" className="h-12 w-12 animate-bounce" aria-hidden>
            <rect x="8" y="10" width="14" height="12" rx="2" fill="#13233f" />
            <rect x="26" y="10" width="14" height="12" rx="2" fill="#f0641e" />
            <rect x="6" y="24" width="36" height="6" rx="2" fill="#13233f" />
            <rect x="8" y="32" width="6" height="6" fill="#13233f" /><rect x="21" y="32" width="6" height="6" fill="#13233f" /><rect x="34" y="32" width="6" height="6" fill="#13233f" />
          </svg>
          <p className="text-sm font-semibold">Loading…</p>
          <LoadingLabel />
        </div>
      </div>
    </>
  );
}
