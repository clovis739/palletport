import Link from "next/link";
import { db } from "@/lib/db";
import { PalletArt } from "@/components/PalletArt";

export const metadata = { title: "All categories" };
export const dynamic = "force-dynamic";

export default async function CategoriesPage() {
  const categories = await db.category.findMany({
    orderBy: { name: "asc" },
    include: {
      subcategories: { orderBy: { name: "asc" }, include: { _count: { select: { lots: { where: { status: "ACTIVE" } } } } } },
      _count: { select: { lots: { where: { status: "ACTIVE" } } } },
    },
  });
  return (
    <div className="container-pp py-10">
      <h1 className="font-display text-3xl font-bold">All categories</h1>
      <p className="mb-8 text-muted">Every pallet on PalletPort, organized by what's inside.</p>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((c) => (
          <div key={c.id} className="card overflow-hidden">
            <Link href={`/c/${c.slug}`} className="block">
              <PalletArt seed={c.slug} hue={c.hue} className="aspect-[16/7] w-full" />
            </Link>
            <div className="p-5">
              <Link href={`/c/${c.slug}`} className="font-display text-xl font-bold hover:text-signal-dark">{c.name}</Link>
              <p className="text-sm text-muted">{c.blurb} · {c._count.lots} lots</p>
              <ul className="mt-3 flex flex-wrap gap-2">
                {c.subcategories.map((s) => (
                  <li key={s.id}>
                    <Link href={`/lots?category=${c.slug}&sub=${s.slug}`} className="inline-block rounded-full border border-line px-3 py-1 text-xs font-medium hover:border-ink">
                      {s.name} <span className="text-muted">({s._count.lots})</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
