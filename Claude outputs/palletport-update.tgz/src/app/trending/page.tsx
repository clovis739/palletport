import Link from "next/link";
import { db } from "@/lib/db";
import { LotCard } from "@/components/LotCard";
import { COLLECTIONS } from "@/lib/collections";

export const metadata = { title: "Trending" };
export const dynamic = "force-dynamic";

const SEARCHES = ["air fryer", "power tools", "earbuds", "office chair", "sneakers", "baby monitor", "smart home", "truckload", "cosmetics", "patio"];

export default async function Trending() {
  const [mostViewed, mostSaved] = await Promise.all([
    db.lot.findMany({ where: { status: "ACTIVE" }, include: { category: true, seller: true }, orderBy: { views: "desc" }, take: 8 }),
    db.lot.findMany({ where: { status: "ACTIVE", favorites: { some: {} } }, include: { category: true, seller: true, _count: { select: { favorites: true } } }, orderBy: { favorites: { _count: "desc" } }, take: 4 }),
  ]);

  return (
    <div className="container-pp space-y-14 py-10">
      <header>
        <h1 className="font-display text-3xl font-bold">Trending on PalletPort</h1>
        <p className="text-muted">What resellers are looking at, saving and searching for this week.</p>
      </header>

      <section>
        <h2 className="label">Popular searches</h2>
        <div className="flex flex-wrap gap-2">
          {SEARCHES.map((q) => (
            <Link key={q} href={`/lots?q=${encodeURIComponent(q)}`} className="rounded-full border border-line bg-white px-4 py-2 text-sm font-medium hover:border-ink">↗ {q}</Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="mb-4 font-display text-2xl font-bold">Most viewed</h2>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{mostViewed.map((l) => <LotCard key={l.id} lot={l} />)}</div>
      </section>

      {mostSaved.length > 0 && (
        <section>
          <h2 className="mb-4 font-display text-2xl font-bold">Most saved</h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{mostSaved.map((l) => <LotCard key={l.id} lot={l} />)}</div>
        </section>
      )}

      <section>
        <h2 className="mb-4 font-display text-2xl font-bold">Hot collections</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {COLLECTIONS.slice(0, 4).map((c) => (
            <Link key={c.slug} href={`/collections/${c.slug}`} className="rounded-2xl p-5 transition hover:-translate-y-0.5" style={{ background: `hsl(${c.hue} 45% 92%)` }}>
              <p className="font-display text-lg font-bold">{c.title}</p>
              <p className="text-sm text-ink/70">{c.tagline}</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
