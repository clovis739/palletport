import Link from "next/link";
import { InquiryForm } from "@/components/InquiryForm";

export const metadata = { title: "Contact us" };

export default function Contact() {
  return (
    <div className="container-pp grid gap-10 py-14 md:grid-cols-2">
      <div className="space-y-5">
        <h1 className="font-display text-4xl font-bold">Contact us</h1>
        <p className="text-ink/75">Questions about an order, selling on PalletPort, or a partnership? Send us a note and we'll reply within one business day.</p>
        <div className="card space-y-3 p-5 text-sm">
          <p><span className="font-semibold">Order issue?</span> Message the seller from your order first — they can usually fix it fastest.</p>
          <p><span className="font-semibold">Quick answers:</span> <Link href="/help" className="font-semibold text-signal-dark hover:underline">Help center</Link></p>
          <p><span className="font-semibold">Hours:</span> Monday–Friday, 8am–6pm ET</p>
        </div>
      </div>
      <div className="card p-6">
        <InquiryForm topic="CONTACT" submitLabel="Send message" bodyLabel="How can we help?" />
      </div>
    </div>
  );
}
