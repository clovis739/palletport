import { LotBrowser, type SearchParams } from "@/components/browse/LotBrowser";

export const metadata = { title: "Buy Now lots" };

export default async function BuyNowPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  return <LotBrowser sp={await searchParams} basePath="/buy-now" fixed={{ type: "BUY_NOW" }} heading="Buy Now" />;
}
