"use client";

import { useActionState } from "react";
import { payForWonLot } from "@/app/actions/orders";
import { SubmitButton } from "@/components/SubmitButton";

type Ship = { shipName: string; shipAddress: string; shipCity: string; shipRegion: string; shipPostal: string; shipCountry: string };

export function PayWonForm({ orderId, ship, net30Approved }: { orderId: string; ship: Ship; net30Approved: boolean }) {
  const [state, action] = useActionState(payForWonLot, undefined);
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="orderId" value={orderId} />
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="sm:col-span-2"><label className="label" htmlFor="shipName">Receiving business</label><input id="shipName" name="shipName" defaultValue={ship.shipName} className="input" required /></div>
        <div className="sm:col-span-2"><label className="label" htmlFor="shipAddress">Street address</label><input id="shipAddress" name="shipAddress" defaultValue={ship.shipAddress} className="input" required /></div>
        <div><label className="label" htmlFor="shipCity">City</label><input id="shipCity" name="shipCity" defaultValue={ship.shipCity} className="input" required /></div>
        <div><label className="label" htmlFor="shipRegion">State</label><input id="shipRegion" name="shipRegion" defaultValue={ship.shipRegion} className="input" required /></div>
        <div><label className="label" htmlFor="shipPostal">Postal code</label><input id="shipPostal" name="shipPostal" defaultValue={ship.shipPostal} className="input" required /></div>
        <div><label className="label" htmlFor="shipCountry">Country</label><input id="shipCountry" name="shipCountry" defaultValue={ship.shipCountry || "United States"} className="input" required /></div>
      </div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="dockAccess" className="accent-signal" /> Loading dock available (no liftgate)</label>
      <fieldset className="space-y-2">
        <legend className="label">Payment</legend>
        {[
          ["CARD", "Credit or debit card", true],
          ["WIRE", "Wire / ACH transfer", true],
          ["NET30", "Net 30 terms (verified resellers)", net30Approved],
        ].map(([v, l, ok], i) => (
          <label key={String(v)} className={`flex items-center gap-2 rounded-lg border border-line p-3 text-sm has-[:checked]:border-ink ${ok ? "" : "opacity-50"}`}>
            <input type="radio" name="paymentMethod" value={String(v)} defaultChecked={i === 0} disabled={!ok} className="accent-signal" /> {String(l)}
          </label>
        ))}
      </fieldset>
      {state?.error && <p className="rounded-lg bg-rust/10 p-3 text-sm font-medium text-rust">{state.error}</p>}
      <SubmitButton className="btn-primary w-full py-3" pendingText="Submitting…">Complete payment</SubmitButton>
    </form>
  );
}
