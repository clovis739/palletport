import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { money } from "@/lib/format";
import { StatusPill } from "./StatusPill";

export const metadata = { title: "Your orders" };

export default async function OrdersPage() {
  const user = await requireUser("/orders");
  const orders = await db.order.findMany({ where: { userId: user.id }, include: { items: true }, orderBy: { createdAt: "desc" } });

  return (
    <div className="container-pp py-10">
      <h1 className="mb-6 font-display text-3xl font-bold">Your orders</h1>
      {orders.length === 0 ? (
        <div className="card p-12 text-center">
          <p className="font-display text-lg font-semibold">No orders yet</p>
          <Link href="/lots" className="btn-primary mt-4">Browse lots</Link>
        </div>
      ) : (
        <div className="card divide-y divide-line">
          {orders.map((o) => (
            <Link key={o.id} href={`/orders/${o.id}`} className="flex flex-wrap items-center gap-4 p-5 hover:bg-sand/40">
              <div className="min-w-0 flex-1">
                <p className="font-mono text-sm font-semibold">{o.number}</p>
                <p className="text-xs text-muted">{o.createdAt.toLocaleDateString()} · {o.items.length} lot{o.items.length > 1 ? "s" : ""}</p>
              </div>
              <StatusPill status={o.status} />
              <p className="w-28 text-right font-display font-bold">{money(o.totalCents)}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
