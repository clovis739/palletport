import Link from "next/link";
import { db } from "@/lib/db";
import { COLLECTIONS } from "@/lib/collections";
import { PalletArt } from "@/components/PalletArt";

export const metadata = { title: "Collections" };
export const dynamic = "force-dynamic";

export default async function CollectionsPage() {
  const counts = await Promise.all(COLLECTIONS.map((c) => db.lot.count({ where: { ...c.where, status: "ACTIVE" } })));
  return (
    <div className="container-pp py-10">
      <h1 className="font-display text-3xl font-bold">Collections</h1>
      <p className="mb-8 text-muted">Curated groups of lots for specific store types, budgets and seasons.</p>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {COLLECTIONS.map((c, i) => (
          <Link key={c.slug} href={`/collections/${c.slug}`} className="group card overflow-hidden">
            <PalletArt seed={c.slug} hue={c.hue} className="aspect-[4/3] w-full" />
            <div className="p-4">
              <p className="font-display text-lg font-bold group-hover:text-signal-dark">{c.title}</p>
              <p className="text-sm text-muted">{c.tagline}</p>
              <p className="mt-2 text-xs font-semibold">{counts[i]} lots →</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
