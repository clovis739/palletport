import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { COLLECTIONS, getCollection } from "@/lib/collections";
import { LotCard } from "@/components/LotCard";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  return { title: getCollection(slug)?.title ?? "Collection" };
}

export default async function CollectionPage({ params }: { params: Params }) {
  const { slug } = await params;
  const c = getCollection(slug);
  if (!c) notFound();
  const lots = await db.lot.findMany({
    where: { ...c.where, status: "ACTIVE" },
    include: { category: true, seller: true },
    orderBy: c.orderBy ?? { createdAt: "desc" },
    take: 48,
  });
  const others = COLLECTIONS.filter((x) => x.slug !== c.slug).slice(0, 4);

  return (
    <>
      <section style={{ background: `hsl(${c.hue} 45% 92%)` }}>
        <div className="container-pp py-12">
          <nav className="mb-2 text-xs text-muted"><Link href="/collections" className="hover:underline">Collections</Link> / {c.title}</nav>
          <h1 className="font-display text-4xl font-bold">{c.title}</h1>
          <p className="mt-1 max-w-xl text-ink/70">{c.tagline}</p>
          <p className="mt-3 text-sm font-semibold">{lots.length} lots</p>
        </div>
      </section>
      <div className="container-pp py-10">
        {lots.length ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{lots.map((l) => <LotCard key={l.id} lot={l} />)}</div>
        ) : (
          <p className="card p-10 text-center text-muted">No lots in this collection right now.</p>
        )}
        <h2 className="mb-4 mt-14 font-display text-xl font-bold">More collections</h2>
        <div className="grid gap-3 sm:grid-cols-4">
          {others.map((o) => (
            <Link key={o.slug} href={`/collections/${o.slug}`} className="rounded-2xl p-4 font-display font-semibold hover:underline" style={{ background: `hsl(${o.hue} 45% 92%)` }}>{o.title}</Link>
          ))}
        </div>
      </div>
    </>
  );
}
