import type { Article } from "./types";

// Starter policy text written for PalletPort. Have a lawyer review before launch.
export const LEGAL: Article[] = [
  {
    slug: "terms", title: "Terms of Service", date: "2026-09-23", excerpt: "The rules for using PalletPort as a buyer or seller.",
    body: [
      { h: "1. The marketplace", p: ["PalletPort connects businesses that sell liquidation inventory (\"Sellers\") with businesses that buy it for resale (\"Buyers\"). PalletPort is not the seller of record for lots listed by Sellers."] },
      { h: "2. Business accounts", p: ["Accounts are for businesses. You confirm that you are buying or selling for business purposes and that the information you give us is accurate."] },
      { h: "3. Listings and condition", p: ["Sellers must describe lots accurately, including condition grade and manifest. Lots are sold as-is according to the listed grade. Manifest counts may vary slightly; see the Returns & Disputes policy for remedies."] },
      { h: "4. Orders and payment", p: ["An order is a binding offer to buy. Payment is taken by the method you select. Net 30 terms are available only to approved Buyers and are due 30 days after delivery."] },
      { h: "5. Fees", p: ["Sellers pay a commission on completed sales as shown in the Seller hub. We will give notice before changing fees."] },
      { h: "6. Prohibited items", p: ["Sellers may not list recalled, counterfeit, stolen or hazardous goods, or items whose sale is restricted by law."] },
      { h: "7. Liability", p: ["To the extent permitted by law, PalletPort's liability for any claim is limited to the fees we received for the transaction concerned."] },
      { h: "8. Changes", p: ["We may update these terms. Continued use after an update means you accept the new terms."] },
    ],
  },
  {
    slug: "privacy", title: "Privacy Policy", date: "2026-09-23", excerpt: "What we collect, why, and your choices.",
    body: [
      { h: "What we collect", list: ["Account details: name, business name, email, phone and addresses.", "Verification details: resale certificate number and issuing state.", "Transaction details: orders, messages and reviews.", "Usage data: pages viewed and lots saved, used to improve the marketplace."] },
      { h: "How we use it", p: ["To run the marketplace, process orders, verify businesses, prevent fraud, and send service messages. We share delivery details with the Seller and carrier needed to fulfil your order."] },
      { h: "Your choices", p: ["You can update your details in your account at any time and ask us to delete your account by contacting support. We keep transaction records as required by law."] },
    ],
  },
  {
    slug: "cookies", title: "Cookie Policy", date: "2026-09-23", excerpt: "The small number of cookies we use.",
    body: [
      { p: ["PalletPort uses a session cookie to keep you signed in and a short-lived cookie to remember a promo code in your cart. We do not use advertising cookies. If you add analytics later, list those tools here."] },
    ],
  },
  {
    slug: "returns-and-disputes", title: "Returns & Disputes", date: "2026-09-23", excerpt: "What happens when a lot isn't as described.",
    body: [
      { h: "As-is sales", p: ["Liquidation lots are sold as-is according to their condition grade. Individual defective units within a returns or salvage lot are not grounds for a refund."] },
      { h: "When you're covered", list: ["The received retail value is more than 10% below the manifest total.", "The lot is a different category or condition grade than listed.", "The shipment was damaged in transit and noted on the delivery receipt."] },
      { h: "How to raise a dispute", p: ["Message the Seller within 7 days of delivery with photos. If you can't agree a resolution within 5 business days, contact PalletPort support and we will review the evidence and decide."] },
    ],
  },
  {
    slug: "prohibited-items", title: "Prohibited Items", date: "2026-09-23", excerpt: "What can't be sold on PalletPort.",
    body: [{ list: ["Recalled products", "Counterfeit or infringing goods", "Stolen property", "Weapons, ammunition and explosives", "Hazardous materials that require special freight handling", "Prescription drugs and medical devices that require a license", "Expired food, supplements or cosmetics"] }],
  },
  {
    slug: "intellectual-property", title: "Intellectual Property Policy", date: "2026-09-23", excerpt: "Reporting listings that infringe your rights.",
    body: [{ p: ["If you believe a listing infringes your trademark or copyright, send us the listing URL, a description of your rights, and your contact details. We will review promptly and may remove listings and suspend repeat infringers."] }],
  },
  {
    slug: "accessibility", title: "Accessibility Statement", date: "2026-09-23", excerpt: "Our commitment to an accessible marketplace.",
    body: [{ p: ["We aim to meet WCAG 2.1 AA across PalletPort. If something is hard to use with assistive technology, contact us and tell us the page and what happened — we'll work on a fix and help you complete your task in the meantime."] }],
  },
];
