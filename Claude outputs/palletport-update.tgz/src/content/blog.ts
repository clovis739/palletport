import type { Article } from "./types";

export const BLOG_CATEGORIES = ["Buying guides", "Industry insights", "Market reports", "Seller tips", "Reseller stories"];

export const AUTHORS: Record<string, { name: string; role: string; bio: string }> = {
  team: { name: "PalletPort Editorial", role: "Marketplace team", bio: "Our buyer-success and marketplace teams write about what they see across thousands of lots every month." },
  sourcing: { name: "PalletPort Sourcing Desk", role: "Seller partnerships", bio: "The team that onboards liquidators and returns processors, and reviews every new seller." },
  freight: { name: "PalletPort Logistics", role: "Freight & fulfilment", bio: "Our logistics specialists help buyers and sellers move pallets and truckloads across the country." },
};

export const POSTS: Article[] = [
  {
    slug: "liquidation-myths-vs-facts", category: "Industry insights", date: "2026-09-20", readMins: 11, hue: 250, author: "team", featured: true,
    tags: ["Getting started", "Risk", "Sourcing"],
    title: "Liquidation myths vs. facts: what new resellers get wrong",
    excerpt: "Is it all broken junk? Do you need a warehouse and a huge budget? We take the most common beliefs about liquidation stock and check them against what actually happens on the dock.",
    body: [
      { p: ["Liquidation has a reputation problem. Ask ten people what's on a returns pallet and you'll hear 'broken stuff nobody wanted' from at least half of them. The reality is more nuanced — and much more useful to understand if you want to make money reselling. Here are the beliefs we hear most often from new buyers, and what the data from our own marketplace suggests instead."] },
      { h: "Myth: Liquidation stock is mostly broken", p: [
        "Fact: condition varies enormously, and it's labelled. A pallet of new overstock is typically sealed retail product that simply didn't sell through fast enough. Shelf pulls are store-display items that may carry stickers or scuffed boxes. Customer returns are the true grab-bag — many units work perfectly and were returned for reasons like 'changed my mind'.",
        "The key is that every lot on PalletPort carries a condition grade. Buy the grade that matches your channel, and your 'broken' rate becomes predictable rather than a surprise.",
      ] },
      { h: "Myth: Every liquidation deal is a steal", p: [
        "Fact: price vs. retail is only half the equation. A lot at 12% of retail can still lose money if half the units need testing, the freight is expensive, or the items are slow sellers in your area.",
        "Compare on landed cost per sellable unit: (bid or price + freight) ÷ units you realistically expect to sell. That number, not the headline discount, tells you whether it's a deal.",
      ] },
      { h: "Myth: You need a big budget to start", p: [
        "Fact: case packs and single pallets let you start small. Many first-time buyers begin with lots under $1,000 and reinvest their profits.",
        "Starting small also means your mistakes are cheap. Your first three lots are as much about learning your recovery rate as they are about profit.",
      ] },
      { h: "Myth: You need a warehouse or a shop", p: [
        "Fact: plenty of successful resellers work from a garage, a storage unit, or a shared space and sell entirely online or at weekend markets. Case packs ship by parcel to a home address; pallets can be delivered by liftgate truck.",
        "What you do need is a plan for where each item goes — listing, testing, parts, donation — before the pallet arrives.",
      ] },
      { h: "Myth: Bigger lots are always better value", p: [
        "Fact: truckloads usually have a lower cost per unit, but they also tie up more cash and more space, and the variety can be harder to sell through. The best-value lot is the biggest one you can turn over within your normal selling cycle.",
      ] },
      { h: "Myth: Unmanifested pallets are never worth it", p: [
        "Fact: they can be — for the right buyer. Bin stores that sell by the item often do well with mixed, unsorted loads because variety is the attraction. If you sell online, a full manifest is worth paying for because it lets you research prices before you bid.",
      ] },
      { h: "Myth: Once you buy, you're stuck with it", p: [
        "Fact: lots are sold as-is according to their grade, but that doesn't mean you have no protection. On PalletPort, if the retail value you receive is materially below the manifest, or the lot isn't the listed category or grade, you can open a dispute. Always inspect and photograph pallets on delivery.",
      ] },
      { h: "Myth: Margins are too thin to bother", p: [
        "Fact: margins depend on your channel, speed and labour. Resellers who know their categories, list quickly and price with recent sold data regularly recover several times their landed cost. Those who buy randomly and let stock sit usually don't.",
      ] },
      { h: "Myth: Liquidation is a passing trend", p: [
        "Fact: returns and overstock are built into modern retail. As online shopping grows, so do returns — and retailers need reliable ways to recover value from them. That steady supply is what makes liquidation a durable business rather than a fad.",
      ] },
      { h: "Myth: You can't build a brand on liquidation stock", p: [
        "Fact: many resellers build loyal followings around curation — 'the best kitchen finds every Friday' or 'tested tools with a 30-day guarantee'. Your brand is the experience you add: testing, cleaning, honest descriptions and service.",
      ] },
      { h: "Myth: Anyone can sell anything — no checks needed", p: [
        "Fact: a trustworthy marketplace verifies both sides. Sellers should be vetted before they list, and buyers should be real businesses. On PalletPort, verified sellers carry a badge, and buyers can submit resale certificates to unlock terms and tax-exempt purchasing.",
      ] },
      { h: "The bottom line", p: [
        "Liquidation isn't a lottery and it isn't a guaranteed win. It's a sourcing channel that rewards buyers who read manifests, understand condition grades, price in freight and know their customers. Start with a lot you can afford to learn from, track your results, and scale what works.",
      ] },
    ],
  },
  {
    slug: "how-to-read-a-manifest", category: "Buying guides", date: "2026-09-18", readMins: 7, hue: 45, author: "sourcing",
    tags: ["Manifests", "Research"],
    title: "How to read a liquidation manifest in 10 minutes",
    excerpt: "A manifest is a list, not a promise — but read correctly it tells you almost everything about a lot's real value.",
    body: [
      { p: ["Every PalletPort lot includes a manifest: SKU, item name, quantity and unit retail price. Here's a fast routine for turning that table into a buying decision."] },
      { h: "1. Sort by extended retail", p: ["Click the 'Ext. retail' column. In most lots the top 3–5 lines carry more than half the value. Those are the items to research first."] },
      { h: "2. Check real resale prices", p: ["Look up recent sold prices (not asking prices) for the top lines. Multiply by quantity and by your expected sell-through rate for the condition grade."] },
      { h: "3. Watch for inflated MSRP", p: ["Retail values come from the original seller's system. If an item's 'retail' looks far above what it's ever sold for, discount it in your maths."] },
      { h: "4. Count distinct SKUs", p: ["Many units of a few SKUs are easier to list (one listing, many sales). Hundreds of single units mean more listing labour."] },
      { h: "5. Estimate landed cost", p: ["Use the shipping estimator on the lot page with your ZIP. Add your expected bid or price. Divide by the units you realistically expect to sell."] },
      { h: "6. Download it", p: ["Use 'Download manifest (CSV)' to keep a copy, add your own price research columns, and compare lots side by side."] },
    ],
  },
  {
    slug: "auction-bidding-strategy", category: "Buying guides", date: "2026-09-12", readMins: 6, hue: 215, author: "team",
    tags: ["Auctions", "Bidding"],
    title: "Bidding strategy: how to win auctions without overpaying",
    excerpt: "Set your maximum once, let proxy bidding do the work, and walk away from lots that don't fit your numbers.",
    body: [
      { h: "Decide your maximum before you look at the current bid", p: ["Work out landed cost per sellable unit first (see our manifest guide). Your maximum bid is the number that still leaves the margin you need. Write it down."] },
      { h: "Enter your true maximum early", p: ["PalletPort uses proxy bidding and a two-minute soft close, so last-second sniping gives no advantage. Enter your real maximum; the system bids only as much as needed."] },
      { h: "Use the watchlist", p: ["Watch several similar lots and bid on the ones where competition stays low. There's always another pallet."] },
      { h: "Check 'Recently sold'", p: ["Closed auctions show what similar lots actually went for. If comparable lots closed below your maximum, don't chase this one above it."] },
      { h: "Remember Buy Now", p: ["If an auction has a Buy Now price below your maximum, it can be cheaper to take it and skip the bidding entirely."] },
    ],
  },
  {
    slug: "ltl-freight-101", category: "Buying guides", date: "2026-09-08", readMins: 8, hue: 10, author: "freight",
    tags: ["Freight", "Receiving"],
    title: "LTL freight 101 for first-time pallet buyers",
    excerpt: "Docks, liftgates, residential fees and what to do when the truck arrives — explained simply.",
    body: [
      { h: "What LTL means", p: ["Less-than-truckload freight shares a trailer between several shippers. It's the standard way to move 1–6 pallets and is priced by distance, weight and extra services."] },
      { h: "Dock vs. liftgate", p: ["A loading dock lets the carrier roll pallets straight off the trailer. Without one, you need a liftgate truck, which lowers pallets to the ground for an extra fee. You'll need a pallet jack either way."] },
      { h: "Residential deliveries", p: ["Deliveries to homes and farms carry a residential surcharge and may require an appointment. Tell us at checkout so the quote is accurate."] },
      { h: "On delivery day", list: ["Count pallets against the bill of lading.", "Look for crushed corners, torn wrap or leaning stacks.", "Write any damage on the delivery receipt before you sign.", "Photograph everything before unwrapping."] },
      { h: "Truckloads", p: ["Full truckloads need a dock and a forklift, and usually a delivery appointment. They're the cheapest per unit for high-volume buyers."] },
    ],
  },
  {
    slug: "liquidation-and-sustainability", category: "Industry insights", date: "2026-09-01", readMins: 5, hue: 150, author: "team",
    tags: ["Sustainability"],
    title: "Why reselling returns is one of the greenest things in retail",
    excerpt: "Every pallet that finds a reseller is one less load heading to landfill.",
    body: [
      { p: ["Returned and unsold goods have to go somewhere. Without a resale channel, a surprising amount is destroyed or landfilled simply because it's cheaper than processing it."] },
      { h: "Keeping goods in use", p: ["Liquidation moves products to businesses that can test, repair, clean and resell them — extending their life and reducing the demand for new manufacturing."] },
      { h: "Local impact", p: ["Bin stores, thrift shops and market vendors bring affordable goods to their communities and create local jobs sorting, testing and selling."] },
      { h: "What you can do", list: ["Offer testing and honest grading so fewer items are returned again.", "Sell parts from salvage items.", "Donate what you can't sell rather than binning it."] },
    ],
  },
  {
    slug: "grading-customer-returns", category: "Seller tips", date: "2026-08-22", readMins: 6, hue: 330, author: "sourcing",
    tags: ["Grading", "Listings"],
    title: "Grading customer returns consistently: a seller's checklist",
    excerpt: "Consistent grading builds repeat buyers. Here's the process our top-rated sellers use.",
    body: [
      { h: "Separate before you pallet", p: ["Sort returns into new-in-box, open-box, and untested before building pallets. Mixing grades on one pallet is fine — just label it 'Mixed' and say so in the description."] },
      { h: "Spot-check and say so", p: ["Test a sample of electronics and tools and state the result ('7 of 10 sampled units powered on'). Buyers trust numbers."] },
      { h: "Photograph the build", p: ["Photos of the pallet before wrapping reduce disputes more than anything else."] },
      { h: "Match the manifest to the pallet", p: ["Scan items as they go on the pallet. An accurate manifest is the single biggest driver of five-star reviews."] },
    ],
  },

  {
    slug: "first-pallet-checklist", category: "Buying guides", date: "2026-09-15", readMins: 6, hue: 24,
    title: "Your first liquidation pallet: a 10-point checklist",
    excerpt: "How to pick a first lot you can actually sell, without getting burned on freight or condition.",
    body: [
      { p: ["Your first pallet sets the tone for your margins. Start small, pick a category you already understand, and treat the first lot as tuition as much as inventory."] },
      { h: "Before you buy", list: [
        "Choose a category you can price quickly — you should know roughly what each item resells for.",
        "Read the full manifest. Sort by extended MSRP and look at the top five lines: they carry most of the value.",
        "Match the condition grade to your channel. Customer returns suit bin stores and refurbishers; new overstock suits online marketplaces.",
        "Check the seller's reviews and whether they photograph pallets before shipping.",
        "Price in freight. At $175 per pallet, a $400 lot really costs $575.",
      ] },
      { h: "When it arrives", list: [
        "Inspect before you sign the delivery receipt.",
        "Photograph the pallet before you unwrap it.",
        "Sort into sell-now, test, and parts piles on day one.",
        "Track the actual resale of every unit for your first three pallets.",
        "Compare real recovery against the manifest value — that's your personal benchmark.",
      ] },
    ],
  },
  {
    slug: "returns-vs-shelf-pulls", category: "Buying guides", date: "2026-09-02", readMins: 5, hue: 215,
    title: "Customer returns vs. shelf pulls: which is right for your store?",
    excerpt: "Cheaper isn't always better. How condition grade changes your labor, risk and margin.",
    body: [
      { p: ["Customer returns typically sell for 10–20% of retail, shelf pulls for 20–30%. The gap looks like free margin, but returns come with testing time and a defect rate you have to absorb."] },
      { h: "When returns win", p: ["If you run a bin store or repair shop, your labor already handles mixed quality. Returns maximize units per dollar and the defect rate is priced in."] },
      { h: "When shelf pulls win", p: ["If you sell online, every defective unit costs you a return label and a bad review. Shelf pulls and new overstock cost more up front but list faster with fewer surprises."] },
      { h: "A quick rule of thumb", p: ["Estimate your hourly labor cost and the minutes it takes to test and list one unit. If that cost per unit exceeds the price difference between grades, buy the higher grade."] },
    ],
  },
  {
    slug: "q4-market-report-2026", category: "Market reports", date: "2026-09-10", readMins: 7, hue: 330,
    title: "Market report: what's moving into Q4",
    excerpt: "Seasonal overstock is arriving early. Here's where supply is heavy and where it's thin.",
    body: [
      { p: ["This report summarizes listing and sell-through patterns on PalletPort over the past 60 days. Figures describe our marketplace only and are directional, not a forecast."] },
      { h: "Where supply is heavy", list: ["Small kitchen appliances — plentiful, with average pricing at the low end of the historical range.", "Outdoor and patio — end-of-season lots are clearing at steep discounts.", "Phone accessories — high unit counts, low per-unit values."] },
      { h: "Where supply is thin", list: ["Toys and games — lots are selling within days of listing ahead of the holidays.", "Cordless power tools — shelf-pull tool lots remain in demand."] },
      { h: "What it means for buyers", p: ["If you stock for the holidays, buy toys now rather than in November. Patio and outdoor lots are a good speculative buy to hold for spring if you have storage."] },
    ],
  },
  {
    slug: "electronics-sell-through", category: "Market reports", date: "2026-08-20", readMins: 4, hue: 250,
    title: "Electronics sell-through: audio leads, smart home lags",
    excerpt: "Earbud and headphone lots are the fastest movers in electronics this summer.",
    body: [
      { p: ["Audio lots sold fastest among electronics subcategories on PalletPort this summer, while smart-home lots sat longer — likely because compatibility questions make them harder to resell."] },
      { h: "Takeaway", p: ["If you buy smart-home returns, budget time to reset and test devices, and list them with clear compatibility notes."] },
    ],
  },
  {
    slug: "writing-manifests-that-sell", category: "Seller tips", date: "2026-09-05", readMins: 5, hue: 150,
    title: "Manifests that sell: 7 habits of top sellers",
    excerpt: "Clear manifests reduce questions, disputes and time-to-sale.",
    body: [
      { list: [
        "Lead with the highest-value lines — buyers skim the top.",
        "Use searchable product names, not internal codes.",
        "Count units, not cartons.",
        "Use realistic retail values.",
        "Say whether items were tested, and how.",
        "Add a photo note in the description, even if you can't upload photos yet.",
        "Answer buyer messages within a business day — responsiveness shows in your reviews.",
      ] },
    ],
  },
  {
    slug: "pricing-your-lots", category: "Seller tips", date: "2026-08-28", readMins: 6, hue: 45,
    title: "How to price a pallet so it sells in 48 hours",
    excerpt: "Percent-of-retail is where buyers start. Here's how to land in the sweet spot.",
    body: [
      { p: ["Buyers compare lots by percent of retail and by price per unit. Check comparable live lots in your category and condition before you set a price."] },
      { h: "Typical ranges on PalletPort", list: ["New / overstock: 25–40% of retail", "Shelf pulls: 20–30%", "Customer returns: 10–20%", "Salvage: 5–10%"] },
      { h: "Use promos instead of price cuts", p: ["A first-order promo code brings in new buyers without permanently lowering your listed price."] },
    ],
  },
  {
    slug: "bin-store-from-zero", category: "Reseller stories", date: "2026-08-12", readMins: 8, hue: 90,
    title: "From garage sales to a 4,000 sq ft bin store",
    excerpt: "An illustrative story of how one reseller scaled from single pallets to weekly truckloads.",
    body: [
      { p: ["This is a composite story drawn from common reseller journeys, shared to show how buying habits change as a store grows."] },
      { h: "Year one: one pallet at a time", p: ["The owner bought one mixed-returns pallet every two weeks, sold at weekend markets and kept a spreadsheet of recovery per pallet."] },
      { h: "Year two: a storefront and a schedule", p: ["With a lease came a weekly restock day. Buying shifted to high-unit-count lots that could fill bins, and to a small set of sellers with consistent grading."] },
      { h: "Year three: truckloads", p: ["Volume pricing and free freight thresholds made multi-pallet lots cheaper per unit. The owner now reserves one truckload a week from two trusted sellers."] },
    ],
  },
];
