export type Section = { h?: string; p?: string[]; list?: string[] };
export type Article = {
  slug: string;
  title: string;
  excerpt: string;
  category?: string;
  date?: string; // ISO
  readMins?: number;
  hue?: number;
  author?: string;
  tags?: string[];
  featured?: boolean;
  body: Section[];
};
