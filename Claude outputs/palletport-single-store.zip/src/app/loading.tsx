import { LoadingLabel } from "@/components/states/Skeleton";
import { Loader2, Package } from "lucide-react";

// Fallback for any route without its own skeleton: a slim progress bar plus a centered loader.
export default function Loading() {
  return (
    <>
      <div className="fixed inset-x-0 top-0 z-50 h-1 overflow-hidden bg-signal/20">
        <div className="h-full w-1/3 animate-[pp-progress_1.1s_ease-in-out_infinite] bg-signal" />
      </div>
      <div className="grid min-h-[50vh] place-items-center">
        <div className="flex flex-col items-center gap-3 text-muted">
          <Package aria-hidden className="h-12 w-12 animate-bounce text-ink" strokeWidth={1.5} />
          <p className="inline-flex items-center gap-2 text-sm font-semibold"><Loader2 aria-hidden className="h-4 w-4 animate-spin" /> Loading…</p>
          <LoadingLabel />
        </div>
      </div>
    </>
  );
}
