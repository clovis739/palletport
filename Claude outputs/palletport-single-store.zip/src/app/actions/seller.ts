"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { getStore } from "@/lib/store";
import { slugify } from "@/lib/format";
import type { FormState } from "./auth";

/** Only the admin (business owner/staff) can manage the store. Returns the company store record. */
async function storeFor(next: string) {
  const session = await getSession();
  if (!session) redirect(`/login?next=${next}`);
  const user = await db.user.findUnique({ where: { id: session.userId }, select: { role: true } });
  if (user?.role !== "ADMIN") redirect("/");
  return getStore();
}

const manifestLine = z.object({ sku: z.string(), name: z.string().min(1), qty: z.number().int().positive(), unitMsrpCents: z.number().int().nonnegative() });

const lotSchema = z.object({
  title: z.string().trim().min(5, "Title is too short"),
  description: z.string().trim().min(20, "Description is too short"),
  categoryId: z.string().min(1, "Choose a category"),
  subcategoryId: z.string().optional(),
  condition: z.enum(["NEW", "SHELF_PULL", "CUSTOMER_RETURN", "MIXED", "SALVAGE"]),
  saleType: z.enum(["AUCTION", "BUY_NOW"]).default("BUY_NOW"),
  lotSize: z.enum(["CASE", "PALLET", "TRUCKLOAD"]).default("PALLET"),
  source: z.string().trim().optional().default(""),
  price: z.coerce.number().positive("Enter a price or starting bid"),
  buyNow: z.coerce.number().min(0).optional(),
  durationDays: z.coerce.number().int().min(1).max(10).default(3),
  palletCount: z.coerce.number().int().min(1).max(26),
  weightLbs: z.coerce.number().int().min(1, "Enter a weight"),
  available: z.coerce.number().int().min(1).max(100),
  manifest: z.string().trim().min(1, "Add at least one manifest line"),
});

// Manifest is pasted as CSV lines: name, qty, unit MSRP (USD) [, sku]
function parseManifest(text: string) {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((line, i) => {
      const [name, qty, msrp, sku] = line.split(",").map((s) => s.trim());
      return manifestLine.parse({
        name,
        qty: Number(qty),
        unitMsrpCents: Math.round(Number(msrp) * 100),
        sku: sku || `LINE-${i + 1}`,
      });
    });
}

export async function createLot(_: FormState, formData: FormData): Promise<FormState> {
  const seller = await storeFor("/dashboard/new");

  const parsed = lotSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const d = parsed.data;

  let manifest;
  try {
    manifest = parseManifest(d.manifest);
  } catch {
    return { error: "Manifest lines must look like: Item name, quantity, unit MSRP" };
  }

  const msrpCents = manifest.reduce((a, m) => a + m.qty * m.unitMsrpCents, 0);
  const units = manifest.reduce((a, m) => a + m.qty, 0);

  const auction = d.saleType === "AUCTION";
  if (auction && d.buyNow && d.buyNow <= d.price) return { error: "Buy Now price must be higher than the starting bid" };
  const lot = await db.lot.create({
    data: {
      slug: `${slugify(d.title)}-${Date.now().toString(36)}`,
      title: d.title,
      description: d.description,
      condition: d.condition,
      saleType: d.saleType,
      lotSize: d.lotSize,
      source: d.source,
      ...(auction
        ? {
            startPriceCents: Math.round(d.price * 100),
            buyNowCents: d.buyNow ? Math.round(d.buyNow * 100) : null,
            endsAt: new Date(Date.now() + d.durationDays * 86400000),
          }
        : {}),
      priceCents: Math.round(d.price * 100),
      msrpCents,
      units,
      palletCount: d.palletCount,
      weightLbs: d.weightLbs,
      available: auction ? 1 : d.available,
      shipsFrom: seller.location,
      categoryId: d.categoryId,
      subcategoryId: d.subcategoryId || null,
      sellerId: seller.id,
      manifest: { create: manifest },
    },
  });
  revalidatePath("/lots");
  redirect(`/lots/${lot.slug}`);
}

export async function setLotStatus(formData: FormData) {
  const seller = await storeFor("/dashboard");
  const id = String(formData.get("id"));
  const status = String(formData.get("status"));
  if (!["ACTIVE", "DRAFT"].includes(status)) return;
  await db.lot.updateMany({ where: { id, sellerId: seller.id }, data: { status } });
  revalidatePath("/dashboard");
}

export async function updateOrderStatus(formData: FormData) {
  const seller = await storeFor("/dashboard");
  const orderId = String(formData.get("orderId"));
  const status = String(formData.get("status"));
  if (!["CONFIRMED", "SHIPPED", "DELIVERED"].includes(status)) return;
  const trackingNo = String(formData.get("trackingNo") ?? "").trim();
  const owns = await db.orderItem.findFirst({ where: { orderId, sellerId: seller.id } });
  if (!owns) return;
  await db.order.update({ where: { id: orderId }, data: { status, ...(trackingNo ? { trackingNo } : {}) } });
  revalidatePath("/dashboard");
}

export async function updateLot(_: FormState, formData: FormData): Promise<FormState> {
  const id = String(formData.get("id"));
  const seller = await storeFor(`/dashboard/lots/${id}`);
  const lot = await db.lot.findFirst({ where: { id, sellerId: seller.id } });
  if (!lot) return { error: "Lot not found" };
  const parsed = lotSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const d = parsed.data;
  if (lot.saleType === "AUCTION" && lot.bidCount > 0) {
    return { error: "This auction has bids, so it can't be edited. Message bidders or contact support to cancel it." };
  }
  let manifest;
  try {
    manifest = parseManifest(d.manifest);
  } catch {
    return { error: "Manifest lines must look like: Item name, quantity, unit MSRP" };
  }
  const auction = d.saleType === "AUCTION";
  if (auction && d.buyNow && d.buyNow <= d.price) return { error: "Buy Now price must be higher than the starting bid" };
  await db.$transaction([
    db.manifestItem.deleteMany({ where: { lotId: id } }),
    db.lot.update({
      where: { id },
      data: {
        title: d.title,
        description: d.description,
        condition: d.condition,
        saleType: d.saleType,
        lotSize: d.lotSize,
        source: d.source,
        priceCents: Math.round(d.price * 100),
        startPriceCents: auction ? Math.round(d.price * 100) : null,
        buyNowCents: auction && d.buyNow ? Math.round(d.buyNow * 100) : null,
        // Editing an auction (or relisting an ended one) restarts the clock.
        endsAt: auction ? new Date(Date.now() + d.durationDays * 86400000) : null,
        leaderId: null,
        leaderMaxCents: null,
        palletCount: d.palletCount,
        weightLbs: d.weightLbs,
        available: auction ? 1 : d.available,
        status: (lot.status === "SOLD_OUT" && d.available > 0 && !auction) || lot.status === "ENDED" ? "ACTIVE" : lot.status,
        categoryId: d.categoryId,
        subcategoryId: d.subcategoryId || null,
        msrpCents: manifest.reduce((a, m) => a + m.qty * m.unitMsrpCents, 0),
        units: manifest.reduce((a, m) => a + m.qty, 0),
        manifest: { create: manifest },
      },
    }),
  ]);
  revalidatePath("/dashboard");
  redirect(`/lots/${lot.slug}`);
}

export async function deleteLot(formData: FormData) {
  const seller = await storeFor("/dashboard");
  const id = String(formData.get("id"));
  const sold = await db.orderItem.count({ where: { lotId: id } });
  if (sold > 0) {
    // Keep order history intact; just hide it.
    await db.lot.updateMany({ where: { id, sellerId: seller.id }, data: { status: "DRAFT" } });
  } else {
    await db.lot.deleteMany({ where: { id, sellerId: seller.id } });
  }
  revalidatePath("/dashboard");
  redirect("/dashboard");
}

const storeSchema = z.object({
  name: z.string().trim().min(2, "Enter your business name"),
  location: z.string().trim().min(2, "Enter your warehouse city"),
  bio: z.string().trim().min(20, "Tell buyers a bit more (20+ characters)"),
  minOrder: z.coerce.number().min(0).default(0),
});

export async function updateStore(_: FormState, formData: FormData): Promise<FormState> {
  const seller = await storeFor("/dashboard/settings");
  const parsed = storeSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const { minOrder, ...rest } = parsed.data;
  await db.seller.update({
    where: { id: seller.id },
    data: { ...rest, minOrderCents: Math.round(minOrder * 100), pickup: formData.get("pickup") === "on" },
  });
  revalidatePath("/dashboard/settings");
  revalidatePath("/", "layout");
  return { error: undefined };
}

const promoSchema = z.object({
  code: z.string().trim().toUpperCase().regex(/^[A-Z0-9]{4,20}$/, "Codes are 4–20 letters or numbers"),
  kind: z.enum(["percent", "amount"]),
  value: z.coerce.number().positive("Enter a discount value"),
  minSubtotal: z.coerce.number().min(0).default(0),
  description: z.string().trim().optional().default(""),
});

export async function createPromo(_: FormState, formData: FormData): Promise<FormState> {
  const seller = await storeFor("/dashboard/promotions");
  const parsed = promoSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const d = parsed.data;
  if (d.kind === "percent" && d.value > 50) return { error: "Percentage discounts are capped at 50%" };
  if (await db.promo.findUnique({ where: { code: d.code } })) return { error: "That code is taken" };
  await db.promo.create({
    data: {
      code: d.code,
      sellerId: seller.id,
      description: d.description || (d.kind === "percent" ? `${d.value}% off your order` : `$${d.value} off your order`),
      percentOff: d.kind === "percent" ? Math.round(d.value) : null,
      amountOffCents: d.kind === "amount" ? Math.round(d.value * 100) : null,
      minSubtotalCents: Math.round(d.minSubtotal * 100),
      firstOrderOnly: formData.get("firstOrderOnly") === "on",
    },
  });
  revalidatePath("/dashboard/promotions");
  return { error: undefined };
}

export async function togglePromo(formData: FormData) {
  const seller = await storeFor("/dashboard/promotions");
  const id = String(formData.get("id"));
  const promo = await db.promo.findFirst({ where: { id, sellerId: seller.id } });
  if (promo) await db.promo.update({ where: { id }, data: { active: !promo.active } });
  revalidatePath("/dashboard/promotions");
}
