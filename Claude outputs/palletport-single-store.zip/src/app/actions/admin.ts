"use server";

import { revalidatePath } from "next/cache";
import { forbidden, redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session) redirect("/login?next=/admin");
  const user = await db.user.findUnique({ where: { id: session.userId } });
  if (user?.role !== "ADMIN") forbidden();
}

export async function setCertStatus(formData: FormData) {
  await requireAdmin();
  const status = String(formData.get("status"));
  if (!["APPROVED", "REJECTED"].includes(status)) return;
  await db.user.update({ where: { id: String(formData.get("userId")) }, data: { certStatus: status } });
  revalidatePath("/admin");
}

export async function toggleFeatured(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("lotId"));
  const lot = await db.lot.findUnique({ where: { id } });
  if (lot) await db.lot.update({ where: { id }, data: { featured: !lot.featured } });
  revalidatePath("/admin");
}

export async function markInquiryHandled(formData: FormData) {
  await requireAdmin();
  await db.inquiry.update({ where: { id: String(formData.get("id")) }, data: { handled: true } });
  revalidatePath("/admin");
}
