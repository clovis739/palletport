import Link from "next/link";
import { db } from "@/lib/db";
import { getStore } from "@/lib/store";
import { settleAuctions } from "@/lib/auctions";
import { LotCard } from "@/components/LotCard";
import { PalletArt } from "@/components/PalletArt";
import { CONDITIONS, LOT_SIZES, money } from "@/lib/format";
import { COLLECTIONS } from "@/lib/collections";
import { GUIDES } from "@/content/guides";
import { POSTS } from "@/content/blog";
import { NextIcon } from "@/components/Icons";
import { MapPin } from "lucide-react";

export const dynamic = "force-dynamic";

const lotInclude = { category: true, seller: true } as const;

export default async function Home() {
  await settleAuctions();
  const now = new Date();
  const [endingSoon, buyNow, categories, store, liveAuctions, endingHour, retail, sizeCounts, recentlySold] = await Promise.all([
    db.lot.findMany({ where: { saleType: "AUCTION", status: "ACTIVE", endsAt: { gt: now } }, include: lotInclude, orderBy: { endsAt: "asc" }, take: 8 }),
    db.lot.findMany({ where: { saleType: "BUY_NOW", status: "ACTIVE" }, include: lotInclude }),
    db.category.findMany({ include: { _count: { select: { lots: { where: { status: "ACTIVE" } } } } }, orderBy: { name: "asc" } }),
    getStore(),
    db.lot.count({ where: { saleType: "AUCTION", status: "ACTIVE", endsAt: { gt: now } } }),
    db.lot.count({ where: { saleType: "AUCTION", status: "ACTIVE", endsAt: { gt: now, lte: new Date(now.getTime() + 3600000) } } }),
    db.lot.aggregate({ where: { status: "ACTIVE" }, _sum: { msrpCents: true } }),
    db.lot.groupBy({ by: ["lotSize"], where: { status: "ACTIVE" }, _count: true }),
    db.lot.findMany({ where: { status: "SOLD_OUT", saleType: "AUCTION" }, include: lotInclude, orderBy: { endsAt: "desc" }, take: 4 }),
  ]);
  const bestBuyNow = buyNow.sort((a, b) => a.priceCents / a.msrpCents - b.priceCents / b.msrpCents).slice(0, 8);
  const sizeCount = (k: string) => sizeCounts.find((s) => s.lotSize === k)?._count ?? 0;

  return (
    <>
      {/* Hero: search-first */}
      <section className="relative overflow-hidden bg-ink text-white">
        <div className="absolute inset-0 opacity-[0.07]" style={{ backgroundImage: "repeating-linear-gradient(90deg,#fff 0 1px,transparent 1px 64px),repeating-linear-gradient(0deg,#fff 0 1px,transparent 1px 64px)" }} />
        <div className="container-pp relative py-14 md:py-20">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-signal">Liquidation pallets, direct from our warehouse</p>
          <h1 className="mt-3 max-w-3xl font-display text-4xl font-bold leading-[1.05] sm:text-5xl lg:text-6xl">
            Bid on returns & overstock by the case, pallet or truckload.
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-white/70">Manifested lots from retailers and distributors. Bid in live auctions or buy now, then ship dock to door.</p>
          <form action="/search" className="mt-8 flex max-w-2xl gap-2 rounded-full bg-white p-1.5">
            <input name="q" placeholder="Search auctions — try “air fryer”, “power tools”, “truckload”" className="min-w-0 flex-1 rounded-full px-4 text-ink outline-none" />
            <button className="btn-primary px-6">Search</button>
          </form>
          <div className="mt-5 flex flex-wrap gap-2 text-sm">
            {[["/auctions", "Live auctions"], ["/buy-now", "Buy Now"], ["/truckloads", "Truckloads"], ["/pallets", "Pallets"], ["/case-packs", "Case packs"]].map(([h, l]) => (
              <Link key={h} href={h} className="rounded-full border border-white/20 px-4 py-1.5 font-semibold hover:bg-white/10">{l}</Link>
            ))}
          </div>
        </div>
        <div className="stripe h-2" />
      </section>

      {/* Live stats strip */}
      <section className="border-b border-line bg-white">
        <div className="container-pp grid grid-cols-2 divide-x divide-line py-4 text-center md:grid-cols-4">
          {[
            [liveAuctions.toLocaleString(), "live auctions"],
            [endingHour.toLocaleString(), "ending in the next hour"],
            [money(retail._sum.msrpCents ?? 0), "retail value listed"],
            ["10–35%", "typical price vs. retail"],
          ].map(([n, l]) => (
            <div key={l} className="px-2">
              <p className="font-display text-2xl font-bold">{n}</p>
              <p className="text-xs text-muted">{l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Ending soon */}
      <section className="container-pp py-12">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="font-display text-2xl font-bold sm:text-3xl">Closing soon</h2>
            <p className="text-sm text-muted">Last chance to bid on these auctions.</p>
          </div>
          <Link href="/auctions" className="text-sm font-semibold text-signal-dark hover:underline">All auctions<NextIcon /></Link>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{endingSoon.map((l) => <LotCard key={l.id} lot={l} />)}</div>
      </section>

      {/* Lot sizes */}
      <section className="container-pp pb-12">
        <h2 className="mb-6 font-display text-2xl font-bold sm:text-3xl">Shop by lot size</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {([["CASE", "/case-packs", 150], ["PALLET", "/pallets", 24], ["TRUCKLOAD", "/truckloads", 215]] as const).map(([k, href, hue]) => (
            <Link key={k} href={href} className="group card flex items-center gap-4 overflow-hidden p-4 transition hover:border-ink">
              <div className="h-24 w-32 shrink-0 overflow-hidden rounded-xl"><PalletArt seed={`size-${k}`} hue={hue} className="h-full w-full" /></div>
              <div>
                <p className="font-display text-xl font-bold group-hover:text-signal-dark">{LOT_SIZES[k].plural}</p>
                <p className="text-sm text-muted">{LOT_SIZES[k].note}</p>
                <p className="mt-1 text-xs font-semibold">{sizeCount(k)} live lots<NextIcon /></p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="border-y border-line bg-sand/40">
        <div className="container-pp py-12">
          <div className="mb-6 flex items-end justify-between">
            <h2 className="font-display text-2xl font-bold sm:text-3xl">Shop by category</h2>
            <Link href="/categories" className="text-sm font-semibold text-signal-dark hover:underline">All categories<NextIcon /></Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {categories.map((c) => (
              <Link key={c.id} href={`/c/${c.slug}`} className="group card flex items-center gap-3 p-3 transition hover:border-ink">
                <div className="h-14 w-14 shrink-0 overflow-hidden rounded-xl"><PalletArt seed={c.slug} hue={c.hue} className="h-full w-full scale-150" /></div>
                <div className="min-w-0">
                  <p className="truncate font-display font-semibold">{c.name}</p>
                  <p className="text-xs text-muted">{c._count.lots} lots</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Buy now */}
      <section className="container-pp py-12">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="font-display text-2xl font-bold sm:text-3xl">Buy Now — no bidding</h2>
            <p className="text-sm text-muted">Fixed-price lots with the lowest percent of retail.</p>
          </div>
          <Link href="/buy-now?sort=value" className="text-sm font-semibold text-signal-dark hover:underline">All Buy Now lots<NextIcon /></Link>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{bestBuyNow.map((l) => <LotCard key={l.id} lot={l} />)}</div>
      </section>

      {/* How it works */}
      <section className="bg-ink text-white">
        <div className="container-pp grid gap-10 py-16 md:grid-cols-[1fr_2fr]">
          <div>
            <h2 className="font-display text-3xl font-bold">How buying works</h2>
            <p className="mt-3 text-white/70">For bin stores, discount shops, online resellers, flea-market vendors and exporters.</p>
            <Link href="/how-to-buy" className="btn-primary mt-6">Bidding guide</Link>
          </div>
          <ol className="grid gap-6 sm:grid-cols-3">
            {[
              ["01", "Register your business", "Free account. Add a resale certificate to unlock Net 30 and tax-exempt buying."],
              ["02", "Bid or buy now", "Read the manifest, set a maximum bid and we'll bid for you — or skip the auction with Buy Now."],
              ["03", "Pay & receive", "Pay within 3 days of winning. Lots ship LTL freight or parcel, or collect from our warehouse."],
            ].map(([n, t, d]) => (
              <li key={n} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                <span className="font-display text-sm font-bold text-signal">{n}</span>
                <h3 className="mt-2 font-display text-lg font-semibold">{t}</h3>
                <p className="mt-1 text-sm text-white/65">{d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Conditions */}
      <section id="conditions" className="container-pp py-12">
        <h2 className="mb-6 font-display text-2xl font-bold sm:text-3xl">Shop by condition</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {Object.entries(CONDITIONS).map(([key, c]) => (
            <Link key={key} href={`/lots?condition=${key}`} className="card p-4 transition hover:border-ink">
              <span className={`inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${c.tone}`}>{c.label}</span>
              <p className="mt-3 text-sm text-ink/75">{c.note}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Collections + guides */}
      <section className="container-pp pb-12">
        <div className="mb-6 flex items-end justify-between">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">Collections</h2>
          <Link href="/collections" className="text-sm font-semibold text-signal-dark hover:underline">All collections<NextIcon /></Link>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {COLLECTIONS.slice(0, 4).map((c) => (
            <Link key={c.slug} href={`/collections/${c.slug}`} className="rounded-2xl p-5 transition hover:-translate-y-0.5" style={{ background: `hsl(${c.hue} 45% 92%)` }}>
              <p className="font-display text-lg font-bold">{c.title}</p>
              <p className="text-sm text-ink/70">{c.tagline}</p>
            </Link>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap items-center gap-2">
          <span className="text-sm font-semibold">Buying guides:</span>
          {GUIDES.map((g) => (
            <Link key={g.slug} href={`/guides/${g.slug}`} className="rounded-full border border-line bg-white px-3 py-1.5 text-sm hover:border-ink">{g.title}</Link>
          ))}
        </div>
      </section>

      {/* Recently sold + about us */}
      <section className="container-pp grid gap-10 pb-6 lg:grid-cols-[2fr_1fr]">
        <div>
          <h2 className="mb-2 font-display text-2xl font-bold">Recently sold</h2>
          <p className="mb-6 text-sm text-muted">What lots like these actually closed for.</p>
          {recentlySold.length ? (
            <div className="grid gap-5 sm:grid-cols-2">{recentlySold.map((l) => <LotCard key={l.id} lot={l} />)}</div>
          ) : (
            <p className="card p-6 text-sm text-muted">Closed auctions will appear here.</p>
          )}
        </div>
        <aside className="space-y-6">
          <Link href="/about" className="group card block p-6 transition hover:border-ink">
            <p className="label">Sold direct by us</p>
            <p className="font-display text-xl font-bold">{store.name}</p>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-muted"><MapPin aria-hidden className="h-4 w-4" /> Warehouse in {store.location}</p>
            <p className="mt-3 text-sm text-ink/75">{store.bio}</p>
            <span className="mt-4 inline-flex items-center font-semibold text-signal-dark">About us<NextIcon /></span>
          </Link>
          <Link href="/contact" className="group card block bg-sand p-6 transition hover:border-ink">
            <p className="font-display text-lg font-bold">Looking for something specific?</p>
            <p className="mt-1 text-sm text-ink/70">Tell us the categories and volume you need — we source new loads every week.</p>
            <span className="mt-4 inline-flex items-center font-semibold text-signal-dark">Contact our team<NextIcon /></span>
          </Link>
        </aside>
      </section>

      {/* Blog */}
      <section className="container-pp pt-14">
        <div className="mb-6 flex items-end justify-between">
          <h2 className="font-display text-2xl font-bold">From The Loading Dock</h2>
          <Link href="/blog" className="text-sm font-semibold text-signal-dark hover:underline">Read the blog<NextIcon /></Link>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          {[...POSTS].sort((a, b) => (b.date ?? "").localeCompare(a.date ?? "")).slice(0, 3).map((p) => (
            <Link key={p.slug} href={`/blog/${p.slug}`} className="card p-5 hover:border-ink">
              <p className="label">{p.category}</p>
              <p className="font-display text-lg font-bold leading-snug">{p.title}</p>
              <p className="mt-1 line-clamp-2 text-sm text-muted">{p.excerpt}</p>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
