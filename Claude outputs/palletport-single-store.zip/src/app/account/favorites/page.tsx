import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { LotCard } from "@/components/LotCard";
import { AccountShell } from "../AccountNav";

export const metadata = { title: "Watchlist" };

export default async function FavoritesPage() {
  const u = await requireUser("/account/favorites");
  const favorites = await db.favorite.findMany({ where: { userId: u.id }, include: { lot: { include: { category: true, seller: true } } }, orderBy: { createdAt: "desc" } });
  return (
    <AccountShell active="/account/favorites" title="Watchlist">
      <p className="mb-4 text-sm text-muted">Lots you&apos;re watching. Auctions show their live countdown.</p>
      {favorites.length === 0 ? (
        <p className="text-sm text-muted">Tap "Watch" on any lot to track it here. <Link href="/lots" className="font-semibold text-signal-dark">Browse lots</Link></p>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{favorites.map((f) => <LotCard key={f.id} lot={f.lot} />)}</div>
      )}
    </AccountShell>
  );
}
