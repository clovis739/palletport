import Link from "next/link";
import { BadgeCheck, Gavel, Heart, KeyRound, Package, UserRound, UsersRound, type LucideIcon } from "lucide-react";

const LINKS: [string, string, LucideIcon][] = [
  ["/account", "Profile & address", UserRound],
  ["/account/verification", "Business verification", BadgeCheck],
  ["/bids", "My bids", Gavel],
  ["/account/favorites", "Watchlist", Heart],
  ["/orders", "Orders", Package],
  ["/account/referrals", "Refer a business", UsersRound],
  ["/account/security", "Password & security", KeyRound],
];

export function AccountNav({ active }: { active: string }) {
  return (
    <nav className="flex gap-1 overflow-x-auto lg:flex-col">
      {LINKS.map(([href, label, Icon]) => (
        <Link key={href} href={href} className={`flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2 text-sm ${active === href ? "bg-ink font-semibold text-white" : "hover:bg-sand"}`}>
          {label}
        </Link>
      ))}
    </nav>
  );
}

export function AccountShell({ active, title, children }: { active: string; title: string; children: React.ReactNode }) {
  return (
    <div className="container-pp grid gap-8 py-10 lg:grid-cols-[220px_1fr]">
      <aside><AccountNav active={active} /></aside>
      <div>
        <h1 className="mb-6 font-display text-3xl font-bold">{title}</h1>
        {children}
      </div>
    </div>
  );
}
