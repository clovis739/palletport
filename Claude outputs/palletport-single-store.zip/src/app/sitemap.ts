import type { MetadataRoute } from "next";
import { db } from "@/lib/db";
import { POSTS } from "@/content/blog";
import { HELP } from "@/content/help";
import { GUIDES } from "@/content/guides";
import { LEGAL } from "@/content/legal";
import { COLLECTIONS } from "@/lib/collections";
import { BLOG_CATEGORIES } from "@/content/blog";
import { categorySlug } from "@/lib/blog";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.APP_URL ?? "http://localhost:3000";
  const [lots, categories] = await Promise.all([
    db.lot.findMany({ where: { status: "ACTIVE" }, select: { slug: true, createdAt: true } }),
    db.category.findMany({ select: { slug: true } }),
  ]);
  const staticPaths = ["", "/auctions", "/buy-now", "/truckloads", "/pallets", "/case-packs", "/how-to-buy", "/lots", "/categories", "/new", "/trending", "/collections", "/how-it-works", "/help", "/blog", "/guides", "/pro", "/volume-buyers", "/affiliates", "/events", "/integrations", "/about", "/contact", "/site-map"];
  return [
    ...staticPaths.map((p) => ({ url: `${base}${p}` })),
    ...categories.map((c) => ({ url: `${base}/c/${c.slug}` })),
    ...COLLECTIONS.map((c) => ({ url: `${base}/collections/${c.slug}` })),
    ...lots.map((l) => ({ url: `${base}/lots/${l.slug}`, lastModified: l.createdAt })),
    ...POSTS.map((p) => ({ url: `${base}/blog/${p.slug}`, lastModified: p.date ? new Date(p.date) : undefined })),
    ...BLOG_CATEGORIES.map((c) => ({ url: `${base}/blog/category/${categorySlug(c)}` })),
    ...HELP.map((h) => ({ url: `${base}/help/${h.slug}` })),
    ...GUIDES.map((g) => ({ url: `${base}/guides/${g.slug}` })),
    ...LEGAL.map((l) => ({ url: `${base}/legal/${l.slug}` })),
  ];
}
