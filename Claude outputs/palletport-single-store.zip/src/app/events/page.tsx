import { ProgramPage } from "@/components/ProgramPage";

export const metadata = { title: "Warehouse Days" };

const EVENTS = [
  ["Oct 17", "Columbus, OH", "Riverside Returns open dock — walk the floor, buy on the spot, same-day pickup."],
  ["Nov 7", "Houston, TX", "Gulf Coast Surplus pre-holiday toy and home day."],
  ["Jan 23", "Online", "New-year overstock drop: 48 hours of exclusive truckload lots."],
];

export default function Events() {
  return (
    <ProgramPage
      eyebrow="Events" title="Warehouse Days" hue={330} topic="EVENTS"
      lead="In-person open docks and online buying events where we release exclusive lots. See the pallets, meet our team, and skip the freight with same-day pickup."
      formTitle="Get event invites" formCta="Notify me" bodyLabel="Which cities are you near?"
      benefits={[
        ["Inspect before you buy", "Walk the dock and open the boxes."],
        ["Event-only lots", "We hold back pallets for attendees."],
        ["No freight", "Load up your truck or trailer on the day."],
        ["Meet our team", "Talk to the people who sort and grade every pallet."],
      ]}
      extra={
        <div className="mt-14">
          <h2 className="mb-5 font-display text-2xl font-bold">Upcoming</h2>
          <ul className="grid gap-4 md:grid-cols-3">
            {EVENTS.map(([date, city, d]) => (
              <li key={date} className="card p-5">
                <p className="font-display text-2xl font-bold text-signal">{date}</p>
                <p className="font-semibold">{city}</p>
                <p className="mt-1 text-sm text-muted">{d}</p>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-muted">Sample schedule — replace with your real events.</p>
        </div>
      }
    />
  );
}
