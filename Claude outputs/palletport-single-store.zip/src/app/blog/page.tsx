import { BlogIndex } from "@/components/blog/BlogIndex";

export const metadata = { title: "Blog — The Loading Dock", description: "Guides, market insights and market insights for liquidation buyers." };

export default async function BlogPage({ searchParams }: { searchParams: Promise<{ tag?: string; q?: string; page?: string; category?: string }> }) {
  const { tag, q, page } = await searchParams;
  return <BlogIndex tag={tag} q={q?.trim() || undefined} page={Math.max(1, Number(page) || 1)} basePath="/blog" />;
}
