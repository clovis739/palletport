import Link from "next/link";
import { InquiryForm } from "@/components/InquiryForm";

export const metadata = { title: "Contact us" };

export default async function Contact({ searchParams }: { searchParams: Promise<{ lot?: string }> }) {
  const { lot } = await searchParams;
  const lotNo = lot?.replace(/[^A-Za-z0-9]/g, "").slice(0, 12).toUpperCase();
  return (
    <div className="container-pp grid gap-10 py-14 md:grid-cols-2">
      <div className="space-y-5">
        <h1 className="font-display text-4xl font-bold">Contact us</h1>
        <p className="text-ink/75">Questions about a lot, an order, pickup or bulk buying? Our warehouse team replies within one business day.</p>
        <div className="card space-y-3 p-5 text-sm">
          <p><span className="font-semibold">Order issue?</span> Include your order number (for example PP-XXXX) so we can find it quickly.</p>
          <p><span className="font-semibold">Quick answers:</span> <Link href="/help" className="font-semibold text-signal-dark hover:underline">Help center</Link></p>
          <p><span className="font-semibold">Hours:</span> Monday–Friday, 8am–6pm ET</p>
        </div>
      </div>
      <div className="card p-6">
        {lotNo && <p className="mb-4 rounded-lg bg-sand p-3 text-sm">Your question is about <strong>lot #{lotNo}</strong>.</p>}
        <InquiryForm topic="CONTACT" submitLabel="Send message" bodyLabel="How can we help?" defaultBody={lotNo ? `Question about lot #${lotNo}: ` : ""} />
      </div>
    </div>
  );
}
