import Link from "next/link";
import { db } from "@/lib/db";
import { LotCard } from "@/components/LotCard";

export const metadata = { title: "New arrivals" };
export const dynamic = "force-dynamic";

export default async function NewArrivals() {
  const since = new Date(Date.now() - 14 * 86400000);
  const [lots] = await Promise.all([
    db.lot.findMany({ where: { status: "ACTIVE", createdAt: { gte: since } }, include: { category: true, seller: true }, orderBy: { createdAt: "desc" } }),
  ]);

  const groups = new Map<string, typeof lots>();
  for (const l of lots) {
    const days = Math.floor((Date.now() - l.createdAt.getTime()) / 86400000);
    const key = days === 0 ? "Today" : days === 1 ? "Yesterday" : days < 7 ? "This week" : "Last week";
    groups.set(key, [...(groups.get(key) ?? []), l]);
  }

  return (
    <div className="container-pp py-10">
      <h1 className="font-display text-3xl font-bold">New arrivals</h1>
      <p className="mb-8 text-muted">{lots.length} pallets listed in the last 14 days. Fresh lots sell fastest — check back daily.</p>

      {[...groups.entries()].map(([label, items]) => (
        <section key={label} className="mb-12">
          <h2 className="mb-4 font-display text-xl font-bold">{label} <span className="text-sm font-normal text-muted">· {items.length} lots</span></h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{items.map((l) => <LotCard key={l.id} lot={l} />)}</div>
        </section>
      ))}
      {lots.length === 0 && <p className="card p-10 text-center text-muted">Nothing new in the last two weeks. <Link href="/lots" className="font-semibold text-signal-dark">Browse all lots</Link></p>}
    </div>
  );
}
