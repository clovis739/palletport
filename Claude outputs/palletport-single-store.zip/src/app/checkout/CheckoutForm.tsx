"use client";

import { useActionState, useMemo, useState } from "react";
import { placeOrder } from "@/app/actions/orders";
import { SubmitButton } from "@/components/SubmitButton";
import { PalletArt } from "@/components/PalletArt";
import { estimateShipments, freightTotal, MODE_LABEL, validZip, type ShipLine } from "@/lib/shipping";
import { NextIcon, PathSep } from "@/components/Icons";

type Item = {
  id: string; slug: string; title: string; hue: number; sellerId: string; sellerName: string;
  saleType: string; lotSize: string; condition: string; units: number; quantity: number; unitCents: number;
};
type Defaults = { shipName: string; shipAddress: string; shipCity: string; shipRegion: string; shipPostal: string; shipCountry: string; phone: string };

function usd(c: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(c / 100);
}

const PAYMENT = [
  { value: "CARD", title: "Credit or debit card", note: "Charged when we confirm your order. (Connect Stripe to take live payments.)" },
  { value: "WIRE", title: "Wire / ACH transfer", note: "We email bank details and an invoice. Ships once funds clear (1–2 business days)." },
  { value: "NET30", title: "Net 30 terms", note: "Invoice due 30 days after delivery. For verified resellers." },
];

function Step({ n, title, children, aside }: { n: number; title: string; children: React.ReactNode; aside?: React.ReactNode }) {
  return (
    <section className="card p-6">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="flex items-center gap-3 font-display text-lg font-bold">
          <span className="grid h-7 w-7 place-items-center rounded-full bg-ink text-sm text-white">{n}</span>
          {title}
        </h2>
        {aside}
      </div>
      {children}
    </section>
  );
}

export function CheckoutForm(props: {
  items: Item[];
  shipLines: ShipLine[];
  subtotalCents: number;
  discountCents: number;
  promoCode: string;
  pickupAvailable: boolean;
  net30Approved: boolean;
  taxExempt: boolean;
  email: string;
  defaults: Defaults;
}) {
  const { items, shipLines, subtotalCents, discountCents, promoCode, pickupAvailable, net30Approved, taxExempt, email, defaults } = props;
  const [state, action] = useActionState(placeOrder, undefined);
  const [zip, setZip] = useState(defaults.shipPostal);
  const [method, setMethod] = useState<"FREIGHT" | "PICKUP">("FREIGHT");
  const [dock, setDock] = useState(false);
  const [residential, setResidential] = useState(false);
  const [payment, setPayment] = useState("CARD");

  const hasFreight = items.some((i) => i.lotSize !== "CASE");
  const shipments = useMemo(
    () => estimateShipments(shipLines, { toZip: zip, method, liftgate: !dock, residential }, subtotalCents),
    [shipLines, zip, method, dock, residential, subtotalCents],
  );
  const freight = freightTotal(shipments);
  const zipOk = validZip(zip) || method === "PICKUP";
  const total = subtotalCents - discountCents + freight;
  const bySeller = useMemo(() => {
    const m = new Map<string, Item[]>();
    for (const i of items) m.set(i.sellerId, [...(m.get(i.sellerId) ?? []), i]);
    return [...m.entries()];
  }, [items]);

  return (
    <form action={action} className="grid gap-8 lg:grid-cols-[1fr_400px]">
      <div className="space-y-5">
        <Step n={1} title="Delivery address" aside={<span className="text-xs text-muted">{email}</span>}>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2"><label className="label" htmlFor="shipName">Business / receiving name</label><input id="shipName" name="shipName" defaultValue={defaults.shipName} className="input" required autoComplete="organization" /></div>
            <div className="sm:col-span-2"><label className="label" htmlFor="shipAddress">Street address</label><input id="shipAddress" name="shipAddress" defaultValue={defaults.shipAddress} className="input" required autoComplete="street-address" /></div>
            <div><label className="label" htmlFor="shipCity">City</label><input id="shipCity" name="shipCity" defaultValue={defaults.shipCity} className="input" required autoComplete="address-level2" /></div>
            <div><label className="label" htmlFor="shipRegion">State</label><input id="shipRegion" name="shipRegion" defaultValue={defaults.shipRegion} className="input" required autoComplete="address-level1" /></div>
            <div>
              <label className="label" htmlFor="shipPostal">ZIP code</label>
              <input id="shipPostal" name="shipPostal" value={zip} onChange={(e) => setZip(e.target.value)} className="input" required inputMode="numeric" autoComplete="postal-code" />
              {!validZip(zip) && zip.length > 0 && <p className="mt-1 text-xs text-rust">Enter a 5-digit ZIP to price freight.</p>}
            </div>
            <div><label className="label" htmlFor="shipCountry">Country</label><input id="shipCountry" name="shipCountry" defaultValue={defaults.shipCountry} className="input" required autoComplete="country-name" /></div>
          </div>
        </Step>

        <Step n={2} title="Delivery method">
          <div className="grid gap-3 sm:grid-cols-2">
            <label className={`cursor-pointer rounded-xl border p-4 ${method === "FREIGHT" ? "border-ink bg-sand/50" : "border-line"}`}>
              <input type="radio" name="deliveryMethod" value="FREIGHT" checked={method === "FREIGHT"} onChange={() => setMethod("FREIGHT")} className="sr-only" />
              <span className="block font-semibold">Ship to me</span>
              <span className="text-sm text-muted">{hasFreight ? "LTL freight or truckload to your address" : "Parcel delivery"}</span>
            </label>
            <label className={`rounded-xl border p-4 ${!pickupAvailable ? "cursor-not-allowed opacity-50" : "cursor-pointer"} ${method === "PICKUP" ? "border-ink bg-sand/50" : "border-line"}`}>
              <input type="radio" name="deliveryMethod" value="PICKUP" disabled={!pickupAvailable} checked={method === "PICKUP"} onChange={() => setMethod("PICKUP")} className="sr-only" />
              <span className="block font-semibold">Pick up at our warehouse</span>
              <span className="text-sm text-muted">{pickupAvailable ? "Free — bring your own truck or trailer" : "Pickup isn't available right now"}</span>
            </label>
          </div>
          {method === "FREIGHT" && hasFreight && (
            <div className="mt-4 grid gap-2 sm:grid-cols-2">
              <label className="flex items-start gap-2 rounded-lg border border-line p-3 text-sm">
                <input type="checkbox" name="dockAccess" checked={dock} onChange={(e) => setDock(e.target.checked)} className="mt-0.5 accent-signal" />
                <span><span className="font-semibold">I have a loading dock</span><span className="block text-xs text-muted">Otherwise a liftgate truck is booked (+$75 per shipment)</span></span>
              </label>
              <label className="flex items-start gap-2 rounded-lg border border-line p-3 text-sm">
                <input type="checkbox" name="residential" checked={residential} onChange={(e) => setResidential(e.target.checked)} className="mt-0.5 accent-signal" />
                <span><span className="font-semibold">Residential address</span><span className="block text-xs text-muted">Home or farm delivery (+$95 per shipment)</span></span>
              </label>
            </div>
          )}
          <div className="mt-4 space-y-2">
            {shipments.map((s) => (
              <div key={s.sellerId} className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-sand/50 px-4 py-3 text-sm">
                <div>
                  <p className="font-semibold">From our warehouse <span className="font-normal text-muted">· {s.shipsFrom}</span></p>
                  <p className="text-xs text-muted">{MODE_LABEL[s.mode]}{s.pallets ? ` · ${s.pallets} pallet${s.pallets > 1 ? "s" : ""}` : ""} · {s.weightLbs.toLocaleString()} lbs · {s.transitDays}</p>
                  {s.notes.map((n) => <p key={n} className="text-xs text-ink/70">{n}</p>)}
                </div>
                <p className="font-display font-bold">{!zipOk ? "—" : s.totalCents ? usd(s.totalCents) : "Free"}</p>
              </div>
            ))}
          </div>
        </Step>

        <Step n={3} title="Payment">
          <div className="space-y-2">
            {PAYMENT.map((p) => {
              const locked = p.value === "NET30" && !net30Approved;
              return (
                <label key={p.value} className={`flex gap-3 rounded-xl border p-4 ${payment === p.value ? "border-ink bg-sand/50" : "border-line"} ${locked ? "opacity-60" : "cursor-pointer"}`}>
                  <input type="radio" name="paymentMethod" value={p.value} checked={payment === p.value} onChange={() => setPayment(p.value)} disabled={locked} className="mt-1 accent-signal" />
                  <span>
                    <span className="block font-semibold">{p.title}</span>
                    <span className="text-sm text-muted">{p.note}</span>
                    {locked && <a href="/account/verification" className="mt-1 block text-xs font-semibold text-signal-dark hover:underline">Verify your business to unlock<NextIcon /></a>}
                  </span>
                </label>
              );
            })}
          </div>
          {payment === "CARD" && (
            <div className="mt-4 rounded-xl border border-dashed border-line p-4 text-sm text-muted">
              Card entry appears here once Stripe is connected (see README<PathSep />Payments). For now, orders are recorded and marked confirmed.
            </div>
          )}
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="poNumber">PO number (optional)</label><input id="poNumber" name="poNumber" maxLength={40} className="input" /></div>
            <div><label className="label" htmlFor="phone">Delivery contact phone</label><input id="phone" defaultValue={defaults.phone} className="input" inputMode="tel" autoComplete="tel" /></div>
          </div>
          <div className="mt-4"><label className="label" htmlFor="notes">Notes for our team / carrier (optional)</label><textarea id="notes" name="notes" rows={2} maxLength={500} className="input" placeholder="Dock hours, gate code, appointment needed…" /></div>
        </Step>

        <Step n={4} title="Review & place order">
          <label className="flex items-start gap-3 text-sm">
            <input type="checkbox" name="terms" required className="mt-1 accent-signal" />
            <span>
              I understand liquidation lots are sold <strong>as-is</strong> according to their condition grade, manifests may vary slightly, and I agree to the{" "}
              <a href="/legal/terms" target="_blank" className="font-semibold text-signal-dark underline">Terms</a> and{" "}
              <a href="/legal/returns-and-disputes" target="_blank" className="font-semibold text-signal-dark underline">Returns & Disputes policy</a>.
            </span>
          </label>
          {state?.error && <p className="mt-4 rounded-lg bg-rust/10 p-3 text-sm font-medium text-rust">{state.error}</p>}
          <div className="mt-5 lg:hidden">
            <SubmitButton className="btn-primary w-full py-3 text-base" pendingText="Placing order…">Place order · {usd(total)}</SubmitButton>
          </div>
        </Step>
      </div>

      {/* Summary */}
      <aside className="h-fit space-y-4 lg:sticky lg:top-[130px]">
        <div className="card overflow-hidden">
          <div className="border-b border-line bg-sand/50 px-5 py-3">
            <h2 className="font-display font-bold">Order summary</h2>
            <p className="text-xs text-muted">{items.reduce((a, i) => a + i.quantity, 0)} lot{items.length === 1 && items[0].quantity === 1 ? "" : "s"}</p>
          </div>
          <div className="max-h-80 divide-y divide-line overflow-y-auto">
            {bySeller.map(([sid, list]) => (
              <div key={sid} className="px-5 py-3">
                
                {list.map((i) => (
                  <div key={i.id} className="flex gap-3 py-1.5">
                    <div className="h-12 w-16 shrink-0 overflow-hidden rounded-md border border-line"><PalletArt seed={i.slug} hue={i.hue} className="h-full w-full" /></div>
                    <div className="min-w-0 flex-1 text-sm">
                      <p className="line-clamp-2 font-medium leading-snug">{i.title}</p>
                      <p className="text-xs text-muted">{i.quantity > 1 ? `${i.quantity} × ` : ""}{i.saleType === "AUCTION" ? "Buy Now price" : `${i.units.toLocaleString()} units`}</p>
                    </div>
                    <p className="text-sm font-semibold">{usd(i.unitCents * i.quantity)}</p>
                  </div>
                ))}
              </div>
            ))}
          </div>
          <dl className="space-y-2 border-t border-line px-5 py-4 text-sm">
            <div className="flex justify-between"><dt>Subtotal</dt><dd>{usd(subtotalCents)}</dd></div>
            {discountCents > 0 && <div className="flex justify-between text-moss"><dt>Promo {promoCode}</dt><dd>−{usd(discountCents)}</dd></div>}
            <div className="flex justify-between"><dt>{method === "PICKUP" ? "Pickup" : "Freight"}</dt><dd>{!zipOk ? "Enter ZIP" : freight ? usd(freight) : "Free"}</dd></div>
            <div className="flex justify-between"><dt>Sales tax</dt><dd>{taxExempt ? "Exempt (certificate on file)" : "Calculated on invoice"}</dd></div>
            <div className="flex justify-between border-t border-line pt-3 text-base font-bold"><dt>Total</dt><dd className="font-display text-xl">{usd(total)}</dd></div>
          </dl>
          <div className="hidden border-t border-line p-5 lg:block">
            <SubmitButton className="btn-primary w-full py-3 text-base" pendingText="Placing order…">Place order</SubmitButton>
            <p className="mt-2 text-center text-[11px] text-muted">You'll be able to track your shipment from your orders page.</p>
          </div>
        </div>
        <div className="rounded-2xl bg-sand/60 p-4 text-xs text-ink/75">
          <p className="font-semibold text-ink">Buyer protection</p>
          <p className="mt-1">If the retail value you receive is more than 10% below the manifest, or the lot isn't the listed category or grade, you're covered under our Returns & Disputes policy.</p>
        </div>
      </aside>
    </form>
  );
}
