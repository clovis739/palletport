import Link from "next/link";
import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { money } from "@/lib/format";
import { StatusPill } from "../StatusPill";
import { cancelOrder, reorder, submitReview } from "@/app/actions/orders";
import { ActionForm } from "@/components/forms/ActionForm";
import { Stars } from "@/components/Stars";
import { PayWonForm } from "../PayWonForm";
import { PrevIcon } from "@/components/Icons";

const STEPS = ["PENDING", "CONFIRMED", "SHIPPED", "DELIVERED"];
const PAY: Record<string, string> = { CARD: "Card", NET30: "Net 30 terms", WIRE: "Wire / ACH", UNPAID: "Awaiting payment" };

export default async function OrderPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ placed?: string }> }) {
  const { id } = await params;
  const { placed } = await searchParams;
  const user = await requireUser(`/orders/${id}`);
  const order = await db.order.findFirst({
    where: { id, userId: user.id },
    include: { items: { include: { seller: true, lot: { select: { slug: true } } } }, reviews: true },
  });
  if (!order) notFound();
  const step = STEPS.indexOf(order.status);

  return (
    <div className="container-pp max-w-4xl py-10">
      {placed && (
        <div className="mb-6 rounded-2xl bg-moss p-5 text-white">
          <p className="font-display text-lg font-bold">Order placed — thank you!</p>
          <p className="text-sm text-white/80">Our warehouse team will confirm your order and freight within one business day.</p>
        </div>
      )}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <Link href="/orders" className="text-xs text-muted hover:underline"><PrevIcon />All orders</Link>
          <h1 className="font-display text-3xl font-bold">Order {order.number}</h1>
          <p className="text-sm text-muted">Placed {order.createdAt.toLocaleString()} · {PAY[order.paymentMethod]}</p>
        </div>
        <div className="flex items-center gap-2">
          <StatusPill status={order.status} />
          <form action={reorder}>
            <input type="hidden" name="orderId" value={order.id} />
            <button className="btn-ghost py-2 text-xs">Reorder</button>
          </form>
          {order.status === "PENDING" && (
            <form action={cancelOrder}>
              <input type="hidden" name="orderId" value={order.id} />
              <button className="btn-ghost py-2 text-xs text-rust">Cancel order</button>
            </form>
          )}
        </div>
      </div>
      {order.trackingNo && (
        <p className="mb-6 rounded-xl border border-line bg-white p-4 text-sm">
          Freight PRO / tracking number: <span className="font-mono font-bold">{order.trackingNo}</span>
        </p>
      )}

      {order.status === "AWAITING_PAYMENT" && (
        <div className="mb-8 grid gap-6 rounded-2xl border-2 border-signal bg-white p-6 md:grid-cols-[1fr_1.2fr]">
          <div>
            <p className="font-display text-2xl font-bold">You won this auction</p>
            <p className="mt-1 text-sm text-muted">Confirm delivery details and choose how to pay{order.payBy ? ` by ${order.payBy.toLocaleDateString()}` : ""}. Unpaid lots may be offered to the next bidder.</p>
            <p className="mt-4 font-display text-3xl font-bold">{money(order.totalCents)}</p>
            <p className="text-xs text-muted">Winning bid {money(order.subtotalCents)} + freight {order.shippingCents ? money(order.shippingCents) : "free"}</p>
          </div>
          <PayWonForm
            orderId={order.id}
            net30Approved={user.certStatus === "APPROVED"}
            ship={{ shipName: order.shipName, shipAddress: order.shipAddress, shipCity: order.shipCity, shipRegion: order.shipRegion, shipPostal: order.shipPostal, shipCountry: order.shipCountry }}
          />
        </div>
      )}

      {order.status !== "CANCELLED" && order.status !== "AWAITING_PAYMENT" && (
        <ol className="mb-8 grid grid-cols-4 gap-2">
          {STEPS.map((s, i) => (
            <li key={s} className="space-y-1.5">
              <div className={`h-1.5 rounded-full ${i <= step ? "bg-signal" : "bg-line"}`} />
              <p className={`text-xs font-semibold ${i <= step ? "text-ink" : "text-muted"}`}>{s.charAt(0) + s.slice(1).toLowerCase()}</p>
            </li>
          ))}
        </ol>
      )}

      <div className="grid gap-6 md:grid-cols-[1fr_280px]">
        <div className="card divide-y divide-line">
          {order.items.map((i) => (
            <div key={i.id} className="flex items-center justify-between gap-4 p-5">
              <div>
                <Link href={`/lots/${i.lot.slug}`} className="font-semibold hover:underline">{i.quantity}× {i.title}</Link>
              </div>
              <p className="font-display font-bold">{money(i.priceCents * i.quantity)}</p>
            </div>
          ))}
        </div>
        <div className="space-y-4">
          <div className="card space-y-2 p-5 text-sm">
            <div className="flex justify-between"><span>Subtotal</span><span>{money(order.subtotalCents)}</span></div>
            {order.discountCents > 0 && (
              <div className="flex justify-between text-moss"><span>Promo {order.promoCode}</span><span>−{money(order.discountCents)}</span></div>
            )}
            <div className="flex justify-between"><span>Freight</span><span>{order.shippingCents ? money(order.shippingCents) : "Free"}</span></div>
            <div className="flex justify-between border-t border-line pt-2 font-bold"><span>Total</span><span className="font-display">{money(order.totalCents)}</span></div>
          </div>
          <div className="card p-5 text-sm">
            <p className="label">Deliver to</p>
            <p className="font-semibold">{order.shipName}</p>
            <p>{order.shipAddress}</p>
            <p>{order.shipCity}, {order.shipRegion} {order.shipPostal}</p>
            <p>{order.shipCountry}</p>
            <p className="mt-2 text-xs text-muted">
              {order.deliveryMethod === "PICKUP" ? "Pickup at our warehouse" : order.dockAccess ? "Dock delivery" : "Liftgate delivery"}
              {order.residential ? " · residential" : ""}
            </p>
            {order.poNumber && <p className="mt-1 text-xs">PO: <span className="font-mono">{order.poNumber}</span></p>}
            {order.notes && <p className="mt-1 text-xs text-ink/75">Notes: {order.notes}</p>}
          </div>
        </div>
      </div>

      {order.status === "DELIVERED" && (
        <section className="mt-10">
          <h2 className="mb-4 font-display text-xl font-bold">Review your order</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {order.items.filter((i, idx) => order.items.findIndex((x) => x.sellerId === i.sellerId) === idx).map(({ seller }) => {
              const existing = order.reviews.find((r) => r.sellerId === seller.id);
              return (
                <div key={seller.id} className="card p-5">
                  <p className="font-semibold">How did this order go?</p>
                  {existing ? (
                    <div className="mt-2 text-sm"><Stars value={existing.rating} /><p className="mt-1 text-ink/80">{existing.body}</p></div>
                  ) : (
                    <ActionForm action={submitReview} submitLabel="Post review" successText="Thanks for your review!" className="mt-3 space-y-3">
                      <input type="hidden" name="orderId" value={order.id} />
                      <input type="hidden" name="sellerId" value={seller.id} />
                      <select name="rating" defaultValue="5" className="input" aria-label="Rating">
                        {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} star{n > 1 ? "s" : ""}</option>)}
                      </select>
                      <textarea name="body" rows={3} required placeholder="Did the manifest match? How was packaging and freight?" className="input" />
                    </ActionForm>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
