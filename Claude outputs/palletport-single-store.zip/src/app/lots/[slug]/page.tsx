import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { settleAuctions } from "@/lib/auctions";
import { LotCard } from "@/components/LotCard";
import { SubmitButton } from "@/components/SubmitButton";
import { FavoriteButton } from "@/components/FavoriteButton";
import { Stars } from "@/components/Stars";
import { BidPanel } from "@/components/BidPanel";
import { ConditionBadge } from "@/components/ConditionBadge";
import { LotGallery } from "@/components/lot/LotGallery";
import { ShippingEstimator } from "@/components/lot/ShippingEstimator";
import { ManifestTable } from "@/components/lot/ManifestTable";
import { CopyLink } from "@/components/lot/CopyLink";
import { addToCart } from "@/app/actions/cart";
import { NextIcon } from "@/components/Icons";
import { Check, Star, MessageCircle } from "lucide-react";
import {
  CONDITIONS,
  LOT_SIZES,
  auctionOpen,
  bidIncrement,
  minNextBid,
  money,
  pctOfRetail,
  purchasePrice,
  timeAgo,
} from "@/lib/format";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  const lot = await db.lot.findUnique({ where: { slug }, select: { title: true, description: true } });
  return { title: lot?.title ?? "Lot not found", description: lot?.description };
}

const SECTIONS = [
  ["overview", "Overview"],
  ["manifest", "Manifest"],
  ["shipping", "Shipping & pickup"],
  ["terms", "Payment & terms"],
  ["reviews", "Reviews"],
] as const;

export default async function LotPage({ params }: { params: Params }) {
  const { slug } = await params;
  await settleAuctions();
  const lot = await db.lot.findUnique({
    where: { slug },
    include: {
      category: true,
      subcategory: true,
      seller: { include: { _count: { select: { lots: { where: { status: "ACTIVE" } }, reviews: true } } } },
      manifest: { orderBy: { unitMsrpCents: "desc" } },
      _count: { select: { favorites: true } },
    },
  });
  if (!lot || lot.status === "DRAFT") notFound();

  const session = await getSession();
  const [saved, reviews, bids, me, related] = await Promise.all([
    session ? db.favorite.findUnique({ where: { userId_lotId: { userId: session.userId, lotId: lot.id } } }) : null,
    db.review.findMany({ where: { sellerId: lot.sellerId }, include: { user: { select: { businessName: true, name: true } } }, orderBy: { createdAt: "desc" }, take: 3 }),
    lot.saleType === "AUCTION"
      ? db.bid.findMany({ where: { lotId: lot.id }, orderBy: [{ amountCents: "desc" }, { createdAt: "desc" }], take: 20 })
      : Promise.resolve([] as { id: string; userId: string; amountCents: number; auto: boolean; createdAt: Date }[]),
    session ? db.user.findUnique({ where: { id: session.userId }, select: { shipPostal: true } }) : null,
    db.lot.findMany({
      where: { categoryId: lot.categoryId, status: "ACTIVE", NOT: { id: lot.id } },
      include: { category: true, seller: true },
      orderBy: { endsAt: "asc" },
      take: 4,
    }),
    db.lot.update({ where: { id: lot.id }, data: { views: { increment: 1 } } }),
  ]);

  const isAuction = lot.saleType === "AUCTION";
  const open = auctionOpen(lot);
  const buyPrice = purchasePrice(lot);
  const pct = pctOfRetail(lot.priceCents, lot.msrpCents);
  const perUnit = Math.round(lot.priceCents / Math.max(1, lot.units));
  const lotNo = lot.id.slice(-6).toUpperCase();
  const myBid = !!session && bids.some((b) => b.userId === session.userId);
  const bidStatus: "leading" | "outbid" | "none" | "own" =
    session && lot.seller.userId === session.userId ? "own" : session && lot.leaderId === session.userId ? "leading" : myBid ? "outbid" : "none";
  const bidderNo = new Map<string, number>();
  [...bids].reverse().forEach((b) => {
    if (!bidderNo.has(b.userId)) bidderNo.set(b.userId, bidderNo.size + 1);
  });
  const top = lot.manifest.slice(0, 3);
  const topShare = lot.msrpCents ? Math.round((top.reduce((a, m) => a + m.qty * m.unitMsrpCents, 0) / lot.msrpCents) * 100) : 0;

  const facts: [string, string][] = [
    ["Lot #", lotNo],
    ["Est. retail", money(lot.msrpCents)],
    ["Units", lot.units.toLocaleString()],
    ["Condition", CONDITIONS[lot.condition]?.label ?? lot.condition],
    ["Lot size", LOT_SIZES[lot.lotSize]?.label ?? lot.lotSize],
    ["Pallets", lot.lotSize === "CASE" ? "—" : String(lot.palletCount)],
    ["Weight", `${lot.weightLbs.toLocaleString()} lbs`],
    ["Ships from", lot.shipsFrom],
    ["Source", lot.source || "—"],
    ["Category", lot.subcategory ? `${lot.category.name} / ${lot.subcategory.name}` : lot.category.name],
    ["Price / unit", money(perUnit, { cents: true })],
    ["Watching", String(lot._count.favorites)],
  ];

  return (
    <div className="container-pp py-6">
      <nav className="mb-4 text-xs text-muted">
        <Link href="/" className="hover:underline">Home</Link> /{" "}
        <Link href={isAuction ? "/auctions" : "/buy-now"} className="hover:underline">{isAuction ? "Auctions" : "Buy Now"}</Link> /{" "}
        <Link href={`/c/${lot.category.slug}`} className="hover:underline">{lot.category.name}</Link>
        {lot.subcategory && (
          <> / <Link href={`/lots?category=${lot.category.slug}&sub=${lot.subcategory.slug}`} className="hover:underline">{lot.subcategory.name}</Link></>
        )}
      </nav>

      {/* Title row */}
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0 max-w-3xl">
          <div className="mb-2 flex flex-wrap items-center gap-2 text-xs">
            <span className={`rounded-md px-2 py-1 font-bold uppercase tracking-wide text-white ${isAuction ? "bg-ink" : "bg-signal"}`}>{isAuction ? "Auction" : "Buy Now"}</span>
            <ConditionBadge condition={lot.condition} />
            <span className="font-mono text-muted">Lot #{lotNo}</span>
            <span className="text-muted">· {lot.views + 1} views</span>
          </div>
          <h1 className="font-display text-2xl font-bold leading-tight sm:text-3xl">{lot.title}</h1>
          <p className="mt-1 text-sm text-muted">
            {lot.units.toLocaleString()} units · {money(lot.msrpCents)} est. retail · ships from {lot.shipsFrom}
          </p>
        </div>
        <div className="flex gap-2">
          <FavoriteButton lotId={lot.id} saved={!!saved} back={`/lots/${lot.slug}`} />
          <CopyLink />
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
        {/* Left column */}
        <div className="min-w-0 space-y-8">
          <LotGallery slug={lot.slug} hue={lot.category.hue} />

          {/* Key facts */}
          <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line text-sm sm:grid-cols-3 lg:grid-cols-4">
            {facts.map(([k, v]) => (
              <div key={k} className="bg-white p-3">
                <dt className="text-[11px] font-semibold uppercase tracking-wider text-muted">{k}</dt>
                <dd className="truncate font-semibold" title={v}>{v}</dd>
              </div>
            ))}
          </dl>

          {/* Section nav */}
          <nav className="sticky top-[118px] z-10 -mx-1 flex gap-1 overflow-x-auto border-b border-line bg-paper/95 px-1 pb-2 pt-1 backdrop-blur">
            {SECTIONS.map(([id, label]) => (
              <a key={id} href={`#${id}`} className="shrink-0 rounded-full px-3 py-1.5 text-sm font-semibold hover:bg-sand">{label}</a>
            ))}
            {isAuction && <a href="#bids" className="shrink-0 rounded-full px-3 py-1.5 text-sm font-semibold hover:bg-sand">Bid history ({lot.bidCount})</a>}
          </nav>

          <section id="overview" className="scroll-mt-40 space-y-4">
            <h2 className="font-display text-xl font-bold">Overview</h2>
            <p className="leading-relaxed text-ink/85">{lot.description}</p>
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="rounded-xl bg-sand/60 p-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted">{isAuction ? "Current price" : "Price"} vs. retail</p>
                <p className="font-display text-2xl font-bold">{pct}%</p>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white"><div className="h-full bg-signal" style={{ width: `${Math.min(100, pct)}%` }} /></div>
              </div>
              <div className="rounded-xl bg-sand/60 p-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted">Top 3 lines</p>
                <p className="font-display text-2xl font-bold">{topShare}%</p>
                <p className="text-xs text-muted">of the lot's retail value</p>
              </div>
              <div className="rounded-xl bg-sand/60 p-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted">Distinct items</p>
                <p className="font-display text-2xl font-bold">{lot.manifest.length}</p>
                <p className="text-xs text-muted">SKUs on the manifest</p>
              </div>
            </div>
            <div className="rounded-xl border border-line bg-white p-4 text-sm">
              <p className="font-semibold">Condition: {CONDITIONS[lot.condition]?.label}</p>
              <p className="mt-1 text-ink/75">{CONDITIONS[lot.condition]?.note} Lots are sold as-is according to this grade.</p>
            </div>
            {top.length > 0 && (
              <div>
                <p className="mb-2 text-sm font-semibold">Highest-value items</p>
                <ul className="grid gap-2 sm:grid-cols-3">
                  {top.map((m) => (
                    <li key={m.id} className="rounded-xl border border-line bg-white p-3 text-sm">
                      <p className="line-clamp-1 font-medium">{m.name}</p>
                      <p className="text-xs text-muted">{m.qty} × {money(m.unitMsrpCents)}</p>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>

          <section id="manifest" className="scroll-mt-40">
            <h2 className="mb-3 font-display text-xl font-bold">Manifest</h2>
            <ManifestTable rows={lot.manifest} csvHref={`/lots/${lot.slug}/manifest.csv`} />
            <p className="mt-2 text-xs text-muted">Manifests are prepared by our warehouse team. Small count variances are normal; see Returns & Disputes for what's covered.</p>
          </section>

          {isAuction && (
            <section id="bids" className="scroll-mt-40">
              <h2 className="mb-3 font-display text-xl font-bold">Bid history <span className="text-base font-normal text-muted">· {lot.bidCount} bids</span></h2>
              {bids.length === 0 ? (
                <p className="card p-6 text-sm text-muted">No bids yet. The auction opens at {money(lot.startPriceCents ?? lot.priceCents)}.</p>
              ) : (
                <div className="card overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-sand/60 text-left text-xs uppercase tracking-wider text-muted">
                      <tr><th className="px-4 py-3">Bidder</th><th className="px-4 py-3 text-right">Bid</th><th className="px-4 py-3">Placed</th></tr>
                    </thead>
                    <tbody className="divide-y divide-line">
                      {bids.map((b, i) => (
                        <tr key={b.id} className={i === 0 ? "bg-moss/5" : ""}>
                          <td className="px-4 py-3">
                            {session?.userId === b.userId ? <strong>You</strong> : `Bidder ${bidderNo.get(b.userId)}`}
                            {b.auto && <span className="ml-2 text-xs text-muted">(auto-bid)</span>}
                            {i === 0 && <span className="ml-2 rounded bg-moss/15 px-1.5 text-[10px] font-bold uppercase text-moss">High</span>}
                          </td>
                          <td className="px-4 py-3 text-right font-semibold">{money(b.amountCents)}</td>
                          <td className="px-4 py-3 text-xs text-muted">{timeAgo(b.createdAt)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          )}

          <section id="shipping" className="scroll-mt-40 space-y-3">
            <h2 className="font-display text-xl font-bold">Shipping & pickup</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="card p-4 text-sm">
                <p className="font-semibold">{lot.lotSize === "CASE" ? "Parcel delivery" : lot.lotSize === "TRUCKLOAD" ? "Full truckload" : "LTL freight"}</p>
                <p className="mt-1 text-ink/75">
                  {lot.lotSize === "CASE"
                    ? "Ships in sealed cartons by parcel carrier. No dock needed."
                    : lot.lotSize === "TRUCKLOAD"
                      ? `${lot.palletCount} pallets on a 53' trailer. A loading dock and forklift are required.`
                      : `${lot.palletCount} standard 48×40 pallet${lot.palletCount > 1 ? "s" : ""}, about ${Math.round(lot.weightLbs / Math.max(1, lot.palletCount)).toLocaleString()} lbs each. Liftgate available if you don't have a dock.`}
                </p>
              </div>
              <div className="card p-4 text-sm">
                <p className="font-semibold">Local pickup {lot.seller.pickup ? "available" : "not offered"}</p>
                <p className="mt-1 text-ink/75">
                  {lot.seller.pickup
                    ? `Collect from our warehouse in ${lot.shipsFrom}. Choose "Pick up" at checkout and we'll email you to book a dock time.`
                    : "Pickup isn't available right now. Freight is quoted by ZIP at checkout."}
                </p>
              </div>
            </div>
            <p className="text-xs text-muted">Freight is free on orders over $7,500 (liftgate and residential fees still apply). Inspect pallets and note any damage on the delivery receipt before signing.</p>
          </section>

          <section id="terms" className="scroll-mt-40 space-y-3">
            <h2 className="font-display text-xl font-bold">Payment & terms</h2>
            <ul className="grid gap-2 text-sm sm:grid-cols-2">
              {[
                ["Payment", "Card, wire/ACH, or Net 30 for verified resellers."],
                [isAuction ? "Winning" : "Checkout", isAuction ? "Winners pay within 3 days. Bids are binding." : "We confirm and prepare your order within one business day."],
                ["Sales tax", "Charged where applicable unless a valid resale certificate is on file."],
                ["Returns", "Sold as-is per the condition grade. Covered if retail value arrives >10% below manifest."],
              ].map(([t, d]) => (
                <li key={t} className="rounded-xl border border-line bg-white p-4">
                  <p className="font-semibold">{t}</p>
                  <p className="text-ink/75">{d}</p>
                </li>
              ))}
            </ul>
            <p className="text-xs"><Link href="/legal/returns-and-disputes" className="font-semibold text-signal-dark hover:underline">Returns & disputes policy</Link> · <Link href="/how-to-buy" className="font-semibold text-signal-dark hover:underline">How bidding works</Link></p>
          </section>

          <section id="reviews" className="scroll-mt-40 grid gap-4 md:grid-cols-[1fr_1.4fr]">
            <div className="card p-5">
              <p className="font-display text-lg font-bold">Questions about this lot?</p>
              <p className="mt-1 text-sm text-ink/75">
                Ask our warehouse team about photos, testing, freight or pickup. Quote lot #{lotNo} and we&apos;ll reply within one business day.
              </p>
              <p className="mt-3 flex items-center gap-1 text-xs text-muted">
                <Stars value={lot.seller.rating} /> {lot.seller.rating.toFixed(1)} from {lot.seller._count.reviews} customer review{lot.seller._count.reviews === 1 ? "" : "s"}
              </p>
              <Link href={`/contact?lot=${lotNo}`} className="btn-ghost mt-4 py-2 text-xs"><MessageCircle aria-hidden className="h-3.5 w-3.5" /> Ask a question</Link>
            </div>
            <div className="space-y-3">
              <h2 className="font-display text-xl font-bold">Customer reviews</h2>
              {reviews.length === 0 && <p className="text-sm text-muted">No reviews yet.</p>}
              {reviews.map((r) => (
                <div key={r.id} className="card p-4">
                  <div className="flex items-center justify-between"><Stars value={r.rating} /><span className="text-xs text-muted">{timeAgo(r.createdAt)}</span></div>
                  <p className="mt-1 text-sm">{r.body}</p>
                  <p className="mt-1 text-xs font-semibold text-muted">{r.user.businessName ?? r.user.name}</p>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Right column: sticky purchase box */}
        <aside className="space-y-4 lg:sticky lg:top-[130px] lg:h-fit">
          <div className="card space-y-4 p-5 shadow-sm">
            {isAuction && open && lot.endsAt ? (
              <BidPanel
                lotId={lot.id}
                priceCents={lot.priceCents}
                minBidCents={minNextBid(lot)}
                incrementCents={bidIncrement(lot.priceCents)}
                bidCount={lot.bidCount}
                endsAt={lot.endsAt.toISOString()}
                status={bidStatus}
                signedIn={!!session}
              />
            ) : isAuction ? (
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-muted">{lot.status === "SOLD_OUT" ? "Sold for" : "Auction ended"}</p>
                <p className="font-display text-4xl font-bold">{money(lot.priceCents)}</p>
                <p className="mt-1 text-sm text-muted">
                  {lot.status === "SOLD_OUT" ? `${lot.bidCount} bids · closed ${lot.endsAt?.toLocaleDateString() ?? ""}` : "No winning bid. We may relist this lot."}
                </p>
                {bidStatus === "leading" && lot.status === "SOLD_OUT" && (
                  <Link href="/bids?tab=won" className="btn-primary mt-3 w-full">You won — pay now</Link>
                )}
              </div>
            ) : (
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-muted">Price</p>
                <p className="font-display text-4xl font-bold">{money(lot.priceCents)}</p>
                <p className="text-sm text-muted">{money(perUnit, { cents: true })} per unit · {lot.available} available</p>
              </div>
            )}

            {buyPrice !== null && (
              <form action={addToCart} className="space-y-2 border-t border-line pt-4">
                <input type="hidden" name="lotId" value={lot.id} />
                {isAuction ? (
                  <p className="text-xs text-muted">Skip the auction — buying now ends it immediately.</p>
                ) : (
                  <label className="flex items-center justify-between text-sm">
                    <span>Quantity</span>
                    <select name="quantity" className="input w-24 py-2">
                      {Array.from({ length: lot.available }, (_, i) => i + 1).map((n) => <option key={n} value={n}>{n}</option>)}
                    </select>
                  </label>
                )}
                <SubmitButton className={isAuction ? "btn-dark w-full py-3" : "btn-primary w-full py-3"} pendingText="Adding…">
                  {isAuction ? `Buy it now · ${money(buyPrice)}` : "Add to cart"}
                </SubmitButton>
              </form>
            )}
            {!isAuction && buyPrice === null && (
              <p className="rounded-lg bg-sand p-3 text-center text-sm font-semibold">This lot has sold.</p>
            )}

            <ul className="space-y-1.5 border-t border-line pt-4 text-xs text-ink/75">
              <li className="flex items-start gap-2"><Check aria-hidden className="mt-0.5 h-3.5 w-3.5 shrink-0 text-moss" /><span>Full manifest — {lot.manifest.length} SKUs, {lot.units.toLocaleString()} units</span></li>
              <li className="flex items-start gap-2"><Check aria-hidden className="mt-0.5 h-3.5 w-3.5 shrink-0 text-moss" /><span>Est. retail {money(lot.msrpCents)} ({pct}% of retail)</span></li>
              <li className="flex items-start gap-2"><Check aria-hidden className="mt-0.5 h-3.5 w-3.5 shrink-0 text-moss" /><span>Sold &amp; shipped by {lot.seller.name} · <Star aria-hidden className="inline-block h-[1em] w-[1em] fill-signal align-[-0.125em] text-signal" /> {lot.seller.rating.toFixed(1)}</span></li>
              <li className="flex items-start gap-2"><Check aria-hidden className="mt-0.5 h-3.5 w-3.5 shrink-0 text-moss" /><span>Pay by card, wire/ACH or Net 30</span></li>
            </ul>
          </div>

          <ShippingEstimator
            pickup={lot.seller.pickup}
            defaultZip={me?.shipPostal}
            line={{
              sellerId: lot.sellerId,
              sellerName: lot.seller.name,
              shipsFrom: lot.shipsFrom,
              lotSize: lot.lotSize,
              palletCount: lot.palletCount,
              weightLbs: lot.weightLbs,
              quantity: 1,
              priceCents: buyPrice ?? lot.priceCents,
            }}
          />
        </aside>
      </div>

      {related.length > 0 && (
        <section className="mt-14">
          <div className="mb-5 flex items-end justify-between">
            <h2 className="font-display text-2xl font-bold">Similar lots</h2>
            <Link href={`/c/${lot.category.slug}`} className="text-sm font-semibold text-signal-dark hover:underline">More {lot.category.name}<NextIcon /></Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{related.map((l) => <LotCard key={l.id} lot={l} />)}</div>
        </section>
      )}
    </div>
  );
}
