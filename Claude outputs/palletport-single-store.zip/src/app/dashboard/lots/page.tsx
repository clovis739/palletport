import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { money, timeLeft } from "@/lib/format";
import { settleAuctions } from "@/lib/auctions";
import { ConditionBadge } from "@/components/ConditionBadge";
import { setLotStatus } from "@/app/actions/seller";
import { Plus } from "lucide-react";

export const metadata = { title: "Lots · Store manager" };

export default async function SellerLots() {
  const { seller } = await requireAdmin();
  await settleAuctions();
  const lots = await db.lot.findMany({ where: { sellerId: seller.id }, include: { _count: { select: { favorites: true, orderItems: true } } }, orderBy: { createdAt: "desc" } });
  return (
    <>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="font-display text-3xl font-bold">Lots</h1>
        <Link href="/dashboard/new" className="btn-primary"><Plus aria-hidden className="h-4 w-4" /> List a pallet</Link>
      </div>
      <div className="card overflow-x-auto">
        <table className="w-full min-w-[820px] text-sm">
          <thead className="bg-sand/60 text-left text-xs uppercase tracking-wider text-muted">
            <tr>
              <th className="px-4 py-3">Lot</th><th className="px-4 py-3">Type</th><th className="px-4 py-3">Condition</th><th className="px-4 py-3 text-right">Price / bid</th>
              <th className="px-4 py-3 text-right">Avail. / bids</th><th className="px-4 py-3 text-right">Views</th><th className="px-4 py-3 text-right">Saves</th>
              <th className="px-4 py-3">Status</th><th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {lots.map((l) => (
              <tr key={l.id}>
                <td className="px-4 py-3"><Link href={`/dashboard/lots/${l.id}`} className="font-medium hover:underline">{l.title}</Link></td>
                <td className="px-4 py-3 text-xs">
                  {l.saleType === "AUCTION" ? <>Auction<span className="block text-muted">{l.status === "ACTIVE" ? timeLeft(l.endsAt) : "closed"}</span></> : "Fixed price"}
                </td>
                <td className="px-4 py-3"><ConditionBadge condition={l.condition} /></td>
                <td className="px-4 py-3 text-right font-semibold">{money(l.priceCents)}</td>
                <td className="px-4 py-3 text-right">{l.saleType === "AUCTION" ? `${l.bidCount} bids` : l.available}</td>
                <td className="px-4 py-3 text-right">{l.views}</td>
                <td className="px-4 py-3 text-right">{l._count.favorites}</td>
                <td className="px-4 py-3 text-xs font-semibold">{l.status.replace("_", " ")}</td>
                <td className="space-x-3 whitespace-nowrap px-4 py-3 text-right">
                  <Link href={`/dashboard/lots/${l.id}`} className="text-xs font-semibold hover:underline">Edit</Link>
                  {(l.status === "ACTIVE" || l.status === "DRAFT") && !(l.saleType === "AUCTION" && l.bidCount > 0) && (
                    <form action={setLotStatus} className="inline">
                      <input type="hidden" name="id" value={l.id} />
                      <input type="hidden" name="status" value={l.status === "ACTIVE" ? "DRAFT" : "ACTIVE"} />
                      <button className="text-xs font-semibold text-signal-dark hover:underline">{l.status === "ACTIVE" ? "Unpublish" : "Publish"}</button>
                    </form>
                  )}
                </td>
              </tr>
            ))}
            {lots.length === 0 && <tr><td colSpan={9} className="p-8 text-center text-muted">No lots yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}
