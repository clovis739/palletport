import { requireAdmin } from "@/lib/auth";
import { updateStore } from "@/app/actions/seller";
import { ActionForm } from "@/components/forms/ActionForm";

export const metadata = { title: "Business settings · Store manager" };


export default async function StoreSettings() {
  const { seller } = await requireAdmin();
  return (
    <>
      <h1 className="mb-6 font-display text-3xl font-bold">Business settings</h1>
      <div className="card max-w-2xl p-6">
        <ActionForm action={updateStore} submitLabel="Save settings" successText="Settings saved">
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="name">Business name</label><input id="name" name="name" defaultValue={seller.name} className="input" required /></div>
            <div><label className="label" htmlFor="location">Warehouse location</label><input id="location" name="location" defaultValue={seller.location} className="input" required /></div>
          </div>
          <div><label className="label" htmlFor="bio">About your business (shown on the About page and lot pages)</label><textarea id="bio" name="bio" rows={4} defaultValue={seller.bio} className="input" required /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="minOrder">Minimum order value ($)</label><input id="minOrder" name="minOrder" type="number" min={0} defaultValue={seller.minOrderCents / 100} className="input" /></div>
            <label className="mt-6 flex items-center gap-2 text-sm"><input type="checkbox" name="pickup" defaultChecked={seller.pickup} className="accent-signal" /> Buyers can collect orders from our warehouse dock</label>
          </div>
        </ActionForm>
      </div>
    </>
  );
}
