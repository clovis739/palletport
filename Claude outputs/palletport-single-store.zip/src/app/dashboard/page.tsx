import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { money, timeAgo } from "@/lib/format";
import { StatusPill } from "../orders/StatusPill";
import { NextIcon } from "@/components/Icons";
import { Plus } from "lucide-react";

export const metadata = { title: "Store manager" };

export default async function DashboardOverview() {
  const { seller } = await requireAdmin();
  const since30 = new Date(Date.now() - 30 * 86400000);
  const [items30, openOrders, liveLots, lowStock, recent, pendingCerts, views] = await Promise.all([
    db.orderItem.findMany({ where: { sellerId: seller.id, order: { createdAt: { gte: since30 }, status: { not: "CANCELLED" } } } }),
    db.order.count({ where: { items: { some: { sellerId: seller.id } }, status: { in: ["PENDING", "CONFIRMED"] } } }),
    db.lot.count({ where: { sellerId: seller.id, status: "ACTIVE" } }),
    db.lot.findMany({ where: { sellerId: seller.id, status: "ACTIVE", available: 1 }, take: 5 }),
    db.order.findMany({ where: { items: { some: { sellerId: seller.id } } }, include: { user: { select: { businessName: true, name: true } } }, orderBy: { createdAt: "desc" }, take: 5 }),
    db.user.count({ where: { certStatus: "PENDING" } }),
    db.lot.aggregate({ where: { sellerId: seller.id }, _sum: { views: true } }),
  ]);
  const sales30 = items30.reduce((a, i) => a + i.priceCents * i.quantity, 0);

  return (
    <>
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm text-muted">Store manager</p>
          <h1 className="font-display text-3xl font-bold">Welcome back</h1>
        </div>
        <Link href="/dashboard/new" className="btn-primary"><Plus aria-hidden className="h-4 w-4" /> List a pallet</Link>
      </div>

      <div className="mb-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ["Sales (30 days)", money(sales30), "/dashboard/analytics"],
          ["Orders to action", String(openOrders), "/dashboard/orders"],
          ["Live lots", String(liveLots), "/dashboard/lots"],
          ["Certificates to review", String(pendingCerts), "/admin"],
        ].map(([k, v, href]) => (
          <Link key={k} href={href} className="card p-5 transition hover:border-ink">
            <p className="text-xs text-muted">{k}</p>
            <p className="font-display text-2xl font-bold">{v}</p>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-[2fr_1fr]">
        <section className="card">
          <div className="flex items-center justify-between border-b border-line px-5 py-3">
            <h2 className="font-display font-bold">Recent orders</h2>
            <Link href="/dashboard/orders" className="text-xs font-semibold text-signal-dark">All orders<NextIcon /></Link>
          </div>
          {recent.length === 0 ? (
            <p className="p-8 text-center text-sm text-muted">No orders yet. Share your storefront link to get your first sale.</p>
          ) : (
            <ul className="divide-y divide-line">
              {recent.map((o) => (
                <li key={o.id} className="flex items-center gap-3 px-5 py-3 text-sm">
                  <span className="font-mono font-semibold">{o.number}</span>
                  <span className="min-w-0 flex-1 truncate text-muted">{o.user.businessName ?? o.user.name}</span>
                  <StatusPill status={o.status} />
                  <span className="w-20 text-right text-xs text-muted">{timeAgo(o.createdAt)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
        <section className="space-y-4">
          <div className="card p-5">
            <h2 className="font-display font-bold">Last lot in stock</h2>
            {lowStock.length === 0 ? (
              <p className="mt-1 text-sm text-muted">Nothing running low.</p>
            ) : (
              <ul className="mt-2 space-y-1 text-sm">
                {lowStock.map((l) => <li key={l.id}><Link href={`/dashboard/lots/${l.id}`} className="hover:underline">{l.title}</Link></li>)}
              </ul>
            )}
          </div>
          <div className="card p-5">
            <h2 className="font-display font-bold">Storefront reach</h2>
            <p className="mt-1 font-display text-2xl font-bold">{(views._sum.views ?? 0).toLocaleString()}</p>
            <p className="text-xs text-muted">total lot views</p>
          </div>
          <div className="rounded-2xl bg-sand p-5 text-sm">
            <p className="font-display font-bold">Grow faster</p>
            <p className="mt-1 text-ink/75">A first-order promo code helps turn new visitors into buyers.</p>
            <Link href="/dashboard/promotions" className="mt-3 inline-block font-semibold text-signal-dark">Create a promotion<NextIcon /></Link>
          </div>
        </section>
      </div>
    </>
  );
}
