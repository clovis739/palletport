import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { initials } from "@/lib/format";
import { DashNav } from "./DashNav";
import { NextIcon } from "@/components/Icons";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { seller } = await requireAdmin();
  return (
    <div className="container-pp grid gap-8 py-8 lg:grid-cols-[220px_1fr]">
      <aside className="space-y-4">
        <Link href="/" className="flex items-center gap-3 rounded-xl bg-ink p-3 text-white">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-signal font-display text-sm font-bold">{initials(seller.name)}</span>
          <span className="min-w-0">
            <span className="block truncate text-sm font-semibold">{seller.name}</span>
            <span className="text-[11px] text-white/60">Store manager · view site<NextIcon /></span>
          </span>
        </Link>
        <DashNav />
      </aside>
      <div className="min-w-0">{children}</div>
    </div>
  );
}
