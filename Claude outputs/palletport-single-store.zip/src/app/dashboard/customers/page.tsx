import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { money } from "@/lib/format";

export const metadata = { title: "Customers · Store manager" };

export default async function Customers() {
  const { seller } = await requireAdmin();
  const items = await db.orderItem.findMany({
    where: { sellerId: seller.id, order: { status: { not: "CANCELLED" } } },
    include: { order: { include: { user: { select: { id: true, name: true, businessName: true, businessType: true, email: true, shipCity: true, shipRegion: true } } } } },
  });
  const map = new Map<string, { user: (typeof items)[number]["order"]["user"]; orders: Set<string>; spent: number; last: Date }>();
  for (const i of items) {
    const u = i.order.user;
    const e = map.get(u.id) ?? { user: u, orders: new Set<string>(), spent: 0, last: i.order.createdAt };
    e.orders.add(i.orderId);
    e.spent += i.priceCents * i.quantity;
    if (i.order.createdAt > e.last) e.last = i.order.createdAt;
    map.set(u.id, e);
  }
  const customers = [...map.values()].sort((a, b) => b.spent - a.spent);
  const followers = await db.follow.count({ where: { sellerId: seller.id } });

  return (
    <>
      <h1 className="mb-2 font-display text-3xl font-bold">Customers</h1>
      <p className="mb-6 text-sm text-muted">{customers.length} buyers · {followers} followers · {customers.filter((c) => c.orders.size > 1).length} repeat buyers</p>
      <div className="card overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="bg-sand/60 text-left text-xs uppercase tracking-wider text-muted">
            <tr><th className="px-4 py-3">Business</th><th className="px-4 py-3">Type</th><th className="px-4 py-3">Location</th><th className="px-4 py-3 text-right">Orders</th><th className="px-4 py-3 text-right">Spent</th><th className="px-4 py-3">Last order</th></tr>
          </thead>
          <tbody className="divide-y divide-line">
            {customers.map((c) => (
              <tr key={c.user.id}>
                <td className="px-4 py-3"><p className="font-medium">{c.user.businessName ?? c.user.name}</p><p className="text-xs text-muted">{c.user.email}</p></td>
                <td className="px-4 py-3 text-xs">{c.user.businessType ?? "—"}</td>
                <td className="px-4 py-3 text-xs">{[c.user.shipCity, c.user.shipRegion].filter(Boolean).join(", ") || "—"}</td>
                <td className="px-4 py-3 text-right">{c.orders.size}</td>
                <td className="px-4 py-3 text-right font-semibold">{money(c.spent)}</td>
                <td className="px-4 py-3 text-xs">{c.last.toLocaleDateString()}</td>
              </tr>
            ))}
            {customers.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-muted">Your buyers will appear here after the first order.</td></tr>}
          </tbody>
        </table>
      </div>
      <p className="mt-4 text-xs text-muted">Questions buyers send from lot pages and the contact form arrive in <a href="/admin" className="font-semibold text-signal-dark">Approvals &amp; inbox</a>.</p>
    </>
  );
}
