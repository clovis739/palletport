import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { createLot } from "@/app/actions/seller";
import { LotForm } from "../LotForm";

export const metadata = { title: "List a pallet" };

export default async function NewLotPage() {
  await requireAdmin();
  const categories = await db.category.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, subcategories: { select: { id: true, name: true }, orderBy: { name: "asc" } } } });
  return (
    <>
      <h1 className="mb-6 font-display text-3xl font-bold">List a pallet</h1>
      <div className="max-w-3xl"><LotForm categories={categories} action={createLot} submitLabel="Publish lot" /></div>
    </>
  );
}
