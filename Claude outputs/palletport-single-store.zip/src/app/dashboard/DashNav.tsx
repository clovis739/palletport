"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  Boxes,
  LayoutDashboard,
  Inbox,
  PlusCircle,

  Settings,
  ShoppingBag,
  TicketPercent,
  Users,
  type LucideIcon,
} from "lucide-react";

const LINKS: [string, string, LucideIcon][] = [
  ["/dashboard", "Overview", LayoutDashboard],
  ["/dashboard/orders", "Orders", ShoppingBag],
  ["/dashboard/lots", "Lots", Boxes],
  ["/dashboard/new", "List a pallet", PlusCircle],
  ["/dashboard/customers", "Customers", Users],
  ["/dashboard/promotions", "Promotions", TicketPercent],
  ["/dashboard/analytics", "Analytics", BarChart3],
  ["/admin", "Approvals & inbox", Inbox],
  ["/dashboard/settings", "Business settings", Settings],
];

export function DashNav() {
  const path = usePathname();
  return (
    <nav className="flex gap-1 overflow-x-auto lg:flex-col">
      {LINKS.map(([href, label, Icon]) => {
        const active = href === "/dashboard" ? path === href : path.startsWith(href);
        return (
          <Link key={href} href={href} className={`flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2 text-sm ${active ? "bg-sand font-semibold" : "text-ink/80 hover:bg-sand"}`}>
            <Icon aria-hidden className="h-4 w-4" />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}

