import type { Article } from "./types";

export const HELP_TOPICS = [
  { key: "Buying", blurb: "Accounts, verification, payment and terms" },
  { key: "Orders & freight", blurb: "Delivery, tracking, receiving and damage" },
  { key: "Account & security", blurb: "Passwords, profile and privacy" },
];

export const HELP: Article[] = [
  {
    slug: "how-bidding-works", category: "Buying", title: "How does bidding work?",
    excerpt: "Enter your maximum and we bid for you, one increment at a time.",
    body: [
      { p: ["PalletPort uses proxy bidding. You enter the most you're willing to pay; the visible bid only rises as much as needed to keep you ahead of other bidders. Your maximum stays private."] },
      { p: ["If a bid is placed in the last two minutes, the auction is extended by two minutes, so everyone gets a fair chance to respond."] },
      { p: ["See the full guide on the How to buy & bid page, including the bid increment table."] },
    ],
  },
  {
    slug: "paying-for-won-auctions", category: "Buying", title: "Paying for an auction you won",
    excerpt: "Pay within 3 days from My bids → Won.",
    body: [
      { p: ["When an auction closes and you're the high bidder, an order is created for you with status 'Awaiting payment'. Open it from My bids → Won, confirm your delivery address and choose card, wire/ACH or Net 30 (if verified)."] },
      { p: ["Please pay within 3 days. Unpaid lots may be offered to the next bidder, and repeated non-payment can suspend bidding privileges."] },
    ],
  },
  {
    slug: "retracting-a-bid", category: "Buying", title: "Can I retract a bid?",
    excerpt: "Bids are binding. Contact support if you made a typo.",
    body: [{ p: ["Bids are binding commitments to buy. If you entered a clearly mistaken amount (for example an extra zero), contact support right away and before the final hour of the auction — we review these case by case."] }],
  },
  {
    slug: "who-can-buy", category: "Buying", title: "Who can buy on PalletPort?",
    excerpt: "PalletPort is a wholesale marketplace for businesses that resell goods.",
    body: [
      { p: ["Any business that resells merchandise can open a buyer account — bin stores, discount shops, online resellers, flea-market vendors, refurbishers and exporters. You can browse without an account; you'll need one to add lots to your cart."] },
      { h: "Do I need a resale certificate?", p: ["Not to buy with a card or wire transfer. A verified resale certificate unlocks Net 30 terms and tax-exempt checkout where it applies. Add yours under Account → Business verification."] },
    ],
  },
  {
    slug: "payment-options", category: "Buying", title: "Payment options and Net 30 terms",
    excerpt: "Pay by card, wire/ACH, or Net 30 once your business is verified.",
    body: [
      { list: ["Card — charged when we confirm your order.", "Wire / ACH — we email bank details; the order ships once funds clear.", "Net 30 — for verified resellers. The invoice is due 30 days after delivery."] },
      { h: "How is Net 30 approved?", p: ["Submit your resale certificate number and issuing state. Our team reviews submissions within one business day. Approval limits are based on order history and may increase over time."] },
    ],
  },
  {
    slug: "condition-grades", category: "Buying", title: "What do the condition grades mean?",
    excerpt: "New, shelf pull, customer return, mixed and salvage — explained.",
    body: [
      { list: [
        "New / Overstock — unopened retail inventory in original packaging.",
        "Shelf Pull — removed from store shelves; may carry price stickers or light box wear.",
        "Customer Return — returned by shoppers and untested; expect a mix of working, cosmetic and defective units.",
        "Mixed — a combination of the grades above.",
        "Salvage — damaged or for parts, sold as-is to repair and parts professionals.",
      ] },
      { p: ["Liquidation lots are sold as-is according to the listed grade. Read the manifest and the lot notes, and contact us with questions before buying."] },
    ],
  },
  {
    slug: "promo-codes", category: "Buying", title: "Using promo codes",
    excerpt: "Enter one code per order in your cart.",
    body: [{ p: ["Enter a code in the Order summary on your cart page. Codes apply to your whole cart. Some codes require a minimum spend or are for first orders only; the cart will tell you why a code didn't apply."] }],
  },
  {
    slug: "minimum-order", category: "Buying", title: "Is there a minimum order?",
    excerpt: "We may set a minimum order value to cover dock and handling costs.",
    body: [{ p: ["If a minimum order value applies, it's shown in your cart along with how much more you'd need to add. Case packs and single pallets usually qualify on their own."] }],
  },
  {
    slug: "freight-and-delivery", category: "Orders & freight", title: "How freight and delivery work",
    excerpt: "Pallets ship LTL freight. Here's what to expect on delivery day.",
    body: [
      { p: ["Most lots ship by less-than-truckload (LTL) freight. Freight is estimated at $175 per pallet and is free on orders over $7,500. When we ship, you'll see a PRO (tracking) number on your order page."] },
      { h: "Dock or liftgate?", p: ["If your location has a loading dock, tick the dock box at checkout. Otherwise the carrier will bring a liftgate truck and lower pallets to the ground. Make sure you have a pallet jack or help to move them."] },
      { h: "Local pickup", p: ["You can collect from our warehouse dock. Choose pickup at checkout and we'll email you to book a time."] },
    ],
  },
  {
    slug: "receiving-a-shipment", category: "Orders & freight", title: "Receiving a shipment: inspect before you sign",
    excerpt: "Note visible damage on the delivery receipt to protect your claim.",
    body: [
      { list: ["Count the pallets against your order.", "Look for crushed corners, torn wrap or leaning stacks.", "Write any damage on the bill of lading before signing and take photos.", "Report problems within 48 hours through the contact form, quoting your order number."] },
    ],
  },
  {
    slug: "cancel-or-change", category: "Orders & freight", title: "Cancelling or changing an order",
    excerpt: "Orders can be cancelled until we confirm them.",
    body: [{ p: ["While an order is Pending, open it from Orders and choose Cancel order — the lot goes straight back on sale. After we confirm it, contact us; changes depend on whether the pallet has already been wrapped or collected by the carrier."] }],
  },
  {
    slug: "manifest-discrepancies", category: "Orders & freight", title: "What if the manifest doesn't match?",
    excerpt: "Small variances are normal; large ones are covered.",
    body: [{ p: ["Manifests are prepared by our warehouse team and small count variances happen. If the retail value you received is more than 10% below the manifest total, contact us within 7 days of delivery with photos. We'll review it and make it right."] }],
  },
  {
    slug: "reset-password", category: "Account & security", title: "Resetting your password",
    excerpt: "Use 'Forgot password?' on the sign-in page.",
    body: [{ p: ["Click Forgot password? on the sign-in page and enter your email. The reset link is valid for one hour. If you're signed in, you can change your password under Account → Password & security."] }],
  },
  {
    slug: "update-business-details", category: "Account & security", title: "Updating your business details",
    excerpt: "Change your name, business type and default address.",
    body: [{ p: ["Go to Account → Profile & address. Your default address pre-fills checkout. Contact us if you need to change the company name on an invoice."] }],
  },
];
