import Link from "next/link";
import { Logo } from "./Logo";
import { getCurrentUser } from "@/lib/auth";
import { getCartCount } from "@/lib/cart";
import { db } from "@/lib/db";
import { logout } from "@/app/actions/auth";
import { initials } from "@/lib/format";
import { NextIcon } from "@/components/Icons";
import { Heart, LayoutDashboard, LogOut, Search, ShoppingCart } from "lucide-react";

export async function Header() {
  const [user, categories] = await Promise.all([
    getCurrentUser(),
    db.category.findMany({ orderBy: { name: "asc" }, select: { name: true, slug: true } }),
  ]);
  const cartCount = user ? await getCartCount(user.id) : 0;
  const isAdmin = user?.role === "ADMIN";

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/95 backdrop-blur">
      <div className="bg-ink text-center text-xs text-white/85">
        <div className="container-pp flex items-center justify-center gap-4 py-2">
          <span>New auctions daily · Free freight on orders over $7,500 · Net 30 for verified resellers</span>
          <Link href="/how-to-buy" className="hidden font-semibold text-signal sm:inline">How bidding works<NextIcon /></Link>
        </div>
      </div>
      <div className="container-pp flex items-center gap-4 py-3">
        <Link href="/" className="shrink-0 text-ink"><Logo /></Link>
        <form action="/search" className="relative hidden flex-1 md:block">
          <Search aria-hidden className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <input name="q" placeholder="Search auctions, products, SKUs…" className="input rounded-full bg-white pl-10" />
        </form>
        <nav className="ml-auto flex items-center gap-1 text-sm font-medium sm:gap-2">
          {isAdmin && (
            <Link href="/dashboard" className="hidden items-center gap-1.5 rounded-full bg-sand px-3 py-2 font-semibold hover:bg-line sm:inline-flex">
              <LayoutDashboard aria-hidden className="h-4 w-4" /> Store manager
            </Link>
          )}
          {user ? (
            <>
              <Link href="/bids" className="hidden rounded-full px-3 py-2 hover:bg-sand md:block">My bids</Link>
              <Link href="/account/favorites" className="rounded-full p-2 hover:bg-sand" aria-label="Watchlist">
                <Heart aria-hidden className="h-6 w-6" strokeWidth={1.8} />
              </Link>
              <details className="relative">
                <summary className="grid h-9 w-9 cursor-pointer list-none place-items-center rounded-full bg-ink font-display text-xs font-bold text-white">{initials(user.name)}</summary>
                <div className="absolute right-0 mt-2 w-56 rounded-xl border border-line bg-white p-2 text-sm shadow-lg">
                  <p className="truncate px-3 py-2 text-xs text-muted">{user.businessName ?? user.email}</p>
                  {[["/account", "Account"], ["/bids", "My bids"], ["/orders", "Orders"], ["/account/favorites", "Watchlist"], ["/account/referrals", "Refer a business"], ...(isAdmin ? [["/dashboard", "Store manager"], ["/admin", "Approvals & inbox"]] : [])].map(([href, label]) => (
                    <Link key={href} href={href} className="block rounded-lg px-3 py-2 hover:bg-sand">{label}</Link>
                  ))}
                  <form action={logout}><button className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-muted hover:bg-sand"><LogOut aria-hidden className="h-4 w-4" /> Sign out</button></form>
                </div>
              </details>
            </>
          ) : (
            <>
              <Link href="/login" className="rounded-full px-3 py-2 hover:bg-sand">Sign in</Link>
              <Link href="/register" className="btn-dark hidden sm:inline-flex">Register to bid</Link>
            </>
          )}
          <Link href="/cart" className="relative rounded-full p-2 hover:bg-sand" aria-label="Cart">
            <ShoppingCart aria-hidden className="h-6 w-6" strokeWidth={1.8} />
            {cartCount > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-signal px-1 text-[11px] font-bold text-white">{cartCount}</span>}
          </Link>
        </nav>
      </div>
      <div className="container-pp -mt-1 flex gap-1 overflow-x-auto pb-2 text-sm [scrollbar-width:none]">
        <Link href="/auctions" className="shrink-0 rounded-full bg-ink px-3 py-1.5 font-semibold text-white hover:bg-ink-2">Auctions</Link>
        <Link href="/auctions?ending=today" className="shrink-0 rounded-full px-3 py-1.5 font-semibold text-rust hover:bg-sand">Ending today</Link>
        <Link href="/buy-now" className="shrink-0 rounded-full px-3 py-1.5 font-semibold hover:bg-sand">Buy Now</Link>
        <Link href="/truckloads" className="shrink-0 rounded-full px-3 py-1.5 font-semibold hover:bg-sand">Truckloads</Link>
        <Link href="/pallets" className="shrink-0 rounded-full px-3 py-1.5 font-semibold hover:bg-sand">Pallets</Link>
        <Link href="/case-packs" className="shrink-0 rounded-full px-3 py-1.5 font-semibold hover:bg-sand">Case packs</Link>
        <span className="mx-1 w-px shrink-0 bg-line" />
        {categories.map((c) => (
          <Link key={c.slug} href={`/c/${c.slug}`} className="shrink-0 rounded-full px-3 py-1.5 text-ink/75 hover:bg-sand hover:text-ink">{c.name}</Link>
        ))}
      </div>
    </header>
  );
}
