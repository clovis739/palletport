import Link from "next/link";
import { Logo } from "./Logo";
import { InquiryForm } from "./InquiryForm";

const COLS: [string, [string, string][]][] = [
  ["Shop", [["Live auctions", "/auctions"], ["Buy Now", "/buy-now"], ["Truckloads", "/truckloads"], ["Pallets", "/pallets"], ["Case packs", "/case-packs"], ["Categories", "/categories"], ["New arrivals", "/new"], ["Trending", "/trending"], ["Collections", "/collections"]]],
  ["Buyers", [["Register to bid", "/register"], ["How to buy & bid", "/how-to-buy"], ["My bids", "/bids"], ["How it works", "/how-it-works"], ["Guides by store type", "/guides"], ["PalletPort Pro", "/pro"], ["Volume buyers", "/volume-buyers"], ["Refer a business", "/account/referrals"]]],
  ["Company", [["About", "/about"], ["Blog", "/blog"], ["Market reports", "/reports"], ["Warehouse Days", "/events"], ["Affiliates", "/affiliates"], ["Help center", "/help"], ["Contact", "/contact"]]],
];

const LEGAL: [string, string][] = [["Terms", "/legal/terms"], ["Privacy", "/legal/privacy"], ["Cookies", "/legal/cookies"], ["Returns & disputes", "/legal/returns-and-disputes"], ["Prohibited items", "/legal/prohibited-items"], ["IP policy", "/legal/intellectual-property"], ["Accessibility", "/legal/accessibility"], ["Site map", "/site-map"]];

export function Footer() {
  return (
    <footer className="mt-20 bg-ink text-white/80">
      <div className="stripe h-2" />
      <div className="container-pp grid gap-10 py-14 lg:grid-cols-[1.5fr_repeat(3,1fr)]">
        <div className="space-y-4">
          <Logo className="text-white" />
          <p className="max-w-xs text-sm text-white/60">Liquidation pallets sold direct from our own warehouse. Every lot manifested, shipped dock to door or ready for pickup.</p>
          <div className="max-w-sm">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-white">The Monday Manifest</p>
            <InquiryForm topic="NEWSLETTER" inline dark submitLabel="Join" />
          </div>
        </div>
        {COLS.map(([title, links]) => (
          <div key={title}>
            <h4 className="mb-3 font-display text-sm font-semibold uppercase tracking-wider text-white">{title}</h4>
            <ul className="space-y-2 text-sm">
              {links.map(([label, href]) => <li key={href}><Link href={href} className="hover:text-signal">{label}</Link></li>)}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/10">
        <div className="container-pp flex flex-wrap items-center justify-between gap-3 py-5 text-xs text-white/50">
          <span>© {new Date().getFullYear()} PalletPort. All rights reserved.</span>
          <nav className="flex flex-wrap gap-x-4 gap-y-1">{LEGAL.map(([l, h]) => <Link key={h} href={h} className="hover:text-white">{l}</Link>)}</nav>
        </div>
      </div>
    </footer>
  );
}
