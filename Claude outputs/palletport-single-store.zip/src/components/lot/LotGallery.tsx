"use client";

import { useState } from "react";
import { PalletArt } from "@/components/PalletArt";
import { ChevronLeft, ChevronRight } from "lucide-react";

// Uses generated pallet art until you add photo uploads (add an images[] relation on Lot).
export function LotGallery({ slug, hue, badge }: { slug: string; hue: number; badge?: React.ReactNode }) {
  const seeds = [slug, `${slug}-2`, `${slug}-3`, `${slug}-4`, `${slug}-5`];
  const [active, setActive] = useState(0);
  return (
    <div className="space-y-3">
      <div className="card relative overflow-hidden">
        <PalletArt seed={seeds[active]} hue={hue} className="aspect-[16/10] w-full" />
        {badge && <div className="absolute left-3 top-3 flex gap-1.5">{badge}</div>}
        <span className="absolute bottom-3 right-3 rounded-md bg-ink/80 px-2 py-1 text-[11px] font-semibold text-white">
          {active + 1} / {seeds.length}
        </span>
        <button
          type="button"
          aria-label="Previous photo"
          onClick={() => setActive((a) => (a - 1 + seeds.length) % seeds.length)}
          className="absolute left-3 top-1/2 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-full bg-white/90 shadow hover:bg-white"
        ><ChevronLeft aria-hidden className="h-5 w-5" /></button>
        <button
          type="button"
          aria-label="Next photo"
          onClick={() => setActive((a) => (a + 1) % seeds.length)}
          className="absolute right-3 top-1/2 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-full bg-white/90 shadow hover:bg-white"
        ><ChevronRight aria-hidden className="h-5 w-5" /></button>
      </div>
      <div className="grid grid-cols-5 gap-2">
        {seeds.map((s, i) => (
          <button
            key={s}
            type="button"
            onClick={() => setActive(i)}
            aria-label={`Show photo ${i + 1}`}
            className={`overflow-hidden rounded-lg border-2 ${i === active ? "border-signal" : "border-transparent opacity-70 hover:opacity-100"}`}
          >
            <PalletArt seed={s} hue={hue} className="w-full" />
          </button>
        ))}
      </div>
    </div>
  );
}
