import Link from "next/link";
import { PalletArt } from "./PalletArt";
import { ConditionBadge } from "./ConditionBadge";
import { Countdown } from "./Countdown";
import { LOT_SIZES, money, pctOfRetail } from "@/lib/format";
import { Gavel, MapPin, Tag } from "lucide-react";

export type LotCardData = {
  slug: string;
  title: string;
  condition: string;
  priceCents: number;
  msrpCents: number;
  units: number;
  palletCount: number;
  shipsFrom: string;
  status: string;
  saleType?: string;
  lotSize?: string;
  bidCount?: number;
  endsAt?: Date | null;
  buyNowCents?: number | null;
  category: { hue: number; name: string };
  seller?: { name: string; verified: boolean };
};

export function LotCard({ lot }: { lot: LotCardData }) {
  const pct = pctOfRetail(lot.priceCents, lot.msrpCents);
  const auction = lot.saleType === "AUCTION";
  const live = auction && lot.status === "ACTIVE" && lot.endsAt && lot.endsAt.getTime() > Date.now();
  const closed = lot.status === "SOLD_OUT" || lot.status === "ENDED" || (auction && !live);
  return (
    <Link href={`/lots/${lot.slug}`} className="group card flex flex-col overflow-hidden transition hover:-translate-y-0.5 hover:shadow-lg hover:shadow-ink/5">
      <div className="relative">
        <PalletArt seed={lot.slug} hue={lot.category.hue} className="aspect-[16/10] w-full" />
        <div className="absolute left-3 top-3 flex gap-1.5">
          <span className={`rounded-md px-2 py-1 text-[11px] font-bold uppercase tracking-wide text-white inline-flex items-center gap-1 ${auction ? "bg-ink" : "bg-signal"}`}>{auction ? <Gavel aria-hidden className="h-3 w-3" /> : <Tag aria-hidden className="h-3 w-3" />}{auction ? "Auction" : "Buy Now"}</span>
          {lot.lotSize && <span className="rounded-md bg-white/90 px-2 py-1 text-[11px] font-bold uppercase tracking-wide text-ink">{LOT_SIZES[lot.lotSize]?.label ?? lot.lotSize}</span>}
        </div>
        <span className="absolute bottom-3 right-3 rounded-md bg-white/90 px-2 py-1 font-display text-xs font-bold text-ink">{pct}% of retail</span>
        {closed && (
          <div className="absolute inset-0 grid place-items-center bg-ink/60 font-display text-lg font-bold uppercase tracking-widest text-white">
            {lot.status === "ENDED" ? "Ended" : "Sold"}
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex items-center justify-between gap-2">
          <ConditionBadge condition={lot.condition} />
          <span className="inline-flex min-w-0 items-center gap-1 text-xs text-muted"><MapPin aria-hidden className="h-3 w-3 shrink-0" /><span className="truncate">{lot.shipsFrom}</span></span>
        </div>
        <h3 className="line-clamp-2 font-display text-[15px] font-semibold leading-snug group-hover:text-signal-dark">{lot.title}</h3>
        <div className="mt-auto flex items-end justify-between gap-2">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-wider text-muted">{auction ? (lot.bidCount ? "Current bid" : "Starting bid") : "Price"}</p>
            <p className="font-display text-xl font-bold leading-none">{money(lot.priceCents)}</p>
          </div>
          <p className="text-right text-xs text-muted">
            Retail
            <span className="block font-semibold text-ink line-through decoration-muted/60">{money(lot.msrpCents)}</span>
          </p>
        </div>
        <div className="flex items-center justify-between border-t border-line pt-2 text-xs text-muted">
          {auction ? (
            <>
              <span className="inline-flex items-center gap-1"><Gavel aria-hidden className="h-3 w-3" />{lot.bidCount ?? 0} bid{lot.bidCount === 1 ? "" : "s"}</span>
              {live && lot.endsAt ? <Countdown endsAt={lot.endsAt.toISOString()} compact className="font-semibold text-ink" /> : <span>Closed</span>}
            </>
          ) : (
            <>
              <span>{lot.units.toLocaleString()} units</span>
              <span className="truncate">{LOT_SIZES[lot.lotSize ?? "PALLET"]?.label ?? ""}</span>
            </>
          )}
        </div>
      </div>
    </Link>
  );
}
