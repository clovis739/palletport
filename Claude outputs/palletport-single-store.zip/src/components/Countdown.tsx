"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Clock } from "lucide-react";

function fmt(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${String(sec).padStart(2, "0")}s`;
  return `${m}m ${String(sec).padStart(2, "0")}s`;
}

/** Live auction countdown. Refreshes the page once when it hits zero so the lot settles. */
export function Countdown({ endsAt, className = "", compact = false }: { endsAt: string; className?: string; compact?: boolean }) {
  const end = new Date(endsAt).getTime();
  const [now, setNow] = useState<number | null>(null);
  const router = useRouter();
  const refreshed = useRef(false);

  useEffect(() => {
    setNow(Date.now());
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const left = now === null ? null : end - now;
  useEffect(() => {
    if (left !== null && left <= 0 && !refreshed.current) {
      refreshed.current = true;
      router.refresh();
    }
  }, [left, router]);

  if (left === null) return <span className={className}>&nbsp;</span>;
  if (left <= 0) return <span className={`${className} text-muted`}>Ended</span>;
  const urgent = left < 3600000;
  return (
    <span className={`${className} tabular-nums ${urgent ? "font-semibold text-rust" : ""}`} suppressHydrationWarning>
      <Clock aria-hidden className="mr-1 inline-block h-[1em] w-[1em] align-[-0.125em]" />
      {compact ? "" : "Ends in "}
      {fmt(left)}
    </span>
  );
}
