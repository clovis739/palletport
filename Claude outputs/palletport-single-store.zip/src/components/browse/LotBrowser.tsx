import Link from "next/link";
import { Search, X } from "lucide-react";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { settleAuctions } from "@/lib/auctions";
import { LotCard } from "@/components/LotCard";
import { CONDITIONS, LOT_SIZES, SOURCES, US_STATES } from "@/lib/format";
import { NextIcon, PrevIcon } from "@/components/Icons";

export type SearchParams = Record<string, string | string[] | undefined>;

const PAGE_SIZE = 24;
const SORTS: Record<string, string> = {
  ending: "Ending soonest",
  new: "Newly listed",
  value: "Lowest % of retail",
  price_asc: "Price: low to high",
  price_desc: "Price: high to low",
  bids: "Most bids",
  retail: "Highest retail value",
  units: "Most units",
};

const TYPES: Record<string, string> = { AUCTION: "Auctions", BUY_NOW: "Buy Now" };
const ENDING: Record<string, { label: string; hours: number }> = {
  "1h": { label: "Next hour", hours: 1 },
  today: { label: "Next 24 hours", hours: 24 },
  "3d": { label: "Next 3 days", hours: 72 },
};

function one(v: string | string[] | undefined) {
  return Array.isArray(v) ? v[0] : v;
}

/**
 * The shared browse grid used by /lots, /auctions, /buy-now and the lot-size pages.
 * `fixed` pins filters for a landing page (e.g. type=AUCTION) and hides that facet.
 */
export async function LotBrowser({
  sp,
  basePath = "/lots",
  fixed = {},
  heading,
  intro,
}: {
  sp: SearchParams;
  basePath?: string;
  fixed?: Record<string, string>;
  heading?: string;
  intro?: string;
}) {
  await settleAuctions();
  const get = (k: string) => fixed[k] ?? one(sp[k]) ?? "";

  const q = get("q").trim();
  const category = get("category");
  const sub = get("sub");
  const condition = get("condition");
  const type = get("type");
  const size = get("size");
  const source = get("source");
  const state = get("state");
  const ending = get("ending");
  const min = Number(get("min")) || 0;
  const max = Number(get("max")) || 0;
  const defaultSort = type === "AUCTION" ? "ending" : "new";
  const sort = SORTS[get("sort")] ? get("sort") : defaultSort;
  const page = Math.max(1, Number(get("page") || 1) || 1);
  const showSold = get("sold") === "1";

  const where: Prisma.LotWhereInput = {
    status: showSold ? { in: ["ACTIVE", "SOLD_OUT", "ENDED"] } : "ACTIVE",
    ...(category ? { category: { slug: category } } : {}),
    ...(condition ? { condition } : {}),
    ...(sub ? { subcategory: { slug: sub } } : {}),
    ...(type && TYPES[type] ? { saleType: type } : {}),
    ...(size && LOT_SIZES[size] ? { lotSize: size } : {}),
    ...(source ? { source } : {}),
    ...(state ? { shipsFrom: { endsWith: `, ${state}` } } : {}),
    ...(ending && ENDING[ending] ? { saleType: "AUCTION", endsAt: { gt: new Date(), lte: new Date(Date.now() + ENDING[ending].hours * 3600000) } } : {}),
    ...(min || max ? { priceCents: { ...(min ? { gte: min * 100 } : {}), ...(max ? { lte: max * 100 } : {}) } } : {}),
    ...(q
      ? {
          OR: [
            { title: { contains: q } },
            { id: { endsWith: q.toLowerCase() } },
            { manifest: { some: { sku: { contains: q } } } },
            { description: { contains: q } },
            { source: { contains: q } },
            { manifest: { some: { name: { contains: q } } } },
          ],
        }
      : {}),
  };

  const [all, categories] = await Promise.all([
    db.lot.findMany({ where, include: { category: true, seller: true } }),
    db.category.findMany({ orderBy: { name: "asc" }, include: { subcategories: { orderBy: { name: "asc" } } } }),
  ]);

  const far = Number.MAX_SAFE_INTEGER;
  const sorted = [...all].sort((a, b) => {
    switch (sort) {
      case "ending": return (a.endsAt?.getTime() ?? far) - (b.endsAt?.getTime() ?? far);
      case "value": return a.priceCents / a.msrpCents - b.priceCents / b.msrpCents;
      case "price_asc": return a.priceCents - b.priceCents;
      case "price_desc": return b.priceCents - a.priceCents;
      case "bids": return b.bidCount - a.bidCount;
      case "retail": return b.msrpCents - a.msrpCents;
      case "units": return b.units - a.units;
      default: return b.createdAt.getTime() - a.createdAt.getTime();
    }
  });
  const pages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  const lots = sorted.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const current: Record<string, string> = { q, category, sub, condition, type, size, source, state, ending, min: min ? String(min) : "", max: max ? String(max) : "", sort: sort === defaultSort ? "" : sort, sold: showSold ? "1" : "" };
  for (const k of Object.keys(fixed)) delete current[k];
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(current)) if (v) params.set(k, v);
  const href = (patch: Record<string, string | number | null>) => {
    const p = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) {
      if (v === null || v === "") p.delete(k);
      else p.set(k, String(v));
    }
    p.delete("page");
    if (patch.page) p.set("page", String(patch.page));
    const s = p.toString();
    return s ? `${basePath}?${s}` : basePath;
  };
  const hidden = (omit: string[]) =>
    Object.entries(current).filter(([k, v]) => v && !omit.includes(k)).map(([k, v]) => <input key={k} type="hidden" name={k} value={v} />);

  const activeCat = categories.find((c) => c.slug === category);
  const activeSub = activeCat?.subcategories.find((s) => s.slug === sub);
  const title = heading ?? (activeSub ? activeSub.name : activeCat ? activeCat.name : q ? `Results for “${q}”` : "All lots");
  const chip = (on: boolean) => `rounded-full border px-3 py-1 text-xs font-medium ${on ? "border-ink bg-ink text-white" : "border-line bg-white hover:border-ink"}`;
  const activeFilters = Object.entries(current).filter(([k, v]) => v && !["sort", "page"].includes(k));

  return (
    <div className="container-pp py-8">
      <nav className="mb-2 text-xs text-muted"><Link href="/" className="hover:underline">Home</Link> / {title}</nav>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold">{title}</h1>
          <p className="text-sm text-muted">{intro ?? `${sorted.length.toLocaleString()} lot${sorted.length === 1 ? "" : "s"}${activeCat ? ` · ${activeCat.blurb}` : ""}`}</p>
        </div>
        <form action={basePath} className="flex items-center gap-2">
          {hidden(["sort"])}
          <label htmlFor="sort" className="text-sm text-muted">Sort</label>
          <select id="sort" name="sort" defaultValue={sort} className="input w-auto py-2">
            {Object.entries(SORTS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <button className="btn-ghost py-2">Apply</button>
        </form>
      </div>

      <form action={basePath} className="mb-5 flex max-w-2xl gap-2">
        {hidden(["q"])}
        <input name="q" defaultValue={q} placeholder="Search by product, brand, SKU or source" className="input rounded-full" aria-label="Search lots" />
        <button className="btn-primary shrink-0"><Search aria-hidden className="h-4 w-4" /> Search</button>
      </form>

      {!fixed.type && (
        <div className="mb-6 flex flex-wrap gap-2">
          <Link href={href({ type: null })} className={chip(!type)}>All listings</Link>
          {Object.entries(TYPES).map(([k, v]) => <Link key={k} href={href({ type: k })} className={chip(type === k)}>{v}</Link>)}
          <span className="mx-1 w-px bg-line" />
          {Object.entries(LOT_SIZES).map(([k, v]) => (
            <Link key={k} href={href({ size: size === k ? null : k })} className={chip(size === k)}>{v.plural}</Link>
          ))}
        </div>
      )}

      {activeFilters.length > 0 && (
        <div className="mb-6 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-muted">Filters:</span>
          {activeFilters.map(([k, v]) => (
            <Link key={k} href={href({ [k]: null, ...(k === "category" ? { sub: null } : {}) })} className="inline-flex items-center gap-1 rounded-full bg-sand px-3 py-1 font-semibold hover:bg-line">
              {k === "min" ? `≥ $${v}` : k === "max" ? `≤ $${v}` : k === "sold" ? "Incl. closed" : (CONDITIONS[v]?.label ?? LOT_SIZES[v]?.plural ?? TYPES[v] ?? ENDING[v]?.label ?? v)}
              <X aria-hidden className="h-3.5 w-3.5" />
            </Link>
          ))}
          <Link href={basePath} className="font-semibold text-signal-dark hover:underline">Clear all</Link>
        </div>
      )}

      <div className="grid gap-8 lg:grid-cols-[250px_1fr]">
        <aside className="space-y-6">
          {(!fixed.type || fixed.type === "AUCTION") && (
            <div>
              <h3 className="label">Auction ending</h3>
              <div className="flex flex-wrap gap-2">
                {Object.entries(ENDING).map(([k, v]) => <Link key={k} href={href({ ending: ending === k ? null : k })} className={chip(ending === k)}>{v.label}</Link>)}
              </div>
            </div>
          )}
          {!fixed.category && (
            <div>
              <h3 className="label">Category</h3>
              <ul className="space-y-0.5 text-sm">
                <li><Link href={href({ category: null, sub: null })} className={`block rounded-lg px-2 py-1.5 hover:bg-sand ${!category ? "bg-sand font-semibold" : ""}`}>All categories</Link></li>
                {categories.map((c) => (
                  <li key={c.id}>
                    <Link href={href({ category: c.slug, sub: null })} className={`block rounded-lg px-2 py-1.5 hover:bg-sand ${category === c.slug && !sub ? "bg-sand font-semibold" : ""}`}>{c.name}</Link>
                    {category === c.slug && (
                      <ul className="ml-3 border-l border-line pl-2">
                        {c.subcategories.map((s) => (
                          <li key={s.id}><Link href={href({ sub: s.slug })} className={`block rounded-lg px-2 py-1 text-[13px] hover:bg-sand ${sub === s.slug ? "bg-sand font-semibold" : "text-ink/75"}`}>{s.name}</Link></li>
                        ))}
                      </ul>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div>
            <h3 className="label">Condition</h3>
            <div className="flex flex-wrap gap-2">
              {Object.entries(CONDITIONS).map(([k, c]) => <Link key={k} href={href({ condition: condition === k ? null : k })} className={chip(condition === k)}>{c.label}</Link>)}
            </div>
          </div>
          {!fixed.size && fixed.type && (
            <div>
              <h3 className="label">Lot size</h3>
              <div className="flex flex-wrap gap-2">
                {Object.entries(LOT_SIZES).map(([k, v]) => <Link key={k} href={href({ size: size === k ? null : k })} className={chip(size === k)}>{v.plural}</Link>)}
              </div>
            </div>
          )}
          <form action={basePath} className="space-y-2">
            {hidden(["source", "state"])}
            <h3 className="label">Source</h3>
            <select name="source" defaultValue={source} className="input py-2">
              <option value="">Any source</option>
              {SOURCES.map((s) => <option key={s}>{s}</option>)}
            </select>
            <h3 className="label pt-2">Ships from</h3>
            <select name="state" defaultValue={state} className="input py-2">
              <option value="">Any state</option>
              {US_STATES.map((s) => <option key={s}>{s}</option>)}
            </select>
            <button className="btn-ghost w-full py-2">Apply</button>
          </form>
          <form action={basePath} className="space-y-2">
            {hidden(["min", "max", "sold"])}
            <h3 className="label">Price (USD)</h3>
            <div className="flex items-center gap-2">
              <input name="min" type="number" min={0} placeholder="Min" defaultValue={min || ""} className="input" />
              <span className="text-muted">–</span>
              <input name="max" type="number" min={0} placeholder="Max" defaultValue={max || ""} className="input" />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" name="sold" value="1" defaultChecked={showSold} className="accent-signal" /> Include closed lots
            </label>
            <button className="btn-dark w-full">Update results</button>
          </form>
        </aside>

        <section>
          {lots.length === 0 ? (
            <div className="card grid place-items-center p-16 text-center">
              <p className="font-display text-lg font-semibold">No lots match those filters</p>
              <p className="mt-1 text-sm text-muted">Try another lot size or condition, or widen the price range.</p>
              <Link href={basePath} className="btn-primary mt-5">Reset filters</Link>
            </div>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {lots.map((l) => <LotCard key={l.id} lot={l} />)}
            </div>
          )}
          {pages > 1 && (
            <div className="mt-10 flex items-center justify-center gap-2">
              {page > 1 && <Link href={href({ page: page - 1 })} className="btn-ghost"><PrevIcon />Prev</Link>}
              <span className="px-3 text-sm text-muted">Page {page} of {pages}</span>
              {page < pages && <Link href={href({ page: page + 1 })} className="btn-ghost">Next<NextIcon /></Link>}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
