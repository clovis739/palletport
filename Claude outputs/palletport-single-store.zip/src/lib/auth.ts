import "server-only";
import { cookies } from "next/headers";
import { forbidden, redirect } from "next/navigation";
import { db } from "./db";
import { SESSION_COOKIE, verifySession } from "./session";

export async function getSession() {
  const store = await cookies();
  return verifySession(store.get(SESSION_COOKIE)?.value);
}

export async function getCurrentUser() {
  const session = await getSession();
  if (!session) return null;
  return db.user.findUnique({
    where: { id: session.userId },
  });
}

export async function requireUser(next = "/") {
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(next)}`);
  return user;
}

/** Store manager pages: only the admin (the business owner/staff) may use them. */
export async function requireAdmin(next = "/dashboard") {
  const user = await requireUser(next);
  if (user.role !== "ADMIN") forbidden();
  const { getStore } = await import("./store");
  return { user, seller: await getStore() };
}
