import type { NextConfig } from "next";

const isProd = process.env.NODE_ENV === "production";

const securityHeaders = [
  // Browsers remember to use HTTPS for two years (only sent in production over HTTPS).
  ...(isProd ? [{ key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" }] : []),
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "SAMEORIGIN" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), browsing-topics=()" },
];

const nextConfig: NextConfig = {
  serverExternalPackages: ["bcryptjs"],
  poweredByHeader: false,
  experimental: {
    // Enables forbidden() / unauthorized() and the app/forbidden.tsx + app/unauthorized.tsx screens.
    authInterrupts: true,
  },
  // Old marketplace URLs (multi-seller features were removed): send visitors somewhere useful.
  async redirects() {
    return [
      { source: "/sell", destination: "/contact", permanent: true },
      { source: "/sell/:path*", destination: "/contact", permanent: true },
      { source: "/sellers", destination: "/about", permanent: true },
      { source: "/sellers/:path*", destination: "/search", permanent: true },
      { source: "/messages", destination: "/contact", permanent: true },
      { source: "/messages/:path*", destination: "/contact", permanent: true },
      { source: "/dashboard/payouts", destination: "/dashboard/analytics", permanent: true },
    ];
  },
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
};

export default nextConfig;
