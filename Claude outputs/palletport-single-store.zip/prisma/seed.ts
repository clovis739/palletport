import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const subcats: Record<string, string[]> = {
  electronics: ["Audio", "Smart Home", "Phone Accessories", "Computers & Tablets"],
  "home-kitchen": ["Small Appliances", "Cookware", "Home Decor", "Bedding & Bath"],
  apparel: ["Activewear", "Footwear", "Kids Clothing", "Bags & Accessories"],
  "tools-hardware": ["Power Tools", "Hand Tools", "Lighting & Electrical", "Plumbing"],
  "toys-baby": ["Toys & Games", "Nursery", "Outdoor Play"],
  "health-beauty": ["Cosmetics", "Personal Care", "Hair Tools"],
  furniture: ["Office", "Patio & Outdoor", "Living Room"],
  "general-merchandise": ["Truckloads", "Seasonal", "Mystery Mix"],
};

const categories = [
  { name: "Electronics", slug: "electronics", blurb: "Phones, audio, smart home, accessories", hue: 215 },
  { name: "Home & Kitchen", slug: "home-kitchen", blurb: "Cookware, small appliances, decor", hue: 24 },
  { name: "Apparel", slug: "apparel", blurb: "Mixed brand clothing, shoes, bags", hue: 330 },
  { name: "Tools & Hardware", slug: "tools-hardware", blurb: "Power tools, hand tools, fixtures", hue: 45 },
  { name: "Toys & Baby", slug: "toys-baby", blurb: "Toys, games, nursery essentials", hue: 280 },
  { name: "Health & Beauty", slug: "health-beauty", blurb: "Personal care, cosmetics, wellness", hue: 160 },
  { name: "Furniture", slug: "furniture", blurb: "Flat-pack, office, patio", hue: 90 },
  { name: "General Merchandise", slug: "general-merchandise", blurb: "Mixed truckload and pallet lots", hue: 0 },
];

// Your company. Edit these, or change them later in Store manager -> Business settings.
const STORE = {
  name: "PalletPort",
  slug: "store",
  location: "Columbus, OH",
  bio: "We buy customer returns, shelf pulls and overstock from major retailers, sort and manifest every pallet in our own Columbus warehouse, and sell direct to resellers.",
  verified: true,
  rating: 4.8,
  minOrderCents: 0,
  pickup: true,
};

const SOURCES = [
  "Big-box retailer returns",
  "Online marketplace returns",
  "Department store overstock",
  "Home improvement retailer",
  "Warehouse club",
  "Specialty retailer",
  "Manufacturer overstock",
  "Closeout / store closure",
];

function inc(c: number) {
  const d = c / 100;
  if (d < 100) return 500;
  if (d < 500) return 1000;
  if (d < 1000) return 2500;
  if (d < 5000) return 5000;
  if (d < 25000) return 10000;
  return 25000;
}

const conditions = ["NEW", "SHELF_PULL", "CUSTOMER_RETURN", "MIXED", "SALVAGE"];

const lotTemplates: Record<string, { title: string; items: [string, number][] }[]> = {
  electronics: [
    { title: "Wireless Earbuds & Headphones", items: [["True wireless earbuds", 39], ["Over-ear ANC headphones", 129], ["Sport neckband earphones", 29], ["Kids volume-limited headphones", 24]] },
    { title: "Smart Home Starter Mix", items: [["Smart plug 2-pack", 24], ["Wi-Fi video doorbell", 99], ["Smart bulb 4-pack", 44], ["Indoor security camera", 49]] },
    { title: "Phone Accessories Bulk", items: [["USB-C fast charger", 19], ["Braided charging cable 6ft", 14], ["Magnetic phone case", 29], ["Power bank 10000mAh", 34]] },
  ],
  "home-kitchen": [
    { title: "Small Kitchen Appliances", items: [["Air fryer 5qt", 89], ["Stand blender", 69], ["Drip coffee maker", 49], ["Electric kettle", 34]] },
    { title: "Cookware & Bakeware Overstock", items: [["Nonstick fry pan set", 59], ["Sheet pan 3-pack", 29], ["Dutch oven 6qt", 79], ["Utensil set", 19]] },
    { title: "Home Decor Shelf Pulls", items: [["Throw pillow", 22], ["Table lamp", 45], ["Wall mirror", 69], ["Faux plant", 29]] },
  ],
  apparel: [
    { title: "Mixed Brand Activewear", items: [["Leggings", 45], ["Performance tee", 28], ["Zip hoodie", 60], ["Running shorts", 32]] },
    { title: "Footwear Closeouts", items: [["Running sneakers", 90], ["Slip-on loafers", 65], ["Kids sneakers", 40], ["Slides", 25]] },
  ],
  "tools-hardware": [
    { title: "Cordless Power Tool Returns", items: [["20V drill/driver kit", 129], ["Impact driver", 99], ["Oscillating multi-tool", 89], ["Battery 4Ah", 79]] },
    { title: "Hand Tools & Storage", items: [["Socket set 120pc", 69], ["Tool bag", 39], ["Tape measure 25ft", 15], ["Rolling tool chest", 199]] },
  ],
  "toys-baby": [
    { title: "Toy Store Overstock", items: [["Building block set", 49], ["Plush toy", 18], ["Board game", 25], ["RC car", 39]] },
    { title: "Nursery Essentials", items: [["Baby monitor", 79], ["Diaper caddy", 22], ["Swaddle 3-pack", 29], ["Bottle warmer", 35]] },
  ],
  "health-beauty": [
    { title: "Beauty & Cosmetics Mix", items: [["Lipstick", 18], ["Foundation", 32], ["Hair dryer", 59], ["Skincare set", 45]] },
    { title: "Personal Care Shelf Pulls", items: [["Electric toothbrush", 49], ["Beard trimmer", 39], ["Body wash 3-pack", 15], ["Vitamin C serum", 25]] },
  ],
  furniture: [
    { title: "Office Furniture Returns", items: [["Ergonomic office chair", 249], ["Standing desk frame", 299], ["Bookshelf 5-tier", 89], ["Filing cabinet", 129]] },
    { title: "Patio & Outdoor", items: [["Folding patio chair", 59], ["Bistro table", 99], ["Outdoor rug 5x7", 69], ["Solar string lights", 29]] },
  ],
  "general-merchandise": [
    { title: "Big-Box Returns Truckload Pallet", items: [["Assorted household", 25], ["Assorted electronics", 45], ["Assorted toys", 20], ["Assorted home", 30]] },
    { title: "Seasonal Overstock Mix", items: [["Holiday decor", 25], ["Pool floats", 20], ["Halloween costumes", 35], ["Outdoor lights", 30]] },
  ],
};

const conditionDiscount: Record<string, number> = {
  NEW: 0.32,
  SHELF_PULL: 0.26,
  CUSTOMER_RETURN: 0.16,
  MIXED: 0.14,
  SALVAGE: 0.07,
};

function rand(seed: number) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function slugify(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

async function main() {
  await prisma.bid.deleteMany();
  await prisma.inquiry.deleteMany();
  await prisma.passwordReset.deleteMany();
  await prisma.payout.deleteMany();
  await prisma.promo.deleteMany();
  await prisma.review.deleteMany();
  await prisma.message.deleteMany();
  await prisma.conversation.deleteMany();
  await prisma.follow.deleteMany();
  await prisma.favorite.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.cartItem.deleteMany();
  await prisma.manifestItem.deleteMany();
  await prisma.lot.deleteMany();
  await prisma.seller.deleteMany();
  await prisma.subcategory.deleteMany();
  await prisma.category.deleteMany();
  await prisma.user.deleteMany();

  const passwordHash = await bcrypt.hash("password123", 10);

  const buyer = await prisma.user.create({
    data: {
      email: "buyer@palletport.test", name: "Demo Buyer", businessName: "Main Street Resale", businessType: "Bin store",
      passwordHash, role: "BUYER", certStatus: "APPROVED", certNumber: "OH-99812", certState: "OH",
      shipAddress: "410 Commerce Dr", shipCity: "Dayton", shipRegion: "OH", shipPostal: "45402", shipCountry: "United States",
    },
  });
  await prisma.user.create({
    data: { email: "pending@palletport.test", name: "Pat Pending", businessName: "Weekend Flea Finds", businessType: "Flea market vendor", passwordHash, certStatus: "PENDING", certNumber: "TX-11873", certState: "TX" },
  });
  const admin = await prisma.user.create({
    data: { email: "admin@palletport.test", name: "PalletPort Admin", passwordHash, role: "ADMIN" },
  });

  const bidders = [buyer];
  for (const [i, b] of ["Northside Bins", "Flip & Ship LLC", "Second Chance Goods"].entries()) {
    bidders.push(await prisma.user.create({ data: { email: `bidder${i + 1}@palletport.test`, name: b, businessName: b, passwordHash, certStatus: "APPROVED" } }));
  }

  const cats = [];
  for (const c of categories) {
    cats.push(
      await prisma.category.create({
        data: { ...c, subcategories: { create: (subcats[c.slug] ?? []).map((name) => ({ name, slug: `${c.slug}-${slugify(name)}` })) } },
        include: { subcategories: true },
      }),
    );
  }

  // Single-seller store: every lot is sold by the company, from its own warehouse, owned by the admin account.
  const store = await prisma.seller.create({ data: { ...STORE, userId: admin.id } });

  let n = 1;
  for (const cat of cats) {
    const templates = lotTemplates[cat.slug] ?? [];
    for (const [ti, t] of templates.entries()) {
      const sub = cat.subcategories[ti % Math.max(1, cat.subcategories.length)];
      for (let v = 0; v < 2; v++) {
        const seed = n * 7.13;
        const condition = conditions[Math.floor(rand(seed) * conditions.length)];
        const seller = store;
        const sizeRoll = rand(seed + 2);
        const lotSize = sizeRoll < 0.15 ? "CASE" : sizeRoll > 0.82 ? "TRUCKLOAD" : "PALLET";
        const palletCount = lotSize === "TRUCKLOAD" ? 18 + Math.floor(rand(seed + 3) * 9) : lotSize === "CASE" ? 1 : rand(seed + 3) > 0.7 ? 2 + Math.floor(rand(seed + 3) * 3) : 1;
        const scale = lotSize === "CASE" ? 0.12 : palletCount;
        const manifest = t.items.map(([name, msrp], i) => ({
          sku: `PP-${cat.slug.slice(0, 3).toUpperCase()}-${n}${i}`,
          name,
          qty: Math.max(lotSize === "CASE" ? 2 : 4, Math.floor(rand(seed + i + 4) * 60 * scale)),
          unitMsrpCents: msrp * 100,
        }));
        const msrpCents = manifest.reduce((a, m) => a + m.qty * m.unitMsrpCents, 0);
        const units = manifest.reduce((a, m) => a + m.qty, 0);
        const fairCents = Math.round((msrpCents * conditionDiscount[condition]) / 100) * 100;
        const title =
          lotSize === "TRUCKLOAD" ? `${t.title} — Truckload (${palletCount} Pallets)` : lotSize === "CASE" ? `${t.title} — Case Pack` : palletCount > 1 ? `${t.title} — ${palletCount} Pallets` : `${t.title} Pallet`;
        const isAuction = rand(seed + 14) < 0.65;
        const source = SOURCES[Math.floor(rand(seed + 15) * SOURCES.length)];

        // Auctions: start low, end between 25 minutes and 6 days from now, some with bidding history.
        let auction: Partial<{
          saleType: string; startPriceCents: number; buyNowCents: number | null; endsAt: Date; bidCount: number;
          leaderId: string | null; leaderMaxCents: number | null; priceCents: number; available: number;
        }> = {};
        const bidRows: { userId: string; amountCents: number; maxCents: number | null; auto: boolean; createdAt: Date }[] = [];
        if (isAuction) {
          const start = Math.max(500, Math.round((fairCents * 0.35) / 500) * 500);
          const endsAt = new Date(Date.now() + (25 + Math.floor(rand(seed + 16) * 6 * 24 * 60)) * 60000);
          const nBids = rand(seed + 17) < 0.25 ? 0 : 1 + Math.floor(rand(seed + 18) * 9);
          let price = start;
          let leader: string | null = null;
          for (let b = 0; b < nBids; b++) {
            const who = bidders[1 + ((b + n) % (bidders.length - 1))].id; // demo buyer bids separately below
            price = b === 0 ? start : price + inc(price);
            leader = who;
            bidRows.push({ userId: who, amountCents: price, maxCents: price, auto: false, createdAt: new Date(Date.now() - (nBids - b) * 3600000) });
          }
          auction = {
            saleType: "AUCTION",
            startPriceCents: start,
            buyNowCents: rand(seed + 19) < 0.4 ? Math.round((fairCents * 1.05) / 500) * 500 : null,
            endsAt,
            bidCount: nBids,
            leaderId: leader,
            leaderMaxCents: leader ? price : null,
            priceCents: price,
            available: 1,
          };
        }
        const lot = await prisma.lot.create({
          data: {
            slug: `${slugify(title)}-${n}`,
            title,
            description: `Manifested ${cat.name.toLowerCase()} ${lotSize === "CASE" ? "case pack" : lotSize === "TRUCKLOAD" ? "truckload" : "lot"} sourced from ${source.toLowerCase()}. Contents are listed in the manifest below; quantities are counted at the dock. ${lotSize === "CASE" ? "Ships by parcel in sealed cartons." : "Stretch-wrapped on standard 48×40 pallets."}`,
            condition,
            priceCents: fairCents,
            msrpCents,
            units,
            palletCount,
            lotSize,
            source,
            weightLbs: lotSize === "CASE" ? 20 + Math.floor(rand(seed + 9) * 60) : palletCount * (300 + Math.floor(rand(seed + 9) * 500)),
            shipsFrom: seller.location,
            available: 1 + Math.floor(rand(seed + 10) * 4),
            featured: rand(seed + 11) > 0.72,
            categoryId: cat.id,
            subcategoryId: sub?.id,
            views: Math.floor(rand(seed + 12) * 900),
            createdAt: new Date(Date.now() - Math.floor(rand(seed + 13) * 30) * 86400000),
            sellerId: seller.id,
            manifest: { create: manifest },
            ...auction,
          },
        });
        if (bidRows.length) await prisma.bid.createMany({ data: bidRows.map((b) => ({ ...b, lotId: lot.id })) });
        n++;
      }
    }
  }

  // ---- demo buyer's auction activity: leading on one, outbid on one, and a won auction awaiting payment
  const open = await prisma.lot.findMany({ where: { saleType: "AUCTION", status: "ACTIVE", bidCount: { gt: 0 } }, orderBy: { endsAt: "asc" }, take: 2 });
  if (open[0]) {
    const price = open[0].priceCents + inc(open[0].priceCents);
    await prisma.bid.create({ data: { lotId: open[0].id, userId: buyer.id, amountCents: price, maxCents: price + inc(price) * 3 } });
    await prisma.lot.update({ where: { id: open[0].id }, data: { priceCents: price, leaderId: buyer.id, leaderMaxCents: price + inc(price) * 3, bidCount: { increment: 1 } } });
  }
  if (open[1]) {
    await prisma.bid.create({ data: { lotId: open[1].id, userId: buyer.id, amountCents: open[1].priceCents - inc(open[1].priceCents), maxCents: open[1].priceCents - inc(open[1].priceCents), createdAt: new Date(Date.now() - 7200000) } });
  }
  const toWin = await prisma.lot.findFirst({ where: { saleType: "AUCTION", status: "ACTIVE", bidCount: 0 } });
  if (toWin && toWin.startPriceCents) {
    // Ended an hour ago with the demo buyer as high bidder; the site settles it into an order on first page load.
    await prisma.bid.create({ data: { lotId: toWin.id, userId: buyer.id, amountCents: toWin.startPriceCents, maxCents: toWin.startPriceCents } });
    await prisma.lot.update({
      where: { id: toWin.id },
      data: { endsAt: new Date(Date.now() - 3600000), leaderId: buyer.id, leaderMaxCents: toWin.startPriceCents, priceCents: toWin.startPriceCents, bidCount: 1 },
    });
  }

  // ---- promos
  await prisma.promo.create({ data: { code: "WELCOME10", description: "10% off your first order (up to any size)", percentOff: 10, firstOrderOnly: true } });
  await prisma.promo.create({ data: { code: "FREIGHT150", description: "$150 off orders over $2,500", amountOffCents: 15000, minSubtotalCents: 250000 } });
  await prisma.promo.create({ data: { code: "TRUCKLOAD5", description: "5% off orders over $10,000", percentOff: 5, minSubtotalCents: 1000000 } });

  // ---- a delivered order with review, and an in-flight order, for the demo buyer
  const someLots = await prisma.lot.findMany({ where: { saleType: "BUY_NOW" }, take: 2 });
  const otherLots = await prisma.lot.findMany({ where: { saleType: "BUY_NOW" }, skip: 2, take: 1 });
  const ship = { shipName: "Main Street Resale", shipAddress: "410 Commerce Dr", shipCity: "Dayton", shipRegion: "OH", shipPostal: "45402", shipCountry: "United States" };
  if (someLots[0]) {
    const o1 = await prisma.order.create({
      data: {
        number: "PP-DEMO-001", userId: buyer.id, status: "DELIVERED", paymentMethod: "NET30",
        subtotalCents: someLots[0].priceCents, shippingCents: 17500, totalCents: someLots[0].priceCents + 17500,
        trackingNo: "PRO-448120", createdAt: new Date(Date.now() - 20 * 86400000), ...ship,
        items: { create: [{ lotId: someLots[0].id, sellerId: store.id, title: someLots[0].title, priceCents: someLots[0].priceCents, quantity: 1 }] },
      },
    });
    await prisma.review.create({ data: { orderId: o1.id, userId: buyer.id, sellerId: store.id, rating: 5, body: "Manifest matched what arrived almost exactly. Well wrapped, dock delivery was on time." } });
  }
  if (otherLots[0]) {
    await prisma.order.create({
      data: {
        number: "PP-DEMO-002", userId: buyer.id, status: "SHIPPED", paymentMethod: "CARD",
        subtotalCents: otherLots[0].priceCents, shippingCents: 17500, totalCents: otherLots[0].priceCents + 17500,
        trackingNo: "PRO-551903", createdAt: new Date(Date.now() - 3 * 86400000), ...ship,
        items: { create: [{ lotId: otherLots[0].id, sellerId: store.id, title: otherLots[0].title, priceCents: otherLots[0].priceCents, quantity: 1 }] },
      },
    });
  }
  if (someLots[1]) await prisma.favorite.create({ data: { userId: buyer.id, lotId: someLots[1].id } });


  console.log(`Seeded ${cats.length} categories and ${n - 1} lots for ${store.name}.`);
  console.log("Demo logins (password: password123): admin@palletport.test (store owner), buyer@palletport.test, pending@palletport.test, bidder1-3@palletport.test");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
